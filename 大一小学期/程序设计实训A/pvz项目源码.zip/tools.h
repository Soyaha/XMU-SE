#pragma once
#include <graphics.h>

void putimagePNG(int  picture_x, int picture_y, IMAGE* picture);
int getDelay();