#include <algorithm>
#include <iostream>
using namespace std;

const int N = 100007;
int nums[N];

int main()
{
    int n, q;
    scanf("%d%d", &n, &q);
    for (int i = 0; i < n; i++)
        scanf("%d", &nums[i]);
    while (q--)
    {
        int k;
        scanf("%d", &k);
        int left = 0, right = n - 1;
        while (left < right)
        {
            int mid = left + right >> 1;
            if (nums[mid] >= k)
                right = mid;
            else
                left = mid + 1;
        }
        if (nums[left] != k)
            cout << "-1 -1" << endl;
        else
        {
            cout << left << " ";
            left = 0, right = n - 1;
            while (left < right)
            {
                int mid = left + right + 1 >> 1;
                if (nums[mid] <= k)
                    left = mid;
                else
                    right = mid - 1;
            }
            cout << left << endl;
        }
    }
    return 0;
}
