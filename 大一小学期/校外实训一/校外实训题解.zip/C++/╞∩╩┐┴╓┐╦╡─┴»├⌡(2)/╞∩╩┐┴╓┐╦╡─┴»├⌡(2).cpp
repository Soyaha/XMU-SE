#include<iostream>
#include<algorithm>
#include<queue>
using namespace std;

int m,n,tx,ty,a,b,day;
char map[151][151];
int dit[8][2]={{1,-2},{1,2},{-1,2},{-1,-2},{2,1},{2,-1},{-2,1},{-2,-1}};
struct node
{
	int x;
	int y;
	int day;
};

void f(int x,int y,int day)
{
    queue<node>q;
	node k({x,y,day});
	q.push(k);
	while(!q.empty())
	{
		node t=q.front();
		if(t.x==a&&t.y==b)
		{
			cout<<t.day<<endl;
			break;
		}
		q.pop();
		for(int i=0;i<8;i++)
		{
			int xx=t.x+dit[i][0];
			int yy=t.y+dit[i][1];
			int tday=t.day+1;
			if(xx>=1&&yy>=1&&xx<=n&&yy<=m&&map[xx][yy]!='*')
			{
				map[xx][yy]='*';
				q.push({xx,yy,tday});
			}
		}
	}
}

int main()
{
	cin>>m>>n;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>map[i][j];
			if(map[i][j]=='K')
			{
				tx=i;
				ty=j;
			}
			if(map[i][j]=='H')
			{
				a=i;
				b=j;
			}
		}
	}
	f(tx,ty,0);
	return 0;
}
