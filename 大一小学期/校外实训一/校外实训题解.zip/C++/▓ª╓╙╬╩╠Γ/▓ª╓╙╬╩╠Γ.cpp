#include <iostream>
#include <cstring>
#include <functional>
#include <algorithm>

using namespace std;

int oriclocks[9];
int clocks[9];
string moves[9]={"ABDE","ABC","BCEF","ADG","BDEFH","CFI","DEGH","GHI","EFHI"};
int movetimes[9]={0};
int mintimes=1<<30;
int result[9];

void dfs(int n)
{
    if(n>=9)
    {
        memcpy(clocks,oriclocks,sizeof(clocks));
        int times=0;
        for(int i=0;i<9;i++)
        {
            if(movetimes[i])
            {
                for(int k=0;k<moves[i].size();k++)
                {
                    clocks[moves[i][k]-'A']=(clocks[moves[i][k]-'A']+movetimes[i])%4;
                    times += movetimes[i];
                }
            }
        }
        bool flag=true;
        for(int i=0;i<9;i++)
            if(clocks[i])
            {
                flag=false;
                break;
            }
        if(flag&&mintimes>times)
        {
            mintimes=min(mintimes,times);
            memcpy(result,movetimes,sizeof(result));
        }
        return;
    }
    for(int i=0;i<4;i++)
    {
        movetimes[n]=i;
        dfs(n+1);
    }
    return;
}

int main()
{
    for(int i=0;i<9;i++)
        cin>>oriclocks[i];
    dfs(0);
    for(int i=0;i<9;i++)
        for(int k=0;k<result[i];k++)
            cout<<i+1<<' ';
    return 0;
}
