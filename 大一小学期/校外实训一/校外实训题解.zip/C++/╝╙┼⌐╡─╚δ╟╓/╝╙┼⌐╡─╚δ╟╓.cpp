#include<iostream>
#include<algorithm>
#include<queue>
using namespace std;

int m,n,tx,ty,day;
char map[101][101];
int dit[8][2]={{-1,0},{1,0},{0,-1},{0,1},{1,1},{1,-1},{-1,1},{-1,-1}};
struct node
{
	int x;
	int y;
	int day;
};

void f(int x,int y,int day)
{
    queue<node>q;
	node k({x,y,day});
	q.push(k);
	int maxs=0;
	int tday;
	while(!q.empty())
	{
		node t=q.front();
		q.pop();
		for(int i=0;i<8;i++)
		{
			int xx=t.x+dit[i][0];
			int yy=t.y+dit[i][1];
			tday=t.day+1;
			if(xx>=1&&yy>=1&&xx<=n&&yy<=m&&map[xx][yy]!='*')
			{
				map[xx][yy]='*';
				q.push({xx,yy,tday});
				maxs=max(maxs,tday);
			}
		}
	}
	cout<<tday-1<<endl;
}

int main()
{
	cin>>m>>n>>ty>>tx;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
			cin>>map[i][j];
	}
	f(n-tx+1,ty,0);
	return 0;
}
