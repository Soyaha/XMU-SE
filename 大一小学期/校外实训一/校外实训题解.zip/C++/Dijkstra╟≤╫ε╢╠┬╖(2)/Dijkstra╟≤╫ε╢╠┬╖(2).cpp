#include<iostream>
#include<queue>
#include<map>
#define ll long long
using namespace std;

const int maxm=500005,maxn=150005;
struct edge
{
    ll to,dis,next;
}e[maxm];
ll head[maxn],dis[maxn],cnt;
bool vis[maxn];
map<int,int> ma;
ll n,m,s;

void add_adge(ll u,ll v,ll d )
{
    cnt++;
    e[cnt].dis=d;
    e[cnt].to=v;
    e[cnt].next=head[u];
    head[u]=cnt;
}

struct node
{
    ll dis;
    ll pos;
    bool operator<(const node&x) const
    {
        return x.dis<dis;
    }
};

priority_queue<node> q;

void dijkstra()
{
    dis[s]=0;
    q.push((node){0,s});
    while(!q.empty())
    {
        node tmp=q.top();
        q.pop();
        ll x=tmp.pos,d=tmp.dis;
        if(vis[x])
            continue;
        vis[x]=1;
        for(int i=head[x];i;i = e[i].next)
        {
            ll y=e[i].to;
            if(dis[y]>dis[x]+e[i].dis)
            {
                dis[y]=dis[x]+e[i].dis;
                if(!vis[y])
                    q.push((node){dis[y],y});
            }
        }
    }
}

int main()
{
    cin>>n>>m;
    s=1;
    for(int i=1;i<maxn;dis[i++]=0x7fffffff);
    for(int i=1;i<=m;i++)
    {
        ll u,v,d;
        cin>>u>>v>>d;
        if(u!=v)
            add_adge(u,v,d);
    }
    dijkstra();
    if(dis[n]<dis[maxn-1])
        cout<<dis[n];
    else if(dis[n]>=dis[maxn-1])
        cout<<-1;
    return 0;
}
