#include<iostream>
#include<queue>
#include<cstring>
#include<algorithm>
using namespace std;

int n,m;
char area[501][501];
int d[510][510][3];
struct rec
{
	int x,y,z;
}st,ed;
queue<rec>q;

bool valid(int x,int y) {return(x>=0&&x<n&&y>=0&&y<m);}
bool check(rec next)
{
	if(!valid(next.x,next.y)) return 0;
	if(area[next.x][next.y]=='#') return 0;
	if(next.z==0&&area[next.x][next.y]!='.') return 0;
	if(next.z==1&&area[next.x][next.y+1]=='#') return 0;
	if(next.z==2&&area[next.x+1][next.y]=='#') return 0;
	return 1;
}
int dxyz[4][3][3]={{{0,-2,1},{0,-1,0},{0,-1,2}},{{0,1,1},{0,2,0},{0,1,2}},{{-2,0,2},{-1,0,1},{-1,0,0}},{{1,0,2},{1,0,1},{2,0,0}}};

int bfs()
{
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			for(int k=0;k<=2;k++)
				d[i][j][k]=-1;
	while(q.size())
		q.pop();
	d[st.x][st.y][st.z]=0;
	q.push(st);
	while(q.size())
	{
		rec now=q.front();
		q.pop();
		for(int i=0;i<=3;i++)
        {
            rec next;
            next.x=now.x+dxyz[i][now.z][0];
            next.y=now.y+dxyz[i][now.z][1];
            next.z=dxyz[i][now.z][2];
            if(check(next)&&d[next.x][next.y][next.z]==-1)
            {
                d[next.x][next.y][next.z]=d[now.x][now.y][now.z]+1;
                q.push(next);
                if(next.x==ed.x&&next.y==ed.y&&next.z==ed.z)
                    return d[next.x][next.y][next.z];
            }
        }
	}
	return -1;
}

int dx[4]={0,0,1,-1},dy[4]={1,-1,0,0};
int main()
{
	cin>>n>>m;
	while(n!= 0)
	{
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				cin>>area[i][j];
				if(area[i][j]=='X')
				{
					for(int k=0;k<4;k++)
					{
						int x=i+dx[k],y=j+dy[k];
						if(valid(x,y)&&area[x][y]=='X')
						{
							st.x=min(i,x);
							st.y=min(j,y);
							st.z=k<2?1:2;
							area[i][j]=area[x][y]='.';
							break;
						}
						if(area[i][j]=='X')
						{
							st.x=i;
							st.y=j;
							st.z=0;
						}
					}
				}
				if(area[i][j]=='O')
				{
					ed.x=i;
					ed.y=j;
					ed.z=0;
					area[i][j]='.';
				}
			}
		}
		int ans=bfs();
		if(ans==-1) cout<<"Impossible\n";
		else cout<<ans<<endl;
		cin>>n>>m;
	}
	return 0;
}
