#include <iostream>
#include <algorithm>
using namespace std;
typedef long long LL;
const int N = 200010;
struct Seq
{
    int s, e, d;
} seqs[N];
int n;
LL get_sum(int x)
{
    LL res = 0;
    for (int i = 0; i < n; i++)
        if (seqs[i].s <= x)
            res += (min(seqs[i].e, x) - seqs[i].s) / seqs[i].d + 1;
    return res;
}

int main()
{
    int T;
    scanf("%d", &T);
    while (T--)
    {
        int l = 0, r = 0;
        scanf("%d", &n);
        for (int i = 0; i < n; i++)
        {
            int s, e, d;
            scanf("%d%d%d", &s, &e, &d);
            seqs[i] = {s, e, d};
            r = max(r, e);
        }
        while (l < r)
        {
            int mid = l + r >> 1;
            if (get_sum(mid) & 1)
                r = mid;
            else
                l = mid + 1;
        }
        auto sum = get_sum(r) - get_sum(r - 1);
        if (sum % 2)
            cout <<r<<' '<< sum << endl;
        else
            puts("There's no weakness.");
    }
    return 0;
}