#include<cstdio>
#include<iostream>
#include<cmath>
#define esp 1e-7
using namespace std;
double Solve(double target)
{
	double left=-100, right=100;
	double mid=(left+ right)/2;
	double y=mid*mid*mid;
	double d=y-target;
	while(fabs(d)>esp)
	{

		if(d>esp)
		{
			right=mid;
		}
		else if(d<-esp)
		{
			left=mid;
		}
		mid=(left + right)/2;
		y=mid*mid*mid;
		d=y-target;
	}
	return mid;
}
int main()
{
	double y;
	cin>>y;
	printf("%.6lf",Solve(y));
}
