#include<bits/stdc++.h>
using namespace std;

int main()
{
	int n,m;
	cin>>m>>n;
	vector<vector<int>>all(m,vector<int>(n,0));
	queue<int>now;
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%1d",&all[i][j]);
			all[i][j]--;
			if(all[i][j]==0)
			{
				now.push(i);
				now.push(j);
			}
		}
	}
	int d=1;
	while(!now.empty())
	{
		int s=now.size()/2;
		while(s--)
		{
			int i=now.front();
			now.pop();
			int j=now.front();
			now.pop();
			if(i>0&&all[i-1][j]==-1)
			{
				all[i-1][j]=d;
				now.push(i-1);
				now.push(j);
			}
			if(j>0&&all[i][j-1]==-1)
			{
				all[i][j-1]=d;
				now.push(i);
				now.push(j-1);
			}
			if(i<m-1&&all[i+1][j]==-1)
			{
				all[i+1][j]=d;
				now.push(i+1);
				now.push(j);
			}
			if(j<n-1&&all[i][j+1]==-1)
			{
				all[i][j+1]=d;
				now.push(i);
				now.push(j+1);
			}
		}
		d++;
	}
	for(auto as:all)
	{
		for(auto a:as) cout<<a<<" ";
		cout<<endl;
	}
}
