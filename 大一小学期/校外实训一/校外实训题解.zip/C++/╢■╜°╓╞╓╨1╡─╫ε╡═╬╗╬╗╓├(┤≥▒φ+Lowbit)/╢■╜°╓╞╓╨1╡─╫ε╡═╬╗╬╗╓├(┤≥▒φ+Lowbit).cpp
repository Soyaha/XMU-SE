#include <iostream>

using namespace std;
#define N 16
int Log[1<<N];

void build(int n)
{
    for(int i=0;i<=n;i++)
        Log[1<<i]=i;
}

inline int lowbit(int n)
{
    return n&-n;
}
int query(int n)
{
    return Log[lowbit(n)];
}

int main()
{
    build(N);
    int n;
    cin>>n;
    cout<<query(n);
    return 0;
}
