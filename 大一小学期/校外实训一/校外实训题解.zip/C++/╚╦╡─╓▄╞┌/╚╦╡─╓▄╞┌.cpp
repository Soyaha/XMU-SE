#include<iostream>
#include<cstdio>
using namespace std;

int main()
{
    int p,e,i,d,caseNumber=0;
    while(cin>>p>>e>>i>>d&&p!=-1)
    {
        ++caseNumber;
        int k;
        for(k=d+1;k<=d+21252;k++)
            if((k-p)%23==0&&(k-e)%28==0&&(k-i)%33==0)
                cout<<"Case "<<caseNumber<<": the next triple peak occurs in "<<k-d<<" days."<<endl;
    }
    return 0;
}
