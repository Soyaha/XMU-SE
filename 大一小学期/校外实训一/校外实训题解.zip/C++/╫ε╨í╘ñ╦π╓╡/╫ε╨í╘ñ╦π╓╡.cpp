#include <iostream>
#include <algorithm>

using namespace std;

int cost[100005];
int n,m;
int MinCost=1<<32,total=0;

bool isBudgetBigEnough(int mid)
{
    int cnt=1,subtotal=0;
    for(int i=0;i<n;++i)
    {
        if(cost[i]>mid) return false;
        if(cost[i]+subtotal>mid)
        {
            subtotal=cost[i];
            cnt++;
            if(cnt>m)
                return false;
        }
        else subtotal+=cost[i];
    }
    return true;
}

int bsearch_1(int l,int r)
{
    while(l < r)
    {
        int mid=l+r>>1;
        if(isBudgetBigEnough(mid))r=mid;
        else l=mid+1;
    }
    return l;
}
int main()
{
    cin>>n>>m;
    for(int i=0;i<n;i++)
    {
        cin>>cost[i];
        MinCost=min(MinCost,total);
        total+=cost[i];
    }
    cout<<bsearch_1(MinCost,total)<<endl;
    return 0;
}
