# Daily Agent Middleware

基于 DeepSeek 与多 Agent 工作流的日常任务规划中间件系统。

## 后端启动

```bash
cd backend
py -3.10 -m pip install -r requirements.txt
py -3.10 -m uvicorn main:app --reload
```

健康检查：

```text
http://127.0.0.1:8000/api/health
```
