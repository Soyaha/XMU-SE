<template>
  <section class="panel input-panel">
    <div class="panel-header">
      <h2>任务输入</h2>
      <span>自然语言任务</span>
    </div>

    <textarea
      v-model="text"
      :disabled="loading"
      placeholder="例如：帮我规划这周复习高数和英语，每天晚上有2小时，周日想休息半天。"
    />

    <div class="sample-row">
      <button
        v-for="sample in samples"
        :key="sample"
        type="button"
        :disabled="loading"
        @click="text = sample"
      >
        {{ sampleLabel(sample) }}
      </button>
    </div>

    <button
      class="primary-button"
      type="button"
      :disabled="loading || !text.trim()"
      @click="submit"
    >
      {{ loading ? "执行中..." : "启动多 Agent 工作流" }}
    </button>
  </section>
</template>

<script setup>
import { ref } from "vue";

defineProps({
  loading: {
    type: Boolean,
    default: false
  }
});

const emit = defineEmits(["submit-task"]);
const text = ref("");
const samples = [
  "帮我规划这周复习高数和英语，每天晚上有2小时，周日想休息半天。",
  "我周末想去南京玩一天，预算300元，希望路线轻松一点。",
  "预算5000元买一台适合编程和学习的笔记本电脑，帮我分析怎么选。",
  "帮我规划一个中间件课程大作业，要求体现多Agent、工作流和工具调用。"
];

function sampleLabel(sample) {
  if (sample.includes("复习")) return "学习规划";
  if (sample.includes("南京")) return "出行规划";
  if (sample.includes("笔记本")) return "消费决策";
  return "课程作业";
}

function submit() {
  const value = text.value.trim();
  if (value) emit("submit-task", value);
}
</script>

