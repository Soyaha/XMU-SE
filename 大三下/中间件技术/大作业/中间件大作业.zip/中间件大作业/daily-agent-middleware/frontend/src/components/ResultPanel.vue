<template>
  <section class="panel result-panel">
    <div class="panel-header">
      <h2>最终结果</h2>
      <span>{{ task?.task_type || "等待任务" }}</span>
    </div>

    <div v-if="error" class="error-box">{{ error }}</div>
    <div v-else-if="loading" class="empty-state">多 Agent 正在协同处理任务...</div>
    <div v-else-if="!task" class="empty-state">提交一个任务后，这里会展示最终计划。</div>
    <article v-else class="result-content">
      <div class="task-meta">
        <span>任务编号：{{ task.task_id }}</span>
        <span>类型：{{ task.task_type }}</span>
      </div>
      <pre>{{ cleanResult }}</pre>
    </article>
  </section>
</template>

<script setup>
import { computed } from "vue";

const props = defineProps({
  task: {
    type: Object,
    default: null
  },
  loading: {
    type: Boolean,
    default: false
  },
  error: {
    type: String,
    default: ""
  }
});

const cleanResult = computed(() => cleanMarkdown(props.task?.final_result || ""));

function cleanMarkdown(text) {
  return text
    .replace(/\*\*/g, "")
    .replace(/^\s*---\s*$/gm, "")
    .trim();
}
</script>

