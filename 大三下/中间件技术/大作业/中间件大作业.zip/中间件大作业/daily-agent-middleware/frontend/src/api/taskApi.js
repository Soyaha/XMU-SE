const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000/api";

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    },
    ...options
  });

  if (!response.ok) {
    const message = await response.text();
    throw new Error(message || `Request failed with status ${response.status}`);
  }

  return response.json();
}

export function createTask(userInput) {
  return request("/tasks", {
    method: "POST",
    body: JSON.stringify({ user_input: userInput })
  });
}

export function listTasks() {
  return request("/tasks");
}

export function getTask(taskId) {
  return request(`/tasks/${taskId}`);
}
