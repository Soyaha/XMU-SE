<template>
  <main class="app-shell">
    <header class="top-bar">
      <div>
        <p class="eyebrow">DeepSeek + Multi-Agent Middleware</p>
        <h1>日常任务规划智能中间件系统</h1>
      </div>
      <div class="status-pill" :class="{ online: apiStatus === 'ok' }">
        {{ apiStatusText }}
      </div>
    </header>

    <section class="workspace-grid">
      <TaskInput :loading="loading" @submit-task="handleSubmit" />

      <AgentTimeline
        :logs="currentTask?.agent_logs || []"
        :loading="loading"
      />

      <ResultPanel
        :task="currentTask"
        :loading="loading"
        :error="error"
      />
    </section>

    <section class="lower-grid">
      <LogPanel
        :agent-logs="currentTask?.agent_logs || []"
        :tool-logs="currentTask?.tool_logs || []"
        :tasks="tasks"
        @select-task="loadTask"
      />
    </section>
  </main>
</template>

<script setup>
import { computed, onMounted, ref } from "vue";

import { createTask, getTask, listTasks } from "./api/taskApi";
import AgentTimeline from "./components/AgentTimeline.vue";
import LogPanel from "./components/LogPanel.vue";
import ResultPanel from "./components/ResultPanel.vue";
import TaskInput from "./components/TaskInput.vue";

const loading = ref(false);
const error = ref("");
const currentTask = ref(null);
const tasks = ref([]);
const apiStatus = ref("checking");

const apiStatusText = computed(() => {
  if (apiStatus.value === "ok") return "后端已连接";
  if (apiStatus.value === "error") return "后端未连接";
  return "连接检查中";
});

async function refreshTasks() {
  tasks.value = await listTasks();
}

async function handleSubmit(userInput) {
  loading.value = true;
  error.value = "";
  currentTask.value = null;

  try {
    currentTask.value = await createTask(userInput);
    await refreshTasks();
  } catch (err) {
    error.value = err.message || "任务执行失败";
  } finally {
    loading.value = false;
  }
}

async function loadTask(taskId) {
  loading.value = true;
  error.value = "";

  try {
    currentTask.value = await getTask(taskId);
  } catch (err) {
    error.value = err.message || "历史任务加载失败";
  } finally {
    loading.value = false;
  }
}

onMounted(async () => {
  try {
    await refreshTasks();
    apiStatus.value = "ok";
    if (tasks.value.length > 0) {
      await loadTask(tasks.value[0].task_id);
    }
  } catch {
    apiStatus.value = "error";
  }
});
</script>

