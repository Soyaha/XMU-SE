<template>
  <section class="panel timeline-panel">
    <div class="panel-header">
      <h2>Agent 工作流</h2>
      <span>{{ loading ? "运行中" : "执行轨迹" }}</span>
    </div>

    <ol class="timeline">
      <li
        v-for="agent in agents"
        :key="agent.name"
        :class="{
          active: hasSuccess(agent.name),
          processing: loading && !hasSuccess(agent.name)
        }"
      >
        <div class="timeline-marker">{{ agent.index }}</div>
        <div>
          <strong>{{ agent.name }}</strong>
          <p>{{ agent.desc }}</p>
          <small>{{ statusText(agent.name) }}</small>
        </div>
      </li>
    </ol>
  </section>
</template>

<script setup>
const props = defineProps({
  logs: {
    type: Array,
    default: () => []
  },
  loading: {
    type: Boolean,
    default: false
  }
});

const agents = [
  { index: 1, name: "PlannerAgent", desc: "任务理解与步骤拆解" },
  { index: 2, name: "InfoAgent", desc: "背景信息与约束补充" },
  { index: 3, name: "ExecutorAgent", desc: "生成具体可执行方案" },
  { index: 4, name: "ReviewerAgent", desc: "合理性与完整性审查" },
  { index: 5, name: "FormatterAgent", desc: "整理最终输出格式" }
];

function latestLog(agentName) {
  return [...props.logs].reverse().find((log) => log.agent === agentName);
}

function hasSuccess(agentName) {
  return props.logs.some((log) => log.agent === agentName && log.status === "success");
}

function statusText(agentName) {
  if (props.loading && !hasSuccess(agentName)) return "处理中";

  const log = latestLog(agentName);
  if (!log) return "等待执行";
  if (log.status === "success") return "已完成";
  if (log.status === "running") return "执行中";
  if (log.status === "failed") return "执行失败";
  return log.status;
}
</script>

