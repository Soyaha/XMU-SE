<template>
  <section class="panel log-panel">
    <div class="panel-header">
      <h2>执行日志</h2>
      <span>Agent / Tool</span>
    </div>

    <div class="log-layout">
      <div>
        <h3>历史任务</h3>
        <button
          v-for="task in tasks"
          :key="task.task_id"
          class="history-item"
          type="button"
          @click="$emit('select-task', task.task_id)"
        >
          <strong>{{ task.task_type }}</strong>
          <span>{{ task.user_input }}</span>
        </button>
      </div>

      <div>
        <h3>Agent 日志</h3>
        <div class="agent-tabs">
          <button
            v-for="agent in agents"
            :key="agent"
            type="button"
            :class="{ selected: selectedAgent === agent }"
            @click="selectedAgent = agent"
          >
            {{ agentLabel(agent) }}
          </button>
        </div>

        <div class="agent-detail">
          <div v-if="selectedAgentLogs.length > 0">
            <div
              v-for="(log, index) in selectedAgentLogs"
              :key="`${log.agent}-${index}`"
              class="log-item"
            >
              <strong>{{ log.agent }} · {{ statusLabel(log.status) }}</strong>
              <p>{{ cleanText(log.output_text || "无输出") }}</p>
            </div>
          </div>
          <p v-else class="muted">暂无该 Agent 日志</p>
        </div>
      </div>

      <div>
        <h3>工具调用</h3>
        <div class="scroll-box">
          <div v-for="(log, index) in toolLogs" :key="`${log.tool}-${index}`" class="log-item">
            <strong>{{ log.tool }}</strong>
            <p>{{ trim(log.output_text) }}</p>
          </div>
          <p v-if="toolLogs.length === 0" class="muted">暂无工具日志</p>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup>
import { computed, ref, watch } from "vue";

const props = defineProps({
  agentLogs: {
    type: Array,
    default: () => []
  },
  toolLogs: {
    type: Array,
    default: () => []
  },
  tasks: {
    type: Array,
    default: () => []
  }
});

defineEmits(["select-task"]);

const agents = ["PlannerAgent", "InfoAgent", "ExecutorAgent", "ReviewerAgent", "FormatterAgent"];
const selectedAgent = ref("PlannerAgent");

const selectedAgentLogs = computed(() =>
  props.agentLogs.filter((log) => log.agent === selectedAgent.value)
);

watch(
  () => props.agentLogs,
  () => {
    const firstLog = props.agentLogs.find((log) => log.status === "success");
    if (firstLog && !props.agentLogs.some((log) => log.agent === selectedAgent.value)) {
      selectedAgent.value = firstLog.agent;
    }
  }
);

function trim(text) {
  const cleaned = cleanText(text);
  if (!cleaned) return "无输出";
  return cleaned.length > 160 ? `${cleaned.slice(0, 160)}...` : cleaned;
}

function cleanText(text) {
  if (!text) return "";
  return text.replace(/\*\*/g, "").replace(/^\s*---\s*$/gm, "").trim();
}

function agentLabel(agent) {
  return agent.replace("Agent", "");
}

function statusLabel(status) {
  if (status === "success") return "已完成";
  if (status === "running") return "执行中";
  if (status === "failed") return "失败";
  return status;
}
</script>

