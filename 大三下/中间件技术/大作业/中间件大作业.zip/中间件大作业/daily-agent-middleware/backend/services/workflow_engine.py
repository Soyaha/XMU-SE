from agents import (
    ExecutorAgent,
    FormatterAgent,
    InfoAgent,
    PlannerAgent,
    ReviewerAgent,
)
from schemas import TaskContext
from services.log_service import log_service


class WorkflowEngine:
    """编排多 Agent 执行顺序，是本系统的任务调度中间件。"""

    def __init__(self) -> None:
        self.agents = [
            PlannerAgent(),
            InfoAgent(),
            ExecutorAgent(),
            ReviewerAgent(),
            FormatterAgent(),
        ]

    async def run(self, user_input: str) -> TaskContext:
        context = TaskContext(user_input=user_input)

        for agent in self.agents:
            try:
                context.add_agent_log(
                    agent=agent.name,
                    status="running",
                    input_text=context.user_input,
                    output_text="",
                )
                context = await agent.run(context)
            except Exception as exc:
                context.add_agent_log(
                    agent=agent.name,
                    status="failed",
                    input_text=context.user_input,
                    output_text=str(exc),
                )
                raise

        log_service.save_task_context(context)
        return context


workflow_engine = WorkflowEngine()
