import json

from sqlalchemy.orm import Session

from database import SessionLocal
from models import AgentLogRecord, TaskRecord, ToolLogRecord
from schemas import TaskContext


class LogService:
    def save_task_context(self, context: TaskContext) -> None:
        db = SessionLocal()
        try:
            self._save_task(db, context)
            self._save_agent_logs(db, context)
            self._save_tool_logs(db, context)
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def _save_task(self, db: Session, context: TaskContext) -> None:
        existing = (
            db.query(TaskRecord)
            .filter(TaskRecord.task_id == context.task_id)
            .one_or_none()
        )

        payload = {
            "task_id": context.task_id,
            "user_input": context.user_input,
            "task_type": context.task_type,
            "plan_json": json.dumps(context.plan, ensure_ascii=False),
            "info": context.info,
            "draft_result": context.draft_result,
            "review_result": context.review_result,
            "final_result": context.final_result,
            "intermediate_results_json": json.dumps(
                context.intermediate_results,
                ensure_ascii=False,
                default=str,
            ),
            "created_at": context.created_at,
        }

        if existing is None:
            db.add(TaskRecord(**payload))
            return

        for key, value in payload.items():
            setattr(existing, key, value)

    def _save_agent_logs(self, db: Session, context: TaskContext) -> None:
        db.query(AgentLogRecord).filter(
            AgentLogRecord.task_id == context.task_id
        ).delete()

        for log in context.agent_logs:
            db.add(
                AgentLogRecord(
                    task_id=context.task_id,
                    agent_name=log.agent,
                    status=log.status,
                    input_text=log.input_text,
                    output_text=log.output_text,
                    created_at=log.created_at,
                )
            )

    def _save_tool_logs(self, db: Session, context: TaskContext) -> None:
        db.query(ToolLogRecord).filter(
            ToolLogRecord.task_id == context.task_id
        ).delete()

        for log in context.tool_logs:
            db.add(
                ToolLogRecord(
                    task_id=context.task_id,
                    tool_name=log.tool,
                    input_text=log.input_text,
                    output_text=log.output_text,
                    created_at=log.created_at,
                )
            )


log_service = LogService()

