from agents.base_agent import BaseAgent
from schemas import TaskContext
from services.llm_service import llm_service
from tools import default_tool_registry


class ExecutorAgent(BaseAgent):
    name = "ExecutorAgent"
    description = "根据规划步骤和补充信息生成具体可执行方案。"

    async def run(self, context: TaskContext) -> TaskContext:
        time_tool = default_tool_registry.get_tool("time_plan_tool")
        time_result = time_tool.run(context.user_input)
        context.intermediate_results["time_plan_tool_output"] = time_result
        context.add_tool_log(
            tool=time_tool.name,
            input_text=context.user_input,
            output_text=str(time_result),
        )

        system_prompt = (
            "你是日常任务规划系统中的 ExecutorAgent。"
            "请根据用户任务、规划步骤和背景提醒，生成具体、可执行、生活化的方案。"
            "输出应包含：总体思路、具体步骤、时间或优先级安排、注意事项。"
        )
        user_prompt = (
            f"用户任务：{context.user_input}\n"
            f"任务类型：{context.task_type}\n"
            f"规划步骤：\n{chr(10).join(context.plan)}\n"
            f"背景提醒：{context.info}\n"
            f"时间工具结果：{time_result}"
        )

        try:
            output = await llm_service.chat(system_prompt, user_prompt)
        except Exception as exc:
            output = self._fallback_execute(context, exc)

        context.draft_result = output
        context.intermediate_results["executor_output"] = output
        context.add_agent_log(
            agent=self.name,
            status="success",
            input_text=user_prompt,
            output_text=output,
        )
        return context

    def _fallback_execute(self, context: TaskContext, exc: Exception) -> str:
        steps = "\n".join(context.plan)
        return (
            f"## 初步执行方案\n\n"
            f"任务类型：{context.task_type}\n\n"
            f"### 规划步骤\n{steps}\n\n"
            f"### 执行建议\n"
            f"1. 先确认任务目标和最重要的限制条件。\n"
            f"2. 按照规划步骤从前到后执行，每完成一步记录结果。\n"
            f"3. 对时间、预算或精力消耗较大的步骤设置缓冲。\n"
            f"4. 最后进行复盘，检查是否达成用户目标。\n\n"
            f"### 背景提醒\n{context.info}\n\n"
            f"备注：DeepSeek 调用暂不可用，已使用本地执行模板。错误信息：{exc}"
        )
