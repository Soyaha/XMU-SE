from agents.base_agent import BaseAgent
from schemas import TaskContext


class InfoAgent(BaseAgent):
    name = "InfoAgent"
    description = "根据任务类型补充背景信息、约束和注意事项。"

    async def run(self, context: TaskContext) -> TaskContext:
        info = self._build_info(context.task_type)
        context.info = info
        context.intermediate_results["info_output"] = info
        context.add_agent_log(
            agent=self.name,
            status="success",
            input_text=context.task_type,
            output_text=info,
        )
        return context

    def _build_info(self, task_type: str) -> str:
        info_map = {
            "学习规划": (
                "学习规划需要控制每日任务量，建议保留复盘时间和缓冲时间；"
                "高强度学习内容适合放在精力较好的时间段。"
            ),
            "出行规划": (
                "出行规划需要关注交通时间、预算、体力消耗、天气变化和返程安排；"
                "路线不宜过满，应保留机动时间。"
            ),
            "消费决策": (
                "消费决策应先明确预算、核心使用场景、必须参数和可放弃参数；"
                "同时关注售后、扩展性和长期使用成本。"
            ),
            "健康生活": (
                "健康生活计划应避免过激目标，关注规律性、可坚持性和安全性；"
                "饮食、运动和睡眠需要一起考虑。"
            ),
            "课程作业": (
                "课程作业需要明确题目、技术路线、实现模块、演示流程、截图材料和报告结构；"
                "如果涉及中间件课程，应突出封装、调度、透明性、互操作性和可扩展性。"
            ),
        }
        return info_map.get(
            task_type,
            "通用任务需要先明确目标、限制条件、执行步骤、风险点和最终交付物。",
        )

