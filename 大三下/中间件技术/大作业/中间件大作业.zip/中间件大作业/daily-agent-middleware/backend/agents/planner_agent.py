from agents.base_agent import BaseAgent
from schemas import TaskContext
from services.llm_service import llm_service
from tools import default_tool_registry


class PlannerAgent(BaseAgent):
    name = "PlannerAgent"
    description = "理解用户任务，识别任务类型，并拆解执行步骤。"

    async def run(self, context: TaskContext) -> TaskContext:
        keyword_tool = default_tool_registry.get_tool("keyword_tool")
        keyword_result = keyword_tool.run(context.user_input)
        task_type = str(keyword_result["task_type"])
        context.task_type = task_type
        context.add_tool_log(
            tool=keyword_tool.name,
            input_text=context.user_input,
            output_text=str(keyword_result),
        )

        system_prompt = (
            "你是日常任务规划系统中的 PlannerAgent。"
            "请识别用户任务类型，并把任务拆成5到7个清晰步骤。"
            "输出要求：第一行写任务类型，后面用编号列表输出步骤。"
        )
        user_prompt = f"用户任务：{context.user_input}\n初步识别任务类型：{task_type}"

        try:
            output = await llm_service.chat(system_prompt, user_prompt)
        except Exception as exc:
            output = self._fallback_plan(context.user_input, task_type, exc)

        context.plan = self._extract_plan(output)
        context.intermediate_results["planner_output"] = output
        context.add_agent_log(
            agent=self.name,
            status="success",
            input_text=context.user_input,
            output_text=output,
        )
        return context

    def _extract_plan(self, output: str) -> list[str]:
        plan: list[str] = []
        for line in output.splitlines():
            cleaned = line.strip()
            if not cleaned:
                continue
            if cleaned[0].isdigit() or cleaned.startswith(("-", "一", "二", "三", "四", "五", "六", "七")):
                plan.append(cleaned)

        if plan:
            return plan
        return [
            "1. 明确用户目标和限制条件",
            "2. 拆解任务为多个可执行步骤",
            "3. 补充必要背景信息和注意事项",
            "4. 生成具体执行方案",
            "5. 审查方案并给出优化建议",
        ]

    def _fallback_plan(self, user_input: str, task_type: str, exc: Exception) -> str:
        return (
            f"任务类型：{task_type}\n"
            "1. 明确用户输入中的目标、时间、预算和限制条件。\n"
            "2. 将任务拆分为若干个可执行子任务。\n"
            "3. 根据任务类型补充必要背景提醒。\n"
            "4. 生成具体的执行计划或决策建议。\n"
            "5. 检查计划是否可落地、是否遗漏关键步骤。\n"
            "6. 整理为用户容易阅读的最终结果。\n"
            f"备注：DeepSeek 调用暂不可用，已使用本地规划模板。错误信息：{exc}"
        )
