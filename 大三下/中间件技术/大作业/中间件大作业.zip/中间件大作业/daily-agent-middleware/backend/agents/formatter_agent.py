from agents.base_agent import BaseAgent
from schemas import TaskContext
from services.llm_service import llm_service


class FormatterAgent(BaseAgent):
    name = "FormatterAgent"
    description = "整合前面 Agent 的结果，输出清晰易读的最终方案。"

    async def run(self, context: TaskContext) -> TaskContext:
        system_prompt = (
            "你是日常任务规划系统中的 FormatterAgent。"
            "请把方案草稿和审查意见整合为一份清晰、完整、适合直接执行的最终结果。"
            "输出结构：任务摘要、执行计划、风险提醒、下一步行动。"
        )
        user_prompt = (
            f"用户任务：{context.user_input}\n"
            f"任务类型：{context.task_type}\n"
            f"方案草稿：\n{context.draft_result}\n"
            f"审查意见：\n{context.review_result}"
        )

        try:
            output = await llm_service.chat(system_prompt, user_prompt)
        except Exception as exc:
            output = self._fallback_format(context, exc)

        context.final_result = output
        context.intermediate_results["formatter_output"] = output
        context.add_agent_log(
            agent=self.name,
            status="success",
            input_text=user_prompt,
            output_text=output,
        )
        return context

    def _fallback_format(self, context: TaskContext, exc: Exception) -> str:
        return (
            f"## 任务摘要\n\n"
            f"用户任务：{context.user_input}\n\n"
            f"任务类型：{context.task_type}\n\n"
            f"## 执行计划\n\n"
            f"{context.draft_result}\n\n"
            f"## 风险提醒\n\n"
            f"{context.review_result}\n\n"
            f"## 下一步行动\n\n"
            f"1. 根据最终计划开始执行第一步。\n"
            f"2. 执行过程中记录实际完成情况。\n"
            f"3. 如果任务条件发生变化，重新提交任务生成新计划。\n\n"
            f"备注：DeepSeek 调用暂不可用，已使用本地格式化模板。错误信息：{exc}"
        )

