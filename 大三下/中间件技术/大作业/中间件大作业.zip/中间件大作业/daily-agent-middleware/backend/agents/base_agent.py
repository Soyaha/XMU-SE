from schemas import TaskContext


class BaseAgent:
    name = "BaseAgent"
    description = "Agent base class"

    async def run(self, context: TaskContext) -> TaskContext:
        raise NotImplementedError("Agent subclasses must implement run().")

