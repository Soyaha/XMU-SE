from agents.base_agent import BaseAgent
from schemas import TaskContext
from services.llm_service import llm_service
from tools import default_tool_registry


class ReviewerAgent(BaseAgent):
    name = "ReviewerAgent"
    description = "审查方案是否合理、完整、可执行。"

    async def run(self, context: TaskContext) -> TaskContext:
        requirement_result = None
        report_outline = None
        if context.task_type == "课程作业" or "中间件" in context.user_input:
            requirement_tool = default_tool_registry.get_tool("requirement_check_tool")
            requirement_result = requirement_tool.run(context.draft_result)
            context.intermediate_results["requirement_check_tool_output"] = requirement_result
            context.add_tool_log(
                tool=requirement_tool.name,
                input_text=context.draft_result,
                output_text=str(requirement_result),
            )

            outline_tool = default_tool_registry.get_tool("report_outline_tool")
            report_outline = outline_tool.run(context.draft_result)
            context.intermediate_results["report_outline_tool_output"] = report_outline
            context.add_tool_log(
                tool=outline_tool.name,
                input_text=context.draft_result,
                output_text=str(report_outline),
            )

        system_prompt = (
            "你是日常任务规划系统中的 ReviewerAgent。"
            "请审查方案是否可执行、是否过于空泛、是否遗漏关键步骤、是否符合用户目标。"
            "如果任务属于课程作业，还要检查是否体现中间件思想、多Agent、工作流和工具调用。"
            "输出应包含：总体评价、发现的问题、修改建议。"
        )
        user_prompt = (
            f"用户任务：{context.user_input}\n"
            f"任务类型：{context.task_type}\n"
            f"方案草稿：\n{context.draft_result}\n"
            f"课程要求检查结果：{requirement_result}\n"
            f"报告大纲工具结果：{report_outline}"
        )

        try:
            output = await llm_service.chat(system_prompt, user_prompt)
        except Exception as exc:
            output = self._fallback_review(context, exc)

        context.review_result = output
        context.intermediate_results["reviewer_output"] = output
        context.add_agent_log(
            agent=self.name,
            status="success",
            input_text=user_prompt,
            output_text=output,
        )
        return context

    def _fallback_review(self, context: TaskContext, exc: Exception) -> str:
        checks = [
            "方案已经包含任务拆解和执行建议。",
            "需要确认用户的时间、预算或其他限制条件是否足够明确。",
            "建议在最终输出中加入风险提醒和下一步行动。",
        ]
        if context.task_type == "课程作业":
            checks.extend(
                [
                    "课程作业类任务需要突出中间件的封装性、透明性和可扩展性。",
                    "建议展示 Agent 调度、工作流编排和工具调用日志。",
                ]
            )

        return (
            "## 审查结果\n\n"
            "总体评价：方案基本可执行，但仍需要在最终结果中进一步结构化展示。\n\n"
            "### 检查意见\n"
            + "\n".join(f"- {item}" for item in checks)
            + f"\n\n备注：DeepSeek 调用暂不可用，已使用本地审查模板。错误信息：{exc}"
        )
