from tools.base_tool import BaseTool


class RequirementCheckTool(BaseTool):
    name = "requirement_check_tool"
    description = "Check whether a course-project answer covers middleware requirements."

    def run(self, input_data: str) -> dict[str, object]:
        text = input_data or ""
        requirements = {
            "题目定位": ["题目", "项目", "系统"],
            "中间件思想": ["中间件", "封装", "透明", "互操作", "可扩展"],
            "多Agent": ["Agent", "agent", "Planner", "Reviewer", "Executor"],
            "工作流": ["工作流", "流程", "调度", "编排"],
            "工具调用": ["工具", "Tool", "tool", "注册"],
            "演示与截图": ["演示", "截图", "运行", "日志"],
        }

        details = []
        missing = []
        for item, keywords in requirements.items():
            hit_keywords = [keyword for keyword in keywords if keyword in text]
            passed = bool(hit_keywords)
            details.append(
                {
                    "item": item,
                    "passed": passed,
                    "matched_keywords": hit_keywords,
                }
            )
            if not passed:
                missing.append(item)

        return {
            "passed": len(missing) == 0,
            "missing": missing,
            "details": details,
            "summary": "课程要求覆盖完整。" if not missing else f"仍需补充：{', '.join(missing)}。",
        }

