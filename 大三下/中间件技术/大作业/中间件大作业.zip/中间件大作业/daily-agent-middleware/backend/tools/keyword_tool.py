from tools.base_tool import BaseTool


class KeywordTool(BaseTool):
    name = "keyword_tool"
    description = "Detect task type by matching common daily-task keywords."

    def run(self, input_data: str) -> dict[str, object]:
        text = input_data or ""
        lowered = text.lower()
        keyword_groups = [
            ("课程作业", ["作业", "大作业", "课程设计", "实验", "中间件"]),
            ("学习规划", ["学习", "复习", "考试", "高数", "英语", "课程"]),
            ("出行规划", ["旅游", "出行", "旅行", "路线", "景点", "周末"]),
            ("消费决策", ["购买", "预算", "电脑", "手机", "怎么选", "比较"]),
            ("健康生活", ["饮食", "运动", "减脂", "睡眠", "健康"]),
        ]

        for task_type, keywords in keyword_groups:
            matched = [
                keyword
                for keyword in keywords
                if keyword in lowered or keyword in text
            ]
            if matched:
                return {
                    "task_type": task_type,
                    "matched_keywords": matched,
                    "confidence": "high",
                }

        return {
            "task_type": "通用任务",
            "matched_keywords": [],
            "confidence": "low",
        }

