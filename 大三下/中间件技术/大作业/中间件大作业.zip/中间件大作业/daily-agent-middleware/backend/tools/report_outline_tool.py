from tools.base_tool import BaseTool


class ReportOutlineTool(BaseTool):
    name = "report_outline_tool"
    description = "Generate a report outline for course-project tasks."

    def run(self, input_data: str) -> list[str]:
        return [
            "1. 项目背景与需求分析",
            "2. 中间件课程知识点对应关系",
            "3. 系统总体架构设计",
            "4. 多 Agent 工作流设计",
            "5. DeepSeek 大模型服务封装",
            "6. ToolRegistry 工具注册与调用机制",
            "7. 系统实现与关键代码说明",
            "8. 运行结果、日志与截图展示",
            "9. 问题分析与改进方向",
            "10. 总结",
        ]

