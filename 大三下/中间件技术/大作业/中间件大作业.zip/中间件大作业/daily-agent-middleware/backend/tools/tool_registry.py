from tools.base_tool import BaseTool
from tools.keyword_tool import KeywordTool
from tools.report_outline_tool import ReportOutlineTool
from tools.requirement_check_tool import RequirementCheckTool
from tools.time_plan_tool import TimePlanTool


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, BaseTool] = {}

    def register(self, tool: BaseTool) -> None:
        self._tools[tool.name] = tool

    def get_tool(self, name: str) -> BaseTool:
        if name not in self._tools:
            raise KeyError(f"Tool not registered: {name}")
        return self._tools[name]

    def list_tools(self) -> list[dict[str, str]]:
        return [
            {"name": tool.name, "description": tool.description}
            for tool in self._tools.values()
        ]


def create_default_tool_registry() -> ToolRegistry:
    registry = ToolRegistry()
    registry.register(KeywordTool())
    registry.register(TimePlanTool())
    registry.register(RequirementCheckTool())
    registry.register(ReportOutlineTool())
    return registry


default_tool_registry = create_default_tool_registry()

