from typing import Any


class BaseTool:
    name = "base_tool"
    description = "Tool base class"

    def run(self, input_data: Any) -> Any:
        raise NotImplementedError("Tool subclasses must implement run().")

