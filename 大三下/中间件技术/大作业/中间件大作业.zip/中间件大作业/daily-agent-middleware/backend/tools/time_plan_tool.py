import re

from tools.base_tool import BaseTool


class TimePlanTool(BaseTool):
    name = "time_plan_tool"
    description = "Create simple time blocks from daily available hours."

    def run(self, input_data: str) -> dict[str, object]:
        text = input_data or ""
        hours = self._extract_hours(text)
        if hours is None:
            return {
                "detected": False,
                "suggestion": "未识别到明确每日可用时长，建议用户补充时间限制。",
                "blocks": [],
            }

        if hours <= 1:
            blocks = ["完整专注块：45-50分钟", "复盘：10分钟"]
        elif hours <= 2:
            blocks = ["任务块A：50分钟", "休息：10分钟", "任务块B：50分钟", "复盘：10分钟"]
        else:
            blocks = [
                "任务块A：60分钟",
                "休息：10分钟",
                "任务块B：60分钟",
                "休息：10分钟",
                "任务块C或复盘：40-60分钟",
            ]

        return {
            "detected": True,
            "hours": hours,
            "suggestion": f"识别到每日约 {hours:g} 小时，可拆成稳定时间块执行。",
            "blocks": blocks,
        }

    def _extract_hours(self, text: str) -> float | None:
        patterns = [
            r"每天.*?(\d+(?:\.\d+)?)\s*小时",
            r"每日.*?(\d+(?:\.\d+)?)\s*小时",
            r"(\d+(?:\.\d+)?)\s*小时",
            r"(\d+(?:\.\d+)?)\s*h",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, flags=re.IGNORECASE)
            if match:
                return float(match.group(1))
        return None

