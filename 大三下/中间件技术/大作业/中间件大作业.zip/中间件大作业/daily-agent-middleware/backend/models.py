from sqlalchemy import Column, DateTime, Integer, Text

from database import Base


class TaskRecord(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Text, unique=True, index=True, nullable=False)
    user_input = Column(Text, nullable=False)
    task_type = Column(Text, nullable=False)
    plan_json = Column(Text, nullable=False, default="[]")
    info = Column(Text, nullable=False, default="")
    draft_result = Column(Text, nullable=False, default="")
    review_result = Column(Text, nullable=False, default="")
    final_result = Column(Text, nullable=False, default="")
    intermediate_results_json = Column(Text, nullable=False, default="{}")
    created_at = Column(DateTime, nullable=False)


class AgentLogRecord(Base):
    __tablename__ = "agent_logs"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Text, index=True, nullable=False)
    agent_name = Column(Text, nullable=False)
    status = Column(Text, nullable=False)
    input_text = Column(Text, nullable=False, default="")
    output_text = Column(Text, nullable=False, default="")
    created_at = Column(DateTime, nullable=False)


class ToolLogRecord(Base):
    __tablename__ = "tool_logs"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Text, index=True, nullable=False)
    tool_name = Column(Text, nullable=False)
    input_text = Column(Text, nullable=False, default="")
    output_text = Column(Text, nullable=False, default="")
    created_at = Column(DateTime, nullable=False)

