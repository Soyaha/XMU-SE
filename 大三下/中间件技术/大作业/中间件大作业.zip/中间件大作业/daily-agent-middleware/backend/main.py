import json

from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from config import settings
from database import get_db, init_database
from models import AgentLogRecord, TaskRecord, ToolLogRecord
from schemas import (
    AgentLogResponse,
    TaskCreateRequest,
    TaskDetailResponse,
    TaskSummaryResponse,
    ToolLogResponse,
)
from services.workflow_engine import workflow_engine


app = FastAPI(
    title="Daily Agent Middleware API",
    description="基于 DeepSeek 与多 Agent 工作流的日常任务规划中间件系统后端",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup_event():
    init_database()


@app.get("/api/health")
def health_check():
    return {
        "status": "ok",
        "service": "daily-agent-middleware",
        "deepseek_model": settings.deepseek_model,
    }


@app.post("/api/tasks", response_model=TaskDetailResponse)
async def create_task(request: TaskCreateRequest):
    context = await workflow_engine.run(request.user_input)
    return _context_to_detail_response(context)


@app.get("/api/tasks", response_model=list[TaskSummaryResponse])
def list_tasks(db: Session = Depends(get_db)):
    records = (
        db.query(TaskRecord)
        .order_by(TaskRecord.created_at.desc())
        .all()
    )
    return [
        TaskSummaryResponse(
            task_id=record.task_id,
            user_input=record.user_input,
            task_type=record.task_type,
            final_result=record.final_result,
            review_result=record.review_result,
            created_at=record.created_at,
        )
        for record in records
    ]


@app.get("/api/tasks/{task_id}", response_model=TaskDetailResponse)
def get_task_detail(task_id: str, db: Session = Depends(get_db)):
    record = (
        db.query(TaskRecord)
        .filter(TaskRecord.task_id == task_id)
        .one_or_none()
    )
    if record is None:
        raise HTTPException(status_code=404, detail="Task not found.")

    agent_logs = (
        db.query(AgentLogRecord)
        .filter(AgentLogRecord.task_id == task_id)
        .order_by(AgentLogRecord.created_at.asc(), AgentLogRecord.id.asc())
        .all()
    )
    tool_logs = (
        db.query(ToolLogRecord)
        .filter(ToolLogRecord.task_id == task_id)
        .order_by(ToolLogRecord.created_at.asc(), ToolLogRecord.id.asc())
        .all()
    )

    return TaskDetailResponse(
        task_id=record.task_id,
        user_input=record.user_input,
        task_type=record.task_type,
        plan=_safe_json_loads(record.plan_json, []),
        info=record.info,
        draft_result=record.draft_result,
        review_result=record.review_result,
        final_result=record.final_result,
        intermediate_results=_safe_json_loads(record.intermediate_results_json, {}),
        agent_logs=[
            AgentLogResponse(
                agent=log.agent_name,
                status=log.status,
                input_text=log.input_text,
                output_text=log.output_text,
                created_at=log.created_at,
            )
            for log in agent_logs
        ],
        tool_logs=[
            ToolLogResponse(
                tool=log.tool_name,
                input_text=log.input_text,
                output_text=log.output_text,
                created_at=log.created_at,
            )
            for log in tool_logs
        ],
        created_at=record.created_at,
    )


def _context_to_detail_response(context) -> TaskDetailResponse:
    return TaskDetailResponse(
        task_id=context.task_id,
        user_input=context.user_input,
        task_type=context.task_type,
        plan=context.plan,
        info=context.info,
        draft_result=context.draft_result,
        review_result=context.review_result,
        final_result=context.final_result,
        intermediate_results=context.intermediate_results,
        agent_logs=[
            AgentLogResponse(
                agent=log.agent,
                status=log.status,
                input_text=log.input_text,
                output_text=log.output_text,
                created_at=log.created_at,
            )
            for log in context.agent_logs
        ],
        tool_logs=[
            ToolLogResponse(
                tool=log.tool,
                input_text=log.input_text,
                output_text=log.output_text,
                created_at=log.created_at,
            )
            for log in context.tool_logs
        ],
        created_at=context.created_at,
    )


def _safe_json_loads(value: str, default):
    try:
        return json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return default
