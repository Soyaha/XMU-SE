from datetime import datetime
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field


class AgentLog(BaseModel):
    agent: str
    status: str = "pending"
    input_text: str = ""
    output_text: str = ""
    created_at: datetime = Field(default_factory=datetime.now)


class ToolLog(BaseModel):
    tool: str
    input_text: str = ""
    output_text: str = ""
    created_at: datetime = Field(default_factory=datetime.now)


class TaskContext(BaseModel):
    task_id: str = Field(default_factory=lambda: str(uuid4()))
    user_input: str
    task_type: str = "通用任务"
    plan: list[str] = Field(default_factory=list)
    info: str = ""
    draft_result: str = ""
    review_result: str = ""
    final_result: str = ""
    intermediate_results: dict[str, Any] = Field(default_factory=dict)
    agent_logs: list[AgentLog] = Field(default_factory=list)
    tool_logs: list[ToolLog] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.now)

    def add_agent_log(
        self,
        agent: str,
        status: str,
        input_text: str = "",
        output_text: str = "",
    ) -> None:
        self.agent_logs.append(
            AgentLog(
                agent=agent,
                status=status,
                input_text=input_text,
                output_text=output_text,
            )
        )

    def add_tool_log(
        self,
        tool: str,
        input_text: str = "",
        output_text: str = "",
    ) -> None:
        self.tool_logs.append(
            ToolLog(
                tool=tool,
                input_text=input_text,
                output_text=output_text,
            )
        )


class TaskCreateRequest(BaseModel):
    user_input: str = Field(min_length=1)


class TaskSummaryResponse(BaseModel):
    task_id: str
    user_input: str
    task_type: str
    final_result: str
    review_result: str
    created_at: datetime


class AgentLogResponse(BaseModel):
    agent: str
    status: str
    input_text: str
    output_text: str
    created_at: datetime


class ToolLogResponse(BaseModel):
    tool: str
    input_text: str
    output_text: str
    created_at: datetime


class TaskDetailResponse(BaseModel):
    task_id: str
    user_input: str
    task_type: str
    plan: list[str]
    info: str
    draft_result: str
    review_result: str
    final_result: str
    intermediate_results: dict[str, Any]
    agent_logs: list[AgentLogResponse]
    tool_logs: list[ToolLogResponse]
    created_at: datetime
