"""
K-Means 聚类算法 — Iris 数据集

从零实现 K-Means 聚类，不依赖 sklearn。使用 Iris 数据集的特征（忽略标签），
通过肘部法（Elbow Method）选择最优 k 值，并用 PCA 降维可视化聚类结果。
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np


# ===================== 参数 =====================
K_RANGE = range(1, 9)  # 肘部法搜索范围
BASE_DIR = Path(__file__).resolve().parent
BP_DIR = BASE_DIR.parent / "反向传播算法"
RANDOM_SEED = 42

CLASS_TO_LABEL = {
    "Iris-setosa": 0,
    "Iris-versicolor": 1,
    "Iris-virginica": 2,
}


# ===================== 数据加载 =====================
def load_features(path: Path) -> np.ndarray:
    """读取 Iris 文件，只返回特征（无标签用于无监督聚类）"""
    features: list[list[float]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(",")
        features.append([float(parts[0]), float(parts[1]), float(parts[2]), float(parts[3])])
    return np.array(features, dtype=float)


def load_labels(path: Path) -> np.ndarray:
    """读取标签（仅用于评估聚类效果）"""
    labels: list[int] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        labels.append(CLASS_TO_LABEL[line.split(",")[4]])
    return np.array(labels, dtype=int)


def standardize(data: np.ndarray) -> np.ndarray:
    """Z-score 标准化"""
    mean = data.mean(axis=0)
    std = data.std(axis=0)
    std[std == 0] = 1.0
    return (data - mean) / std


# ===================== K-Means 聚类器 =====================
class KMeans:
    """从零实现的 K-Means 聚类算法"""

    def __init__(self, n_clusters: int = 3, max_iters: int = 300, tol: float = 1e-6, seed: int = RANDOM_SEED):
        self.n_clusters = n_clusters
        self.max_iters = max_iters
        self.tol = tol
        self.rng = np.random.default_rng(seed)
        self.centroids: np.ndarray | None = None
        self.labels_: np.ndarray | None = None
        self.inertia_: float = 0.0
        self.n_iter_: int = 0

    def fit(self, x: np.ndarray) -> "KMeans":
        """执行 K-Means 聚类"""
        n_samples, n_features = x.shape

        # 随机初始化质心（K-Means++ 思路：先随机选第一个，再按距离加权选其余）
        first_idx = int(self.rng.choice(n_samples, size=1)[0])
        self.centroids = x[first_idx:first_idx + 1].copy().astype(float)

        for _ in range(1, self.n_clusters):
            # 计算每个点到最近质心的距离平方
            all_dist_sq = np.min(
                np.sum((x[:, np.newaxis, :] - self.centroids[np.newaxis, :, :]) ** 2, axis=2),
                axis=1,
            )
            probs = all_dist_sq / all_dist_sq.sum()
            cumsum = np.cumsum(probs)
            r_val = float(self.rng.random())
            new_idx = int(np.searchsorted(cumsum, r_val))
            new_idx = min(new_idx, n_samples - 1)
            self.centroids = np.vstack([self.centroids, x[new_idx:new_idx + 1]])

        # 迭代优化
        for iteration in range(self.max_iters):
            # 分配：每个样本分配到最近的质心
            distances = np.sqrt(
                np.sum((x[:, np.newaxis, :] - self.centroids[np.newaxis, :, :]) ** 2, axis=2)
            )
            labels = np.argmin(distances, axis=1)

            # 更新质心
            new_centroids = np.array([
                x[labels == c].mean(axis=0) if np.sum(labels == c) > 0 else self.centroids[c]
                for c in range(self.n_clusters)
            ])

            # 检查收敛
            shift = np.sqrt(np.sum((new_centroids - self.centroids) ** 2))
            self.centroids = new_centroids

            if shift < self.tol:
                break

        self.labels_ = labels
        self.n_iter_ = iteration + 1
        # 计算惯性（簇内平方和 SSE）
        self.inertia_ = float(np.sum((x - self.centroids[labels]) ** 2))
        return self

    def predict(self, x: np.ndarray) -> np.ndarray:
        """预测新样本的簇标签"""
        assert self.centroids is not None, "请先调用 fit()"
        distances = np.sqrt(
            np.sum((x[:, np.newaxis, :] - self.centroids[np.newaxis, :, :]) ** 2, axis=2)
        )
        return np.argmin(distances, axis=1)


# ===================== PCA 简易实现 =====================
class SimplePCA:
    """简易 PCA 降维（不依赖 sklearn）"""

    def __init__(self, n_components: int = 2):
        self.n_components = n_components
        self.components_: np.ndarray | None = None
        self.mean_: np.ndarray | None = None

    def fit_transform(self, x: np.ndarray) -> np.ndarray:
        self.mean_ = x.mean(axis=0)
        x_centered = x - self.mean_
        # 协方差矩阵的特征分解
        cov = np.cov(x_centered.T)
        eigenvalues, eigenvectors = np.linalg.eigh(cov)
        # 按特征值降序排列
        idx = np.argsort(eigenvalues)[::-1]
        self.components_ = eigenvectors[:, idx[: self.n_components]]
        return x_centered @ self.components_


# ===================== 评估 =====================
def cluster_accuracy(true_labels: np.ndarray, pred_labels: np.ndarray, n_clusters: int = 3) -> float:
    """
    计算聚类准确率（匈牙利匹配）。
    由于聚类标签是无序的，需要找到最优的标签映射。
    """
    from itertools import permutations

    best_acc = 0.0
    # 对簇标签的所有排列找最优
    for perm in permutations(range(n_clusters)):
        mapped = np.array([perm[p] for p in pred_labels])
        acc = np.mean(mapped == true_labels)
        if acc > best_acc:
            best_acc = acc
    return best_acc


# ===================== 绘图 =====================
def plot_elbow(k_range: range, sse_list: list[float], save_path: Path) -> None:
    """绘制肘部法 SSE 曲线"""
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(list(k_range), sse_list, marker="o", linewidth=2, markersize=8, color="#d62728")
    ax.set_xlabel("Number of Clusters (K)", fontsize=13)
    ax.set_ylabel("Sum of Squared Errors (SSE)", fontsize=13)
    ax.set_title("Elbow Method for Optimal K", fontsize=14)
    ax.set_xticks(list(k_range))
    ax.grid(True, alpha=0.4)

    for k_val, sse in zip(k_range, sse_list):
        ax.annotate(
            f"{sse:.1f}",
            (k_val, sse),
            textcoords="offset points",
            xytext=(0, 12),
            ha="center",
            fontsize=8,
        )

    fig.tight_layout()
    fig.savefig(save_path, dpi=200)
    plt.close(fig)
    print(f"肘部法曲线已保存: {save_path}")


def plot_clusters(
    x_2d: np.ndarray,
    pred_labels: np.ndarray,
    true_labels: np.ndarray,
    centroids_2d: np.ndarray,
    save_path: Path,
) -> None:
    """绘制聚类结果与真实标签对比"""
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    colors = ["#1f77b4", "#ff7f0e", "#2ca02c"]
    cluster_names = ["Cluster 0", "Cluster 1", "Cluster 2"]
    class_names = ["Setosa", "Versicolor", "Virginica"]

    # 左图：K-Means 聚类结果
    ax = axes[0]
    for c in range(3):
        mask = pred_labels == c
        ax.scatter(
            x_2d[mask, 0], x_2d[mask, 1],
            c=colors[c], label=cluster_names[c], alpha=0.7, edgecolors="k", linewidth=0.5, s=50,
        )
    ax.scatter(
        centroids_2d[:, 0], centroids_2d[:, 1],
        c="red", marker="X", s=200, edgecolors="black", linewidth=1.5, label="Centroids", zorder=5,
    )
    ax.set_title("K-Means Clustering Result", fontsize=13)
    ax.set_xlabel("PC 1")
    ax.set_ylabel("PC 2")
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)

    # 右图：真实标签
    ax = axes[1]
    for c in range(3):
        mask = true_labels == c
        ax.scatter(
            x_2d[mask, 0], x_2d[mask, 1],
            c=colors[c], label=class_names[c], alpha=0.7, edgecolors="k", linewidth=0.5, s=50,
        )
    ax.set_title("Ground Truth Labels", fontsize=13)
    ax.set_xlabel("PC 1")
    ax.set_ylabel("PC 2")
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)

    fig.tight_layout()
    fig.savefig(save_path, dpi=200)
    plt.close(fig)
    print(f"聚类结果图已保存: {save_path}")


# ===================== 主流程 =====================
def main() -> None:
    # 1. 加载 & 标准化（使用全部 150 条 Iris 数据）
    features = load_features(BP_DIR / "Iris.txt.txt")
    true_labels = load_labels(BP_DIR / "Iris.txt.txt")
    features = standardize(features)

    print("=" * 60)
    print("K-Means 聚类 — Iris 数据集")
    print(f"样本数: {len(features)}  |  特征数: {features.shape[1]}")
    print(f"真实类别: 3 (Setosa / Versicolor / Virginica)")
    print("=" * 60)

    # 2. 肘部法：搜索最优 k
    print("\n[肘部法] 搜索 K = 1~8 的 SSE:")
    sse_list: list[float] = []
    for k_val in K_RANGE:
        km = KMeans(n_clusters=k_val, seed=RANDOM_SEED)
        km.fit(features)
        sse_list.append(km.inertia_)
        print(f"  K = {k_val}  →  SSE = {km.inertia_:.2f}  (迭代 {km.n_iter_} 次)")

    # 3. 使用 k=3 进行最终聚类
    print("\n[聚类] 使用 K = 3 进行最终聚类:")
    km3 = KMeans(n_clusters=3, seed=RANDOM_SEED)
    km3.fit(features)
    print(f"  迭代次数: {km3.n_iter_}")
    print(f"  最终 SSE: {km3.inertia_:.2f}")
    print(f"  各簇样本数: {[int(np.sum(km3.labels_ == c)) for c in range(3)]}")

    # 4. 评估
    acc = cluster_accuracy(true_labels, km3.labels_, n_clusters=3)
    print(f"\n  聚类准确率 (最优标签匹配): {acc:.4f}")

    # 5. 可视化
    # PCA 降维
    pca = SimplePCA(n_components=2)
    features_2d = pca.fit_transform(features)
    centroids_2d = (km3.centroids - pca.mean_) @ pca.components_

    plot_elbow(K_RANGE, sse_list, BASE_DIR / "kmeans_elbow.png")
    plot_clusters(features_2d, km3.labels_, true_labels, centroids_2d, BASE_DIR / "kmeans_clusters.png")

    # 6. 簇中心与类别对应
    print("\n[簇与真实类别的对应关系]")
    for c in range(3):
        mask = km3.labels_ == c
        true_in_cluster = true_labels[mask]
        counts = np.bincount(true_in_cluster, minlength=3)
        dominant = np.argmax(counts)
        class_names = ["Setosa", "Versicolor", "Virginica"]
        print(f"  Cluster {c}: {counts[0]} Setosa, {counts[1]} Versicolor, {counts[2]} Virginica  →  主要: {class_names[dominant]}")


if __name__ == "__main__":
    main()
