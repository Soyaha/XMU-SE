import random
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np


random.seed(42)
np.random.seed(42)


def generate_cities(
    num_cities: int,
    x_range: tuple[int, int] = (0, 100),
    y_range: tuple[int, int] = (0, 100),
) -> np.ndarray:
    """Generate random TSP city coordinates."""
    xs = np.random.uniform(x_range[0], x_range[1], num_cities)
    ys = np.random.uniform(y_range[0], y_range[1], num_cities)
    return np.column_stack((xs, ys))


def build_distance_matrix(cities: np.ndarray) -> np.ndarray:
    """Pre-compute pairwise Euclidean distances."""
    diff = cities[:, None, :] - cities[None, :, :]
    return np.sqrt(np.sum(diff * diff, axis=2))


@dataclass
class PSOParams:
    num_particles: int = 60
    iterations: int = 400
    inertia_max: float = 0.9
    inertia_min: float = 0.4
    cognitive_coeff: float = 1.7
    social_coeff: float = 1.7
    vmax: float = 0.2


class PSOTSP:
    def __init__(self, cities: np.ndarray, params: PSOParams | None = None):
        self.cities = cities
        self.n_cities = len(cities)
        self.params = params or PSOParams()
        self.distance_matrix = build_distance_matrix(cities)
        self.positions = np.random.rand(self.params.num_particles, self.n_cities)
        self.velocities = np.random.uniform(
            -self.params.vmax,
            self.params.vmax,
            size=(self.params.num_particles, self.n_cities),
        )
        self.best_route: list[int] | None = None
        self.best_distance = float("inf")
        self.history: list[float] = []

    def decode_route(self, position: np.ndarray) -> list[int]:
        """Convert a particle position to a TSP permutation by sorting."""
        return list(np.argsort(position, kind="mergesort"))

    def route_distance(self, route: list[int]) -> float:
        total = 0.0
        for index in range(len(route)):
            start_city = route[index]
            end_city = route[(index + 1) % len(route)]
            total += self.distance_matrix[start_city, end_city]
        return total

    def optimize(self) -> tuple[list[int], float]:
        pbest_positions = self.positions.copy()
        pbest_distances = np.array(
            [self.route_distance(self.decode_route(position)) for position in pbest_positions],
            dtype=float,
        )

        gbest_index = int(np.argmin(pbest_distances))
        gbest_position = pbest_positions[gbest_index].copy()
        gbest_distance = float(pbest_distances[gbest_index])

        for iteration in range(self.params.iterations):
            if self.params.iterations == 1:
                inertia_weight = self.params.inertia_min
            else:
                ratio = iteration / (self.params.iterations - 1)
                inertia_weight = self.params.inertia_max - (self.params.inertia_max - self.params.inertia_min) * ratio

            for particle_index in range(self.params.num_particles):
                r1 = np.random.rand(self.n_cities)
                r2 = np.random.rand(self.n_cities)

                self.velocities[particle_index] = (
                    inertia_weight * self.velocities[particle_index]
                    + self.params.cognitive_coeff
                    * r1
                    * (pbest_positions[particle_index] - self.positions[particle_index])
                    + self.params.social_coeff * r2 * (gbest_position - self.positions[particle_index])
                )
                self.velocities[particle_index] = np.clip(
                    self.velocities[particle_index],
                    -self.params.vmax,
                    self.params.vmax,
                )

                self.positions[particle_index] = np.clip(
                    self.positions[particle_index] + self.velocities[particle_index],
                    0.0,
                    1.0,
                )

                current_route = self.decode_route(self.positions[particle_index])
                current_distance = self.route_distance(current_route)

                if current_distance < pbest_distances[particle_index]:
                    pbest_distances[particle_index] = current_distance
                    pbest_positions[particle_index] = self.positions[particle_index].copy()

            gbest_index = int(np.argmin(pbest_distances))
            if pbest_distances[gbest_index] < gbest_distance:
                gbest_distance = float(pbest_distances[gbest_index])
                gbest_position = pbest_positions[gbest_index].copy()

            self.history.append(gbest_distance)

            if (iteration + 1) % 50 == 0:
                print(f"Iteration {iteration + 1}: best distance = {gbest_distance:.4f}")

        self.best_route = self.decode_route(gbest_position)
        self.best_distance = gbest_distance
        return self.best_route, self.best_distance

    def plot_result(self, output_dir: Path | None = None) -> Path | None:
        if self.best_route is None:
            return None

        best_route = self.best_route + [self.best_route[0]]
        route_cities = self.cities[best_route]

        fig, axes = plt.subplots(1, 2, figsize=(13, 5))

        axes[0].scatter(self.cities[:, 0], self.cities[:, 1], c="tab:blue", s=50)
        for index, (x, y) in enumerate(self.cities):
            axes[0].text(x + 0.8, y + 0.8, str(index), fontsize=9)
        axes[0].plot(route_cities[:, 0], route_cities[:, 1], c="tab:red", linewidth=2)
        axes[0].set_title("PSO TSP Route")
        axes[0].set_xlabel("X")
        axes[0].set_ylabel("Y")
        axes[0].grid(alpha=0.3)

        axes[1].plot(self.history, c="tab:green")
        axes[1].set_title("Convergence Curve")
        axes[1].set_xlabel("Iteration")
        axes[1].set_ylabel("Best Distance")
        axes[1].grid(alpha=0.3)

        plt.tight_layout()

        image_path = None
        if output_dir is not None:
            output_dir.mkdir(parents=True, exist_ok=True)
            image_path = output_dir / "pso_tsp_result.png"
            plt.savefig(image_path, dpi=200, bbox_inches="tight")
            print(f"Saved result figure: {image_path}")

        plt.close(fig)
        return image_path


def main() -> None:
    cities = generate_cities(20)
    params = PSOParams(
        num_particles=60,
        iterations=400,
        inertia_max=0.9,
        inertia_min=0.4,
        cognitive_coeff=1.7,
        social_coeff=1.7,
        vmax=0.2,
    )

    optimizer = PSOTSP(cities, params)
    best_route, best_distance = optimizer.optimize()

    print("\nOptimization Finished!")
    print(f"Best route: {best_route}")
    print(f"Minimum distance: {best_distance:.6f}")

    optimizer.plot_result(Path(__file__).resolve().parent)


if __name__ == "__main__":
    main()