"""
遗传算法（GA）— 连续函数最大值求解

求解 PPT 指定问题：
    f(x) = |x·sin(x)·cos(2x) - 2x·sin(3x) + 3x·sin(4x)|
在区间 [0, 50] 上的最大值。

使用二进制编码，轮盘赌选择，单点交叉，位翻转变异，精英保留。
"""

from __future__ import annotations

import random
from dataclasses import dataclass

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


# ===================== 参数 =====================
random.seed(42)
np.random.seed(42)

X_MIN, X_MAX = 0.0, 50.0          # 搜索区间
CHROMO_BITS = 22                    # 染色体长度（精度≈1.2e-5）
POP_SIZE = 100                      # 种群规模
GENERATIONS = 200                   # 进化代数
CROSSOVER_RATE = 0.85               # 交叉概率
MUTATION_RATE = 0.02                # 变异概率
ELITE_SIZE = 2                      # 精英保留数


# ===================== 目标函数 =====================
def target_function(x: np.ndarray) -> np.ndarray:
    """待最大化函数 f(x) = |x·sin(x)·cos(2x) - 2x·sin(3x) + 3x·sin(4x)|"""
    return np.abs(
        x * np.sin(x) * np.cos(2 * x)
        - 2 * x * np.sin(3 * x)
        + 3 * x * np.sin(4 * x)
    )


# ===================== 编码 / 解码 =====================
def encode(x: float) -> list[int]:
    """将实数值 x ∈ [X_MIN, X_MAX] 编码为二进制串"""
    normalized = (x - X_MIN) / (X_MAX - X_MIN)
    int_val = int(round(normalized * ((1 << CHROMO_BITS) - 1)))
    bits = [(int_val >> i) & 1 for i in range(CHROMO_BITS)]
    return bits  # LSB first for convenience


def decode(chromosome: list[int]) -> float:
    """将二进制串解码为实数值"""
    int_val = sum(bit << i for i, bit in enumerate(chromosome))
    normalized = int_val / ((1 << CHROMO_BITS) - 1)
    return X_MIN + normalized * (X_MAX - X_MIN)


# ===================== 种群操作 =====================
def init_population(size: int) -> list[list[int]]:
    """随机初始化种群"""
    return [[random.randint(0, 1) for _ in range(CHROMO_BITS)] for _ in range(size)]


def fitness_func(chromosome: list[int]) -> float:
    """适应度 = f(x)，直接最大化"""
    x = decode(chromosome)
    return float(target_function(np.array([x]))[0])


def evaluate(population: list[list[int]]) -> np.ndarray:
    """计算种群适应度"""
    return np.array([fitness_func(ind) for ind in population], dtype=float)


def select_roulette(population: list[list[int]], fitness: np.ndarray) -> list[int]:
    """轮盘赌选择"""
    total_fit = fitness.sum()
    if total_fit == 0:
        return random.choice(population).copy()
    probs = fitness / total_fit
    idx = np.random.choice(len(population), p=probs)
    return population[idx].copy()


def single_point_crossover(p1: list[int], p2: list[int]) -> tuple[list[int], list[int]]:
    """单点交叉"""
    if random.random() >= CROSSOVER_RATE:
        return p1.copy(), p2.copy()
    point = random.randint(1, CHROMO_BITS - 1)
    c1 = p1[:point] + p2[point:]
    c2 = p2[:point] + p1[point:]
    return c1, c2


def bit_flip_mutate(chromosome: list[int]) -> list[int]:
    """位翻转变异"""
    mutated = chromosome.copy()
    for i in range(CHROMO_BITS):
        if random.random() < MUTATION_RATE:
            mutated[i] = 1 - mutated[i]
    return mutated


# ===================== GA 主流程 =====================
class GeneticAlgorithm:
    def __init__(self):
        self.best_x: float = 0.0
        self.best_fitness: float = 0.0
        self.avg_history: list[float] = []
        self.best_history: list[float] = []

    def run(self) -> tuple[float, float]:
        population = init_population(POP_SIZE)
        fitness = evaluate(population)

        for gen in range(GENERATIONS):
            # 记录统计
            best_idx = int(np.argmax(fitness))
            current_best_fit = float(fitness[best_idx])
            avg_fit = float(np.mean(fitness))

            self.best_history.append(current_best_fit)
            self.avg_history.append(avg_fit)

            if current_best_fit > self.best_fitness:
                self.best_fitness = current_best_fit
                self.best_x = decode(population[best_idx])

            # 下一代
            next_pop: list[list[int]] = []

            # 精英保留
            elite_idx = np.argsort(fitness)[-ELITE_SIZE:]
            for idx in elite_idx:
                next_pop.append(population[int(idx)].copy())

            # 生成子代
            while len(next_pop) < POP_SIZE:
                parent1 = select_roulette(population, fitness)
                parent2 = select_roulette(population, fitness)
                child1, child2 = single_point_crossover(parent1, parent2)
                child1 = bit_flip_mutate(child1)
                child2 = bit_flip_mutate(child2)
                next_pop.append(child1)
                if len(next_pop) < POP_SIZE:
                    next_pop.append(child2)

            population = next_pop
            fitness = evaluate(population)

            if (gen + 1) % 20 == 0:
                print(f"  第 {gen+1:3d} 代: 最优适应度 = {self.best_fitness:.6f}, "
                      f"当前最优 = {current_best_fit:.6f}, 平均 = {avg_fit:.6f}")

        return self.best_x, self.best_fitness

    def plot(self, save_path: str) -> None:
        """绘制收敛曲线和目标函数图"""
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))

        # 左：收敛曲线
        ax = axes[0]
        ax.plot(self.best_history, label="Best Fitness", color="#d62728", linewidth=1.5)
        ax.plot(self.avg_history, label="Average Fitness", color="#1f77b4", linewidth=1, alpha=0.7)
        ax.set_xlabel("Generation")
        ax.set_ylabel("Fitness")
        ax.set_title("GA Convergence Curve")
        ax.legend()
        ax.grid(True, alpha=0.3)

        # 右：目标函数 + 最优解标记
        ax = axes[1]
        x_vals = np.linspace(X_MIN, X_MAX, 1000)
        y_vals = target_function(x_vals)
        ax.plot(x_vals, y_vals, color="#2ca02c", linewidth=1, label="f(x)")
        ax.scatter([self.best_x], [self.best_fitness], c="red", s=120,
                   marker="*", zorder=5, label=f"Best: x={self.best_x:.4f}")
        ax.set_xlabel("x")
        ax.set_ylabel("f(x)")
        ax.set_title(f"Target Function & Optimal Solution (f_max = {self.best_fitness:.6f})")
        ax.legend()
        ax.grid(True, alpha=0.3)

        fig.tight_layout()
        fig.savefig(save_path, dpi=200)
        plt.close(fig)
        print(f"结果图已保存: {save_path}")


# ===================== 主流程 =====================
def main() -> None:
    print("=" * 60)
    print("遗传算法 (GA) — 连续函数最大值求解")
    print(f"目标函数: f(x) = |x·sin(x)·cos(2x) - 2x·sin(3x) + 3x·sin(4x)|")
    print(f"搜索区间: [{X_MIN}, {X_MAX}]")
    print(f"种群规模: {POP_SIZE}  |  进化代数: {GENERATIONS}")
    print(f"交叉概率: {CROSSOVER_RATE}  |  变异概率: {MUTATION_RATE}")
    print(f"编码长度: {CHROMO_BITS} bits  |  精度 ≈ {(X_MAX-X_MIN)/(2**CHROMO_BITS-1):.2e}")
    print("=" * 60)

    ga = GeneticAlgorithm()
    best_x, best_fit = ga.run()

    print("-" * 60)
    print(f"最优解: x = {best_x:.6f}")
    print(f"最大值: f(x) = {best_fit:.6f}")
    print(f"验证: f({best_x:.6f}) = {target_function(np.array([best_x]))[0]:.6f}")

    import os
    save_dir = os.path.dirname(os.path.abspath(__file__))
    ga.plot(os.path.join(save_dir, "ga_convergence.png"))


if __name__ == "__main__":
    main()
