"""
KNN (K-Nearest Neighbors) 算法 — Iris 数据集分类

从零实现 KNN 分类器，不依赖 sklearn。使用 Iris 数据集，
每类取 25 条训练 / 25 条测试，共 75+75 条。
输出不同 k 值下的准确率并绘制对比图。
"""

from __future__ import annotations

from collections import Counter
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np


# ===================== 参数 =====================
K_VALUES = [1, 3, 5, 7, 9, 11, 13, 15]
BASE_DIR = Path(__file__).resolve().parent
BP_DIR = BASE_DIR.parent / "反向传播算法"

CLASS_TO_LABEL = {
    "Iris-setosa": 0,
    "Iris-versicolor": 1,
    "Iris-virginica": 2,
}
LABEL_TO_CLASS = {v: k for k, v in CLASS_TO_LABEL.items()}


# ===================== 数据加载 =====================
def load_dataset(path: Path) -> tuple[np.ndarray, np.ndarray]:
    """读取 Iris train/test 文件，返回 (features, labels)"""
    features: list[list[float]] = []
    labels: list[int] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(",")
        feats = [float(parts[0]), float(parts[1]), float(parts[2]), float(parts[3])]
        features.append(feats)
        labels.append(CLASS_TO_LABEL[parts[4]])
    return np.array(features, dtype=float), np.array(labels, dtype=int)


def standardize(
    train_x: np.ndarray, test_x: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Z-score 标准化"""
    mean = train_x.mean(axis=0)
    std = train_x.std(axis=0)
    std[std == 0] = 1.0
    return (train_x - mean) / std, (test_x - mean) / std


# ===================== KNN 分类器 =====================
class KNNClassifier:
    """K 近邻分类器（欧氏距离）"""

    def __init__(self, k: int = 5):
        self.k = k
        self.train_x: np.ndarray | None = None
        self.train_y: np.ndarray | None = None

    def fit(self, x: np.ndarray, y: np.ndarray) -> None:
        """KNN 无显式训练过程，仅存储数据"""
        self.train_x = x
        self.train_y = y

    def predict(self, x: np.ndarray) -> np.ndarray:
        """对每个测试样本投票"""
        assert self.train_x is not None and self.train_y is not None
        predictions = np.empty(len(x), dtype=int)
        for i, sample in enumerate(x):
            # 计算到所有训练样本的欧氏距离
            distances = np.sqrt(((self.train_x - sample) ** 2).sum(axis=1))
            # 取距离最近的 k 个
            nearest = np.argsort(distances)[: self.k]
            nearest_labels = self.train_y[nearest]
            # 多数投票
            predictions[i] = Counter(nearest_labels.tolist()).most_common(1)[0][0]
        return predictions


# ===================== 绘图 =====================
def plot_accuracy_vs_k(k_list: list[int], acc_list: list[float], save_path: Path) -> None:
    """绘制不同 k 值的准确率对比图"""
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(k_list, acc_list, marker="o", linewidth=2, markersize=8, color="#1f77b4")
    ax.set_xlabel("K Value", fontsize=13)
    ax.set_ylabel("Accuracy", fontsize=13)
    ax.set_title("KNN Classification Accuracy on Iris (Different K)", fontsize=14)
    ax.set_xticks(k_list)
    ax.grid(True, alpha=0.4)

    # 标注数值
    for k_val, acc in zip(k_list, acc_list):
        ax.annotate(
            f"{acc:.4f}",
            (k_val, acc),
            textcoords="offset points",
            xytext=(0, 12),
            ha="center",
            fontsize=9,
        )

    fig.tight_layout()
    fig.savefig(save_path, dpi=200)
    plt.close(fig)
    print(f"准确率对比图已保存: {save_path}")


# ===================== 主流程 =====================
def main() -> None:
    # 1. 加载 & 标准化（使用与 BP 实验一致的训练/测试划分）
    train_x, train_y = load_dataset(BP_DIR / "Iris-train.txt")
    test_x, test_y = load_dataset(BP_DIR / "Iris-test.txt")
    train_x, test_x = standardize(train_x, test_x)

    print("=" * 55)
    print("KNN 分类器 — Iris 数据集")
    print(f"训练集: {len(train_x)} 条  |  测试集: {len(test_x)} 条")
    print(f"待测试 k 值: {K_VALUES}")
    print("=" * 55)

    # 2. 对不同 k 值进行测试
    accuracies: list[float] = []
    best_k, best_acc = 1, 0.0

    for k_val in K_VALUES:
        knn = KNNClassifier(k=k_val)
        knn.fit(train_x, train_y)
        pred = knn.predict(test_x)
        acc = float(np.mean(pred == test_y))
        accuracies.append(acc)
        print(f"  k = {k_val:2d}  →  准确率 = {acc:.4f}")

        if acc > best_acc:
            best_acc = acc
            best_k = k_val

    # 3. 汇总
    print("-" * 55)
    print(f"最优 k = {best_k}, 对应准确率 = {best_acc:.4f}")
    print(f"平均准确率 = {np.mean(accuracies):.4f}")

    # 4. 绘图
    plot_accuracy_vs_k(K_VALUES, accuracies, BASE_DIR / "knn_accuracy.png")


if __name__ == "__main__":
    main()
