from collections import Counter
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np


FEATURE_NAMES = ["f1", "f2", "f3", "f4"]


def load_dataset(path: Path) -> tuple[np.ndarray, np.ndarray]:
    data = np.loadtxt(path, dtype=float)
    features = data[:, :-1]
    labels = data[:, -1].astype(int)
    return features, labels


def entropy(labels: np.ndarray) -> float:
    counts = np.array(list(Counter(labels).values()), dtype=float)
    probabilities = counts / counts.sum()
    return float(-np.sum(probabilities * np.log2(probabilities + 1e-12)))


def majority_label(labels: np.ndarray) -> int:
    return Counter(labels.tolist()).most_common(1)[0][0]


def best_threshold_for_feature(features: np.ndarray, labels: np.ndarray, feature_index: int) -> tuple[float | None, float]:
    values = features[:, feature_index]
    order = np.argsort(values)
    sorted_values = values[order]
    sorted_labels = labels[order]

    candidate_thresholds: list[float] = []
    for index in range(len(sorted_values) - 1):
        if sorted_labels[index] != sorted_labels[index + 1] and sorted_values[index] != sorted_values[index + 1]:
            candidate_thresholds.append((sorted_values[index] + sorted_values[index + 1]) / 2.0)

    if not candidate_thresholds:
        return None, -1.0

    base_entropy = entropy(labels)
    best_gain = -1.0
    best_threshold: float | None = None

    for threshold in candidate_thresholds:
        left_mask = values <= threshold
        right_mask = ~left_mask
        if not left_mask.any() or not right_mask.any():
            continue

        left_entropy = entropy(labels[left_mask])
        right_entropy = entropy(labels[right_mask])
        weighted_entropy = (
            left_mask.mean() * left_entropy + right_mask.mean() * right_entropy
        )
        gain = base_entropy - weighted_entropy

        if gain > best_gain:
            best_gain = gain
            best_threshold = threshold

    return best_threshold, best_gain


def best_split(features: np.ndarray, labels: np.ndarray) -> tuple[int | None, float | None, float]:
    best_feature = None
    best_threshold = None
    best_gain = -1.0

    for feature_index in range(features.shape[1]):
        threshold, gain = best_threshold_for_feature(features, labels, feature_index)
        if threshold is None:
            continue
        if gain > best_gain:
            best_gain = gain
            best_feature = feature_index
            best_threshold = threshold

    return best_feature, best_threshold, best_gain


class TreeNode:
    def __init__(
        self,
        is_leaf: bool,
        predicted_class: int,
        feature_index: int | None = None,
        threshold: float | None = None,
        left: "TreeNode | None" = None,
        right: "TreeNode | None" = None,
        samples: int = 0,
        label_counts: dict[int, int] | None = None,
    ):
        self.is_leaf = is_leaf
        self.predicted_class = predicted_class
        self.feature_index = feature_index
        self.threshold = threshold
        self.left = left
        self.right = right
        self.samples = samples
        self.label_counts = label_counts


class ID3DecisionTree:
    def __init__(self, max_depth: int | None = None, min_samples_split: int = 2):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.root: TreeNode | None = None

    def fit(self, features: np.ndarray, labels: np.ndarray) -> None:
        self.root = self._build_tree(features, labels, depth=0)

    def _build_tree(self, features: np.ndarray, labels: np.ndarray, depth: int) -> TreeNode:
        counts = Counter(labels.tolist())
        predicted_class = counts.most_common(1)[0][0]
        node = TreeNode(
            is_leaf=False,
            predicted_class=predicted_class,
            samples=len(labels),
            label_counts=dict(counts),
        )

        if len(set(labels.tolist())) == 1:
            node.is_leaf = True
            return node

        if len(labels) < self.min_samples_split:
            node.is_leaf = True
            return node

        if self.max_depth is not None and depth >= self.max_depth:
            node.is_leaf = True
            return node

        feature_index, threshold, gain = best_split(features, labels)
        if feature_index is None or threshold is None or gain <= 1e-12:
            node.is_leaf = True
            return node

        left_mask = features[:, feature_index] <= threshold
        right_mask = ~left_mask
        if not left_mask.any() or not right_mask.any():
            node.is_leaf = True
            return node

        node.feature_index = feature_index
        node.threshold = threshold
        node.left = self._build_tree(features[left_mask], labels[left_mask], depth + 1)
        node.right = self._build_tree(features[right_mask], labels[right_mask], depth + 1)
        return node

    def predict_one(self, sample: np.ndarray) -> int:
        if self.root is None:
            raise RuntimeError("Decision tree has not been fitted.")

        node = self.root
        while not node.is_leaf:
            if node.feature_index is None or node.threshold is None:
                break
            if sample[node.feature_index] <= node.threshold:
                if node.left is None:
                    break
                node = node.left
            else:
                if node.right is None:
                    break
                node = node.right
        return node.predicted_class

    def predict(self, features: np.ndarray) -> np.ndarray:
        return np.array([self.predict_one(sample) for sample in features], dtype=int)


def tree_to_lines(node: TreeNode, depth: int = 0, branch: str = "root") -> list[str]:
    indent = "  " * depth
    if node.is_leaf:
        counts = ", ".join(f"{label}:{count}" for label, count in sorted((node.label_counts or {}).items()))
        return [f"{indent}{branch} -> class {node.predicted_class} [{counts}] (samples={node.samples})"]

    assert node.feature_index is not None and node.threshold is not None
    lines = [
        f"{indent}{branch}: {FEATURE_NAMES[node.feature_index]} <= {node.threshold:.3f}"
    ]
    if node.left is not None:
        lines.extend(tree_to_lines(node.left, depth + 1, "yes"))
    if node.right is not None:
        lines.extend(tree_to_lines(node.right, depth + 1, "no"))
    return lines


def plot_tree(node: TreeNode, output_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(14, 8))
    ax.axis("off")

    positions: dict[int, tuple[float, float]] = {}
    labels: dict[int, str] = {}
    edges: list[tuple[int, int, str]] = []

    def assign_positions(current: TreeNode, depth: int, x_cursor: list[float]) -> float:
        node_id = id(current)
        if current.is_leaf:
            x = x_cursor[0]
            positions[node_id] = (x, -depth)
            labels[node_id] = f"class {current.predicted_class}\n{current.samples} samples"
            x_cursor[0] += 1.6
            return x

        left_x = assign_positions(current.left, depth + 1, x_cursor) if current.left is not None else x_cursor[0]
        right_x = assign_positions(current.right, depth + 1, x_cursor) if current.right is not None else x_cursor[0]
        x = (left_x + right_x) / 2 if current.left is not None and current.right is not None else left_x
        positions[node_id] = (x, -depth)
        labels[node_id] = f"{FEATURE_NAMES[current.feature_index]} <= {current.threshold:.3f}\n{current.samples} samples"
        if current.left is not None:
            edges.append((node_id, id(current.left), "yes"))
        if current.right is not None:
            edges.append((node_id, id(current.right), "no"))
        return x

    assign_positions(node, 0, [0.0])

    for parent_id, child_id, edge_label in edges:
        x1, y1 = positions[parent_id]
        x2, y2 = positions[child_id]
        ax.plot([x1, x2], [y1, y2], c="gray", linewidth=1.2)
        ax.text((x1 + x2) / 2, (y1 + y2) / 2, edge_label, ha="center", va="center", fontsize=9, color="darkgreen")

    for node_id, (x, y) in positions.items():
        text = labels[node_id]
        box_style = dict(boxstyle="round,pad=0.35", facecolor="#fff7e6", edgecolor="#c97d00")
        ax.text(x, y, text, ha="center", va="center", fontsize=9, bbox=box_style)

    ax.set_xlim(-1, max((x for x, _ in positions.values()), default=1) + 1)
    ax.set_ylim(min((y for _, y in positions.values()), default=0) - 1, 1)
    plt.tight_layout()
    fig.savefig(output_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    base_dir = Path(__file__).resolve().parent
    train_x, train_y = load_dataset(base_dir / "traindata.txt")
    test_x, test_y = load_dataset(base_dir / "testdata.txt")

    tree = ID3DecisionTree(max_depth=None, min_samples_split=2)
    tree.fit(train_x, train_y)

    predictions = tree.predict(test_x)
    accuracy = float(np.mean(predictions == test_y))

    print("训练完成")
    print(f"测试集准确率: {accuracy:.4f}")
    print("\n决策树结构:")
    if tree.root is not None:
        for line in tree_to_lines(tree.root):
            print(line)

    plot_path = base_dir / "id3_tree.png"
    if tree.root is not None:
        plot_tree(tree.root, plot_path)
        print(f"树图已保存: {plot_path}")


if __name__ == "__main__":
    main()