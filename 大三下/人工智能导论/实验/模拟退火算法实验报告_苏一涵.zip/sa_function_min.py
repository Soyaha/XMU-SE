import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import random
from pathlib import Path

# 设置随机种子以保证结果可复现
random.seed(42)
np.random.seed(42)

def target_function(x):
    """
    目标函数: f(x) = 11*sin(6x) + 7*cos(5x)
    """
    return 11 * np.sin(6 * x) + 7 * np.cos(5 * x)

class SimulatedAnnealingFunction:
    def __init__(self, func, x_min=0, x_max=2*np.pi, T0=100, Tf=1e-6, alpha=0.99, L=200):
        """
        初始化模拟退火算法参数
        :param func: 目标函数
        :param x_min: 搜索区间下界
        :param x_max: 搜索区间上界
        :param T0: 初始温度
        :param Tf: 终止温度
        :param alpha: 降温系数
        :param L: 每个温度下的迭代次数
        """
        self.func = func
        self.x_min = x_min
        self.x_max = x_max
        self.T0 = T0
        self.Tf = Tf
        self.alpha = alpha
        self.L = L
        
        # 初始解
        self.best_x = random.uniform(x_min, x_max)
        self.best_y = self.func(self.best_x)
        
        self.curr_x = self.best_x
        self.curr_y = self.best_y
        
        self.history = []

    def solve(self):
        """执行模拟退火算法"""
        T = self.T0
        iteration = 0
        
        while T > self.Tf:
            for _ in range(self.L):
                # 1. 产生新解 (在当前解附近随机扰动)
                # 步长随温度降低而减小，有助于后期收敛
                step = (self.x_max - self.x_min) * (T / self.T0)
                new_x = self.curr_x + random.uniform(-step, step)
                
                # 边界检查
                new_x = max(self.x_min, min(self.x_max, new_x))
                new_y = self.func(new_x)
                
                # 2. 计算能量差 (求解最小值，所以 delta = new - curr)
                delta_e = new_y - self.curr_y
                
                # 3. Metropolis准则
                if delta_e < 0:
                    self.curr_x = new_x
                    self.curr_y = new_y
                    if new_y < self.best_y:
                        self.best_x = new_x
                        self.best_y = new_y
                else:
                    p = np.exp(-delta_e / T)
                    if random.random() < p:
                        self.curr_x = new_x
                        self.curr_y = new_y
            
            self.history.append(self.best_y)
            T *= self.alpha
            iteration += 1
            
            if iteration % 100 == 0:
                print(f"Iteration {iteration}: T={T:.6f}, Best x={self.best_x:.4f}, f(x)={self.best_y:.4f}")
        
        return self.best_x, self.best_y

    def plot_result(self, save_path: Path | None = None):
        """可视化结果并保存"""
        fig, axes = plt.subplots(1, 2, figsize=(13, 5))

        # 函数曲线图
        ax = axes[0]
        x = np.linspace(self.x_min, self.x_max, 1000)
        y = self.func(x)
        ax.plot(x, y, label='f(x) = 11sin(6x) + 7cos(5x)', color='#2ca02c')
        ax.scatter(self.best_x, self.best_y, color='red', s=100, marker='*',
                  zorder=5, label=f'Min: ({self.best_x:.4f}, {self.best_y:.4f})')
        ax.set_title("Function Optimization")
        ax.set_xlabel("x")
        ax.set_ylabel("f(x)")
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)

        # 收敛曲线
        ax = axes[1]
        ax.plot(self.history, color='#d62728', linewidth=1.5)
        ax.set_title("Convergence Curve")
        ax.set_xlabel("Temperature Step")
        ax.set_ylabel("Best f(x)")
        ax.grid(True, alpha=0.3)

        fig.tight_layout()
        if save_path:
            fig.savefig(save_path, dpi=200)
            print(f"结果图已保存: {save_path}")
        plt.close(fig)

if __name__ == "__main__":
    sa = SimulatedAnnealingFunction(target_function)
    best_x, best_y = sa.solve()

    print("\nOptimization Finished!")
    print(f"Best x Found: {best_x:.6f}")
    print(f"Minimum Value: {best_y:.6f}")

    base_dir = Path(__file__).resolve().parent
    sa.plot_result(base_dir / "sa_result.png")
