import time
import unittest
import logging
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)


class LibrarySystemAutomationTest(unittest.TestCase):
    """
    四大核心功能模块自动化测试集（全量参数化断言覆盖版）
    """
    LOCATORS = {
        # 登录页（已验证可用）
        "login_username_input": (By.XPATH, "(//input[@placeholder='请输入用户名'])[1]"),
        "login_password_input": (By.XPATH, "(//input[@placeholder='请输入密码'])[1]"),
        "login_radio_buttons": (By.XPATH, "//input[@type='radio']"),
        "login_btn": (By.XPATH, "//button[text()='登录']"),

        # 新增用户页（已验证可用）
        "add_user_username": (By.ID, "userName"),
        "add_user_password": (By.ID, "password"),
        "add_user_email": (By.ID, "email"),
        "add_user_submit_btn": (By.ID, "btn_addUser"),

        # 新增书籍类别页
        "add_category_name": (By.ID, "categoryName"),
        "add_category_submit_btn": (By.ID, "btn_addBookCategory"),

        # 新增图书页
        "add_book_name": (By.ID, "bookName"),
        "add_book_author": (By.ID, "bookAuthor"),
        "add_book_publish": (By.ID, "bookPublish"),
        "add_book_price": (By.ID, "bookPrice"),
        "add_book_intro": (By.ID, "bookIntroduction"),
        "add_book_submit_btn": (By.ID, "btn1"),

        # 读者查书与借还页
        "find_book_input": (By.NAME, "bookPartInfo"),
        "find_book_btn": (By.XPATH, "//input[@value='查询']"),
        "borrow_return_input": (By.ID, "bookId"),
        "borrow_return_btn": (By.ID, "btn1"),
    }

    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.implicitly_wait(5)
        self.base_url = "http://localhost:8080"
        self.wait = WebDriverWait(self.driver, 15, poll_frequency=0.3)
        self.driver.maximize_window()
        logger.info("浏览器初始化完成，开始登录")
        self._login()

    def _login(self):
        """登录逻辑（已验证可用）"""
        driver = self.driver
        try:
            driver.get(self.base_url)
            logger.info(f"打开登录页：{self.base_url}")

            # 输入账号密码
            self.wait.until(EC.visibility_of_element_located(self.LOCATORS["login_username_input"])).send_keys("admin")
            self.wait.until(EC.visibility_of_element_located(self.LOCATORS["login_password_input"])).send_keys("123456")
            logger.info("输入账号密码完成")

            # 选中管理员单选框
            radio_buttons = self.wait.until(EC.presence_of_all_elements_located(self.LOCATORS["login_radio_buttons"]))
            driver.execute_script("arguments[0].checked = true;", radio_buttons[1])
            logger.info("选中管理员角色")

            # 点击登录
            self.wait.until(EC.element_to_be_clickable(self.LOCATORS["login_btn"])).click()
            logger.info("点击登录按钮")

            # 验证登录成功（等待首页加载）
            self.wait.until(EC.title_contains("管理员"))
            logger.info("登录成功，进入管理员首页")

        except Exception as e:
            self._take_screenshot("login_fail")
            self.fail(f"登录失败：{str(e)}")

    def _take_screenshot(self, scenario):
        """失败截图"""
        screenshot_name = f"error_{scenario}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        self.driver.save_screenshot(screenshot_name)
        logger.error(f"截图已保存：{screenshot_name}")

    def _wait_for_layer_message(self, text, timeout=5):
        """等待 Layui 浮层消息/弹窗出现，避免直接读 page_source 漏掉短暂提示。"""
        xpath = f"//div[contains(@class,'layui-layer') and contains(@class,'layui-layer-content') and contains(., '{text}')]"
        return WebDriverWait(self.driver, timeout, poll_frequency=0.2).until(
            EC.visibility_of_element_located((By.XPATH, xpath))
        )

    def test_1_add_user_parameterized(self):
        """1. 新增用户参数化测试（用户赋权与管理模块）"""
        driver = self.driver
        wait = self.wait

        test_data = [
            {"scenario": "1.合法有效等价类", "uname": "user_test99", "pwd": "123456", "email": "123@qq.com",
             "expect": "添加成功"},
            {"scenario": "2.无效等价类(关键值缺失)", "uname": "user_test100", "pwd": "", "email": "test@163.com",
             "expect": "必填"},
            {"scenario": "3.无效等价类(非法字符类)", "uname": "admin' OR", "pwd": "pass123", "email": "hi@aliyun.com",
             "expect": "失败"}
        ]

        for idx, data in enumerate(test_data):
            with self.subTest(scenario=data["scenario"]):
                logger.info(f"\n========== 执行第{idx + 1}轮测试：{data['scenario']} ==========")
                try:
                    driver.get(f"{self.base_url}/addUserPage")
                    # 等待页面加载完成（验证用户名输入框存在）
                    wait.until(EC.visibility_of_element_located(self.LOCATORS["add_user_username"]))
                    logger.info("直接跳转到新增用户页面")

                    # 4. 输入测试数据
                    uname_input = wait.until(EC.visibility_of_element_located(self.LOCATORS["add_user_username"]))
                    uname_input.clear()
                    if data["uname"]:
                        uname_input.send_keys(data["uname"])

                    pwd_input = wait.until(EC.visibility_of_element_located(self.LOCATORS["add_user_password"]))
                    pwd_input.clear()
                    if data["pwd"]:
                        pwd_input.send_keys(data["pwd"])

                    email_input = wait.until(EC.visibility_of_element_located(self.LOCATORS["add_user_email"]))
                    email_input.clear()
                    if data["email"]:
                        email_input.send_keys(data["email"])
                    logger.info(f"输入测试数据：{data['uname']}/{data['pwd']}/{data['email']}")

                    time.sleep(0.5)

                    # 5. 点击提交
                    submit_btn = wait.until(EC.presence_of_element_located(self.LOCATORS["add_user_submit_btn"]))
                    driver.execute_script("arguments[0].click();", submit_btn)
                    
                    # 避免页面来不及渲染提示就立刻读取
                    time.sleep(1)

                    # 6. 断言结果
                    self.assertIn(
                        data["expect"], driver.page_source,
                        f"场景【{data['scenario']}】断言失败！期望包含'{data['expect']}'"
                    )
                    logger.info(f"断言成功：{data['expect']}")

                    # 7. 重置：等待页面跳转/刷新
                    time.sleep(1)

                except Exception as e:
                    self._take_screenshot(data["scenario"] + "_fail")
                    self.fail(f"场景【{data['scenario']}】执行失败：{str(e)}")

    def test_2_add_category_parameterized(self):
        """2. 新增图书类别参数化测试（图书物资管理模块）"""
        driver = self.driver
        wait = self.wait

        test_data = [
            {"scenario": "1.合法类别", "category_name": "自动化测试类", "expect": "添加成功"},
            {"scenario": "2.非法类别_为空", "category_name": "", "expect": "必填"}
        ]

        for idx, data in enumerate(test_data):
            with self.subTest(scenario=data["scenario"]):
                logger.info(f"\n========== 执行图书类别第{idx + 1}轮测试：{data['scenario']} ==========")
                try:
                    # 直接跳转到新增类别的URL，利用 pageNum 查询参数
                    driver.get(f"{self.base_url}/addCategoryPage?pageNum=1")
                    
                    # 验证类别名称输入框存在
                    cat_input = wait.until(EC.visibility_of_element_located(self.LOCATORS["add_category_name"]))
                    logger.info("直接跳转到新增类别页面")

                    # 填入类别名称
                    cat_input.clear()
                    if data["category_name"]:
                        cat_input.send_keys(data["category_name"])
                    
                    logger.info(f"输入图书类别名称：{data['category_name']}")
                    
                    time.sleep(0.5)

                    # 强制JS点击提交
                    submit_btn = wait.until(EC.presence_of_element_located(self.LOCATORS["add_category_submit_btn"]))
                    driver.execute_script("arguments[0].click();", submit_btn)
                    
                    # 避免页面来不及渲染提示就立刻读取
                    time.sleep(1)

                    # 断言结果
                    self.assertIn(
                        data["expect"], driver.page_source,
                        f"图书类别场景【{data['scenario']}】断言失败！期望包含'{data['expect']}'"
                    )
                    logger.info(f"图书类别测试断言成功：{data['expect']}")

                    time.sleep(1)

                except Exception as e:
                    self._take_screenshot("category_" + data["scenario"] + "_fail")
                    self.fail(f"图书类别测试场景【{data['scenario']}】执行失败：{str(e)}")

    def test_3_add_book_parameterized(self):
        """3. 新增图书参数化测试（图书物资管理模块）"""
        driver = self.driver
        wait = self.wait

        test_data = [
            {
                "scenario": "1.合法新书", 
                "bName": "软件测试实战", "bAuthor": "张三", "bPub": "清华大学出版社", 
                "bPrice": "59.9", "bIntro": "一本好书", 
                "expect": "添加成功"
            },
            {
                "scenario": "2.价格类型错误(字母)", 
                "bName": "测试用书", "bAuthor": "李四", "bPub": "北大出版社", 
                "bPrice": "abc", "bIntro": "价格非数字", 
                "expect": "数字"
            }
        ]

        for idx, data in enumerate(test_data):
            with self.subTest(scenario=data["scenario"]):
                logger.info(f"\n========== 执行新增图书第{idx + 1}轮测试：{data['scenario']} ==========")
                try:
                    driver.get(f"{self.base_url}/addBookPage")
                    wait.until(EC.visibility_of_element_located(self.LOCATORS["add_book_name"]))
                    logger.info("成功跳转录入新书页面")

                    driver.find_element(*self.LOCATORS["add_book_name"]).clear()
                    if data["bName"]: driver.find_element(*self.LOCATORS["add_book_name"]).send_keys(data["bName"])
                    
                    driver.find_element(*self.LOCATORS["add_book_author"]).clear()
                    if data["bAuthor"]: driver.find_element(*self.LOCATORS["add_book_author"]).send_keys(data["bAuthor"])
                    
                    driver.find_element(*self.LOCATORS["add_book_publish"]).clear()
                    if data["bPub"]: driver.find_element(*self.LOCATORS["add_book_publish"]).send_keys(data["bPub"])
                    
                    driver.find_element(*self.LOCATORS["add_book_price"]).clear()
                    if data["bPrice"]: driver.find_element(*self.LOCATORS["add_book_price"]).send_keys(data["bPrice"])
                    
                    driver.find_element(*self.LOCATORS["add_book_intro"]).clear()
                    if data["bIntro"]: driver.find_element(*self.LOCATORS["add_book_intro"]).send_keys(data["bIntro"])


                    # 假设类别1总是存在的 (数据库里有 1, 小说等)
                    driver.execute_script("document.getElementById('bookCategory').value = '1';")
                    
                    time.sleep(0.5)

                    # 强制JS点击提交
                    submit_btn = wait.until(EC.presence_of_element_located(self.LOCATORS["add_book_submit_btn"]))
                    driver.execute_script("arguments[0].click();", submit_btn)
                    
                    time.sleep(1)

                    self.assertIn(
                        data["expect"], driver.page_source,
                        f"新增图书场景【{data['scenario']}】断言失败！期望包含'{data['expect']}'"
                    )
                    logger.info(f"新增图书测试断言成功：{data['expect']}")
                    time.sleep(1)

                except Exception as e:
                    self._take_screenshot("book_" + data["scenario"] + "_fail")
                    self.fail(f"新增图书场景【{data['scenario']}】执行失败：{str(e)}")

    def _switch_to_reader(self):
        """辅助方法：登出管理员并以普通读者身份登录"""
        driver = self.driver
        wait = self.wait
        driver.get(f"{self.base_url}/adminLogOut")
        time.sleep(1)
        driver.get(f"{self.base_url}")
        
        wait.until(EC.visibility_of_element_located(self.LOCATORS["login_username_input"])).send_keys("user1")
        wait.until(EC.visibility_of_element_located(self.LOCATORS["login_password_input"])).send_keys("123456")
        
        # 选择第二个单选按钮（普通用户 role=1）
        radio_buttons = wait.until(EC.presence_of_all_elements_located(self.LOCATORS["login_radio_buttons"]))
        driver.execute_script("arguments[0].checked = true;", radio_buttons[0])
        
        wait.until(EC.element_to_be_clickable(self.LOCATORS["login_btn"])).click()
        time.sleep(1)

    def test_4_reader_find_book_parameterized(self):
        """4. 读者端查阅书籍参数化测试（前台查阅流转模块）"""
        try:
            self._switch_to_reader()
        except Exception as e:
            self.fail(f"无法切换至读者身份进行模块3测试: {str(e)}")

        driver = self.driver
        wait = self.wait

        logger.info("\n========== [模块3] 前台查阅模块参数化场景测试 ==========")
        test_data = [
            {"scenario": "1.合法关键词查询", "keyword": "三体", "expect": "三体"},
            {"scenario": "2.空关键词查询", "keyword": "", "expect": "请输入书名信息"}, # Layui必填拦截，不会发送请求
            {"scenario": "3.不存在的查无此书", "keyword": "银河系漫游飞船指南本不存在", "expect": "暂无数据"} # Layui table 空数据
        ]

        for idx, data in enumerate(test_data):
            with self.subTest(scenario=data["scenario"]):
                try:
                    driver.get(f"{self.base_url}/findBookPage")
                    input_ele = wait.until(EC.visibility_of_element_located(self.LOCATORS["find_book_input"]))
                    logger.info(f"成功跳转查阅书籍，准备输入关键词: {data['keyword']}")

                    input_ele.clear()
                    if data["keyword"]:
                        input_ele.send_keys(data["keyword"])

                    # 停顿一下，防止发送过快导致前端没拿到值就提交了
                    time.sleep(0.5)

                    submit_btn = wait.until(EC.presence_of_element_located(self.LOCATORS["find_book_btn"]))
                    driver.execute_script("arguments[0].click();", submit_btn)
                    
                    time.sleep(1)
                    
                    self.assertIn(
                        data["expect"], driver.page_source,
                        f"查阅书籍场景【{data['scenario']}】异常：未显示 '{data['expect']}'"
                    )
                    logger.info(f"查书测试断言成功：{data['scenario']}")
                except AssertionError as ae:
                    self._take_screenshot("find_book_" + data["scenario"] + "_assert_fail")
                    self.fail(str(ae))
                except Exception as e:
                    self._take_screenshot("find_book_" + data["scenario"] + "_fail")
                    self.fail(f"查书场景【{data['scenario']}】报错：{str(e)}")

    def test_5_reader_borrow_return_parameterized(self):
        """5. 读者端借阅与归还调度参数化测试（借阅调度记录模块）"""
        try:
            self._switch_to_reader()
        except Exception:
            pass # 刚才可能已经切了
        
        driver = self.driver
        wait = self.wait

        logger.info("\n========== [模块4] 借还调度记录模块参数化场景测试 ==========")
        test_data = [
            {"scenario": "1.借书-书籍ID非数字", "path": "/borrowingPage", "bookId": "abc", "expect": "请正确输入书籍编号"},
            {"scenario": "2.借书-正常借阅(Book ID=2 三体)", "path": "/borrowingPage", "bookId": "2", "expect": "借 书 成 功"},
            {"scenario": "3.还书-异常图书ID", "path": "/userReturnBooksPage", "bookId": "abc", "expect": "请正确输入书籍编号"},
            {"scenario": "4.还书-正常归还(Book ID=16 计算机网络)", "path": "/userReturnBooksPage", "bookId": "16", "expect": "还书成功"}
        ]

        for idx, data in enumerate(test_data):
            with self.subTest(scenario=data["scenario"]):
                try:
                    driver.get(f"{self.base_url}{data['path']}")
                    input_ele = wait.until(EC.visibility_of_element_located(self.LOCATORS["borrow_return_input"]))
                    
                    input_ele.clear()
                    if data["bookId"]:
                        input_ele.send_keys(data["bookId"])

                    # 停顿一下，确保输入框已经完整填入
                    time.sleep(0.5)

                    submit_btn = wait.until(EC.presence_of_element_located(self.LOCATORS["borrow_return_btn"]))
                    driver.execute_script("arguments[0].click();", submit_btn)
                    
                    message_ele = self._wait_for_layer_message(data["expect"])

                    self.assertIn(
                        data["expect"], message_ele.text,
                        f"借还调度场景【{data['scenario']}】断言失败，期望浮层包含: {data['expect']}"
                    )
                    logger.info(f"借还调度测试断言成功：{data['scenario']}")
                except AssertionError as ae:
                    self._take_screenshot("borrow_return_" + data["scenario"] + "_assert_fail")
                    self.fail(str(ae))
                except Exception as e:
                    self._take_screenshot("borrow_return_" + data["scenario"] + "_fail")
                    self.fail(f"借还调度场景【{data['scenario']}】报错：{str(e)}")

    def tearDown(self):
        logger.info("测试结束，关闭浏览器")
        self.driver.quit()


if __name__ == "__main__":
    unittest.main(verbosity=2)