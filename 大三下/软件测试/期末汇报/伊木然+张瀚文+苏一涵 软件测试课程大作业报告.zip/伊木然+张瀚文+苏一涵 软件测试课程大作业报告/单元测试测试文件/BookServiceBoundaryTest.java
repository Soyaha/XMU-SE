package com.zbw.service.impl;

import com.zbw.domain.Book;
import com.zbw.domain.BorrowingBooks;
import com.zbw.domain.Vo.BookVo;
import com.zbw.mapper.BookMapper;
import com.zbw.mapper.BorrowingBooksMapper;
import com.zbw.utils.page.Page;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BookServiceBoundaryTest {

    @Mock
    private BookMapper bookMapper;

    @Mock
    private BorrowingBooksMapper borrowingBooksMapper;

    @InjectMocks
    private BookServiceImpl bookService;

    @Test
    public void selectBooksByBookPartInfo_emptyKeyword_returnsEmptyList() {
        when(bookMapper.selectBooksByPartInfo("%%")).thenReturn(null);

        List<BookVo> result = bookService.selectBooksByBookPartInfo("");

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(bookMapper).selectBooksByPartInfo("%%");
        verifyZeroInteractions(borrowingBooksMapper);
    }

    @Test
    public void selectBooksByBookPartInfo_bookListSingleItem_andBorrowRecordEmpty_marksAvailable() {
        Book book = createBook(1, "边界值图书");
        when(bookMapper.selectBooksByPartInfo("%边界%")).thenReturn(Collections.singletonList(book));
        when(borrowingBooksMapper.selectByExample(any())).thenReturn(Collections.emptyList());

        List<BookVo> result = bookService.selectBooksByBookPartInfo("边界");

        assertEquals(1, result.size());
        assertEquals("可借", result.get(0).getIsExist());
        assertEquals("边界值图书", result.get(0).getBookName());
    }

    @Test
    public void findBooksByCategoryId_totalCountIsZero_pageCountStillOne() {
        when(bookMapper.selectByCategoryId(eq(1), eq(0), eq(10))).thenReturn(null);

        Page<BookVo> page = bookService.findBooksByCategoryId(1, 1);

        assertNotNull(page);
        assertEquals(1, page.getPageNum());
        assertEquals(1, page.getPageCount());
        assertNull(page.getList());
    }

    @Test
    public void findBooksByCategoryId_totalCountIsTen_pageCountIsOne() {
        Book book = createBook(10, "第十本书");

        when(bookMapper.selectByCategoryId(eq(2), eq(0), eq(10))).thenReturn(Collections.singletonList(book));
        when(bookMapper.selectBookCountByCategoryId(2)).thenReturn(10);
        when(borrowingBooksMapper.selectByExample(any())).thenReturn(Collections.singletonList(new BorrowingBooks()));

        Page<BookVo> page = bookService.findBooksByCategoryId(2, 1);

        assertNotNull(page.getList());
        assertEquals(1, page.getList().size());
        assertEquals(1, page.getPageCount());
        assertEquals("不可借", page.getList().get(0).getIsExist());
    }

    @Test
    public void findBooksByCategoryId_totalCountIsEleven_pageCountIsTwo() {
        Book firstBook = createBook(11, "第十一本书");
        Book secondBook = createBook(12, "第十二本书");

        when(bookMapper.selectByCategoryId(eq(3), eq(0), eq(10)))
                .thenReturn(Arrays.asList(firstBook, secondBook));
        when(bookMapper.selectBookCountByCategoryId(3)).thenReturn(11);
        when(borrowingBooksMapper.selectByExample(any())).thenReturn(Collections.emptyList());

        Page<BookVo> page = bookService.findBooksByCategoryId(3, 1);

        assertEquals(2, page.getPageCount());
        assertEquals(2, page.getList().size());
    }

    private Book createBook(int bookId, String bookName) {
        Book book = new Book();
        book.setBookId(bookId);
        book.setBookName(bookName);
        book.setBookAuthor("作者" + bookId);
        book.setBookPublish("出版社" + bookId);
        return book;
    }
}