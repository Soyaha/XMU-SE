package com.zbw.service.impl;

import com.zbw.domain.BorrowingBooks;
import com.zbw.domain.User;
import com.zbw.mapper.BookMapper;
import com.zbw.mapper.BorrowingBooksMapper;
import com.zbw.mapper.DepartmentMapper;
import com.zbw.mapper.UserMapper;
import com.zbw.utils.page.Page;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceBoundaryTest {

    @Mock
    private UserMapper userMapper;

    @Mock
    private DepartmentMapper departmentMapper;

    @Mock
    private BorrowingBooksMapper borrowingBooksMapper;

    @Mock
    private BookMapper bookMapper;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpSession session;

    @InjectMocks
    private UserServiceImpl userService;

    @Before
    public void setUp() {
        when(request.getSession()).thenReturn(session);
    }

    @Test
    public void userLogin_emptyPassword_returnsNull() {
        User user = new User();
        user.setUserName("yxc");
        user.setUserPwd("123456");
        when(userMapper.selectByExample(any())).thenReturn(Collections.singletonList(user));

        assertNull(userService.userLogin("yxc", ""));
    }

    @Test
    public void updateUser_sessionUserMissing_throwsNullPointerLikeCurrentImplementation() {
        when(session.getAttribute("user")).thenReturn(null);

        User requestUser = new User();
        requestUser.setUserName("newName");

        try {
            userService.updateUser(requestUser, request);
        } catch (NullPointerException ex) {
            assertTrue(true);
            return;
        }
        throw new AssertionError("Expected NullPointerException when session user is missing");
    }

    @Test
    public void userBorrowingBook_bookAlreadyBorrowed_returnsFalse() {
        User sessionUser = new User();
        sessionUser.setUserId(10);
        when(session.getAttribute("user")).thenReturn(sessionUser);
        when(borrowingBooksMapper.selectByExample(any())).thenReturn(Collections.singletonList(new BorrowingBooks()));

        assertFalse(userService.userBorrowingBook(3, request));
        verify(borrowingBooksMapper, never()).insert(any(BorrowingBooks.class));
    }

    @Test
    public void userBorrowingBook_bookNotBorrowedAndInsertSucceeds_returnsTrue() {
        User sessionUser = new User();
        sessionUser.setUserId(10);
        when(session.getAttribute("user")).thenReturn(sessionUser);
        when(borrowingBooksMapper.selectByExample(any())).thenReturn(Collections.emptyList());
        when(borrowingBooksMapper.insert(any(BorrowingBooks.class))).thenReturn(1);

        assertTrue(userService.userBorrowingBook(3, request));
    }

    @Test
    public void findUserByPage_totalCountIsEleven_pageCountIsTwo() {
        when(userMapper.selectByPageNum(10, 10)).thenReturn(Collections.singletonList(new User()));
        when(userMapper.selectUserCount()).thenReturn(11);

        Page<User> page = userService.findUserByPage(2);

        assertNotNull(page);
        assertEquals(2, page.getPageCount());
        assertEquals(1, page.getList().size());
    }

    @Test
    public void userReturnBook_bookIdZero_returnsFalseWhenNoDelete() {
        User sessionUser = new User();
        sessionUser.setUserId(10);
        when(session.getAttribute("user")).thenReturn(sessionUser);
        when(borrowingBooksMapper.deleteByExample(any())).thenReturn(0);

        assertFalse(userService.userReturnBook(0, request));
    }
}