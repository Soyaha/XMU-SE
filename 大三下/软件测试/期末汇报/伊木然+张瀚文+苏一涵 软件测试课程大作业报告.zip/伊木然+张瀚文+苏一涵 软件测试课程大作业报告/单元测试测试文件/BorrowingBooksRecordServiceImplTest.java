package com.zbw.service.impl;

import com.zbw.domain.Book;
import com.zbw.domain.BorrowingBooks;
import com.zbw.domain.User;
import com.zbw.domain.Vo.BorrowingBooksVo;
import com.zbw.mapper.BookMapper;
import com.zbw.mapper.BorrowingBooksMapper;
import com.zbw.mapper.UserMapper;
import com.zbw.utils.page.Page;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BorrowingBooksRecordServiceImplTest {

    @Mock
    private BorrowingBooksMapper borrowingBooksMapper;

    @Mock
    private BookMapper bookMapper;

    @Mock
    private UserMapper userMapper;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpSession session;

    @InjectMocks
    private BorrowingBooksRecordServiceImpl borrowingBooksRecordService;

    @Before
    public void setUp() {
        when(request.getSession()).thenReturn(session);
    }

    @Test
    public void tcBR1_selectAllByPage_returnsNullWhenNoRecordListExists() {
        when(borrowingBooksMapper.selectAllByPage(0, 10)).thenReturn(null);

        Page<BorrowingBooksVo> page = borrowingBooksRecordService.selectAllByPage(1);

        assertNull(page);
    }

    @Test
    public void tcBR2_selectAllByPage_returnsPageObjectWhenDataExists() {
        BorrowingBooks borrowingBooks = new BorrowingBooks();
        borrowingBooks.setUserId(1);
        borrowingBooks.setBookId(2);
        borrowingBooks.setDate(createDate(2026, Calendar.JANUARY, 15));

        User user = new User();
        user.setUserId(1);
        user.setUserName("张三");

        Book book = new Book();
        book.setBookId(2);
        book.setBookName("软件测试基础");

        when(borrowingBooksMapper.selectAllByPage(0, 10)).thenReturn(Arrays.asList(borrowingBooks));
        when(userMapper.selectByPrimaryKey(1)).thenReturn(user);
        when(bookMapper.selectByPrimaryKey(2)).thenReturn(book);
        when(borrowingBooksMapper.selectAll()).thenReturn(1);

        Page<BorrowingBooksVo> page = borrowingBooksRecordService.selectAllByPage(1);

        assertNotNull(page);
        assertEquals(1, page.getList().size());
        assertEquals(1, page.getPageNum());
        assertEquals(10, page.getPageSize());
        assertEquals("张三", page.getList().get(0).getUser().getUserName());
        assertEquals("软件测试基础", page.getList().get(0).getBook().getBookName());
    }

    @Test
    public void tcBR3_selectAllByPage_formatsBorrowAndReturnDates() {
        BorrowingBooks borrowingBooks = new BorrowingBooks();
        borrowingBooks.setUserId(1);
        borrowingBooks.setBookId(2);
        borrowingBooks.setDate(createDate(2026, Calendar.JANUARY, 15));

        User user = new User();
        user.setUserId(1);
        user.setUserName("张三");

        Book book = new Book();
        book.setBookId(2);
        book.setBookName("软件测试基础");

        when(borrowingBooksMapper.selectAllByPage(0, 10)).thenReturn(Arrays.asList(borrowingBooks));
        when(userMapper.selectByPrimaryKey(1)).thenReturn(user);
        when(bookMapper.selectByPrimaryKey(2)).thenReturn(book);
        when(borrowingBooksMapper.selectAll()).thenReturn(1);

        Page<BorrowingBooksVo> page = borrowingBooksRecordService.selectAllByPage(1);

        assertNotNull(page);
        assertEquals("2026-01-15", page.getList().get(0).getDateOfBorrowing());
        assertEquals("2026-03-15", page.getList().get(0).getDateOfReturn());
    }

    @Test
    public void tcBR4_selectAllByPage_calculatesPageCountByBoundaryValue() {
        BorrowingBooks borrowingBooks = new BorrowingBooks();
        borrowingBooks.setUserId(1);
        borrowingBooks.setBookId(2);
        borrowingBooks.setDate(createDate(2026, Calendar.JANUARY, 15));

        User user = new User();
        user.setUserId(1);
        user.setUserName("张三");

        Book book = new Book();
        book.setBookId(2);
        book.setBookName("软件测试基础");

        when(borrowingBooksMapper.selectAllByPage(0, 10)).thenReturn(Arrays.asList(borrowingBooks));
        when(userMapper.selectByPrimaryKey(1)).thenReturn(user);
        when(bookMapper.selectByPrimaryKey(2)).thenReturn(book);
        when(borrowingBooksMapper.selectAll()).thenReturn(11);

        Page<BorrowingBooksVo> page = borrowingBooksRecordService.selectAllByPage(1);

        assertNotNull(page);
        assertEquals(2, page.getPageCount());
    }

    @Test
    public void tcBR5_selectAllBorrowRecord_returnsNullWhenSessionUserMissing() {
        when(session.getAttribute("user")).thenReturn(null);

        assertNull(borrowingBooksRecordService.selectAllBorrowRecord(request));
    }

    @Test
    public void tcBR6_selectAllBorrowRecord_formatsBorrowAndReturnDates() {
        User user = new User();
        user.setUserId(5);
        user.setUserName("李四");

        BorrowingBooks borrowingBooks = new BorrowingBooks();
        borrowingBooks.setBookId(3);
        borrowingBooks.setDate(createDate(2026, Calendar.MARCH, 8));

        Book book = new Book();
        book.setBookId(3);
        book.setBookName("测试驱动开发");

        when(session.getAttribute("user")).thenReturn(user);
        when(borrowingBooksMapper.selectAllBorrowRecord(5)).thenReturn(Collections.singletonList(borrowingBooks));
        when(bookMapper.selectByPrimaryKey(3)).thenReturn(book);

        List<BorrowingBooksVo> result = borrowingBooksRecordService.selectAllBorrowRecord(request);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("2026-03-08", result.get(0).getDateOfBorrowing());
        assertEquals("2026-05-08", result.get(0).getDateOfReturn());
        assertEquals("测试驱动开发", result.get(0).getBook().getBookName());
    }

    private Date createDate(int year, int month, int dayOfMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, dayOfMonth, 0, 0, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }
}