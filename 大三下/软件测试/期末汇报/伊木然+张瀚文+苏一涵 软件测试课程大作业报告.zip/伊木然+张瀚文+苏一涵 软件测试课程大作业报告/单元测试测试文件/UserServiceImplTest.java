package com.zbw.service.impl;

import com.zbw.domain.Book;
import com.zbw.domain.BorrowingBooks;
import com.zbw.domain.Department;
import com.zbw.domain.User;
import com.zbw.domain.Vo.BorrowingBooksVo;
import com.zbw.mapper.BookMapper;
import com.zbw.mapper.BorrowingBooksMapper;
import com.zbw.mapper.DepartmentMapper;
import com.zbw.mapper.UserMapper;
import com.zbw.utils.page.Page;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Calendar;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceImplTest {

    @Mock
    private UserMapper userMapper;

    @Mock
    private DepartmentMapper departmentMapper;

    @Mock
    private BorrowingBooksMapper borrowingBooksMapper;

    @Mock
    private BookMapper bookMapper;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpSession session;

    @InjectMocks
    private UserServiceImpl userService;

    @Before
    public void setUp() {
        when(request.getSession()).thenReturn(session);
    }

    @Test
    public void findUserByUserName_returnsMatchedUsers() {
        User user = new User();
        user.setUserName("yxc");
        when(userMapper.selectByExample(any())).thenReturn(Collections.singletonList(user));

        assertEquals(1, userService.findUserByUserName("yxc").size());
    }

    @Test
    public void userLogin_returnsUserWhenPasswordMatches() {
        User user = new User();
        user.setUserName("yxc");
        user.setUserPwd("123456");
        when(userMapper.selectByExample(any())).thenReturn(Collections.singletonList(user));

        User result = userService.userLogin("yxc", "123456");

        assertSame(user, result);
    }

    @Test
    public void userLogin_returnsNullWhenPasswordDoesNotMatch() {
        User user = new User();
        user.setUserName("yxc");
        user.setUserPwd("123456");
        when(userMapper.selectByExample(any())).thenReturn(Collections.singletonList(user));

        assertNull(userService.userLogin("yxc", "000000"));
    }

    @Test
    public void userLogin_returnsNullWhenUserNotFound() {
        when(userMapper.selectByExample(any())).thenReturn(null);

        assertNull(userService.userLogin("missing", "123456"));
    }

    @Test
    public void updateUser_updatesSessionWhenDatabaseWriteSucceeds() {
        User sessionUser = new User();
        sessionUser.setUserId(8);
        when(session.getAttribute("user")).thenReturn(sessionUser);

        User requestUser = new User();
        requestUser.setUserName("newName");
        requestUser.setUserPwd("newPwd");

        User refreshedUser = new User();
        refreshedUser.setUserId(8);
        refreshedUser.setUserName("newName");
        refreshedUser.setUserPwd("newPwd");

        when(userMapper.updateByPrimaryKey(any(User.class))).thenReturn(1);
        when(userMapper.selectByPrimaryKey(8)).thenReturn(refreshedUser);

        boolean result = userService.updateUser(requestUser, request);

        assertTrue(result);
        ArgumentCaptor<User> captor = ArgumentCaptor.forClass(User.class);
        verify(userMapper).updateByPrimaryKey(captor.capture());
        assertEquals(Integer.valueOf(8), captor.getValue().getUserId());
        verify(session).setAttribute("user", refreshedUser);
    }

    @Test
    public void updateUser_returnsFalseWhenDatabaseWriteFails() {
        User sessionUser = new User();
        sessionUser.setUserId(8);
        when(session.getAttribute("user")).thenReturn(sessionUser);

        User requestUser = new User();
        requestUser.setUserName("newName");
        requestUser.setUserPwd("newPwd");

        when(userMapper.updateByPrimaryKey(any(User.class))).thenReturn(0);

        boolean result = userService.updateUser(requestUser, request);

        assertFalse(result);
        verify(userMapper).updateByPrimaryKey(any(User.class));
    }

    @Test
    public void userBorrowingBook_returnsFalseWhenBookAlreadyBorrowed() {
        User sessionUser = new User();
        sessionUser.setUserId(10);
        when(session.getAttribute("user")).thenReturn(sessionUser);
        when(borrowingBooksMapper.selectByExample(any())).thenReturn(Collections.singletonList(new BorrowingBooks()));

        assertFalse(userService.userBorrowingBook(3, request));
        verify(borrowingBooksMapper, never()).insert(any(BorrowingBooks.class));
    }

    @Test
    public void userBorrowingBook_returnsTrueWhenInsertSucceeds() {
        User sessionUser = new User();
        sessionUser.setUserId(10);
        when(session.getAttribute("user")).thenReturn(sessionUser);
        when(borrowingBooksMapper.selectByExample(any())).thenReturn(Collections.emptyList());
        when(borrowingBooksMapper.insert(any(BorrowingBooks.class))).thenReturn(1);

        assertTrue(userService.userBorrowingBook(3, request));
    }

    @Test
    public void userReturnBook_returnsTrueWhenDeleteSucceeds() {
        User sessionUser = new User();
        sessionUser.setUserId(10);
        when(session.getAttribute("user")).thenReturn(sessionUser);
        when(borrowingBooksMapper.deleteByExample(any())).thenReturn(1);

        assertTrue(userService.userReturnBook(3, request));
    }

    @Test
    public void userReturnBook_returnsFalseWhenDeleteFails() {
        User sessionUser = new User();
        sessionUser.setUserId(10);
        when(session.getAttribute("user")).thenReturn(sessionUser);
        when(borrowingBooksMapper.deleteByExample(any())).thenReturn(0);

        assertFalse(userService.userReturnBook(3, request));
    }

    @Test
    public void findAllDepts_returnsAllDepartments() {
        Department dept = new Department();
        dept.setDeptId(1);
        dept.setDeptName("计算机学院");
        when(departmentMapper.selectByExample(any())).thenReturn(Collections.singletonList(dept));

        List<Department> depts = userService.findAllDepts();

        assertNotNull(depts);
        assertEquals(1, depts.size());
        assertEquals("计算机学院", depts.get(0).getDeptName());
    }

    @Test
    public void findAllBorrowingBooks_returnsBorrowingBooksList() {
        User sessionUser = new User();
        sessionUser.setUserId(10);
        sessionUser.setUserName("yxc");
        when(session.getAttribute("user")).thenReturn(sessionUser);

        BorrowingBooks borrowingBooks = new BorrowingBooks();
        borrowingBooks.setBookId(3);
        borrowingBooks.setDate(createDate(2026, Calendar.APRIL, 10));

        Book book = new Book();
        book.setBookId(3);
        book.setBookName("软件测试基础");

        when(borrowingBooksMapper.selectByExample(any())).thenReturn(Collections.singletonList(borrowingBooks));
        when(bookMapper.selectByPrimaryKey(3)).thenReturn(book);

        List<BorrowingBooksVo> result = userService.findAllBorrowingBooks(request);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("软件测试基础", result.get(0).getBook().getBookName());
        assertEquals("2026-04-10", result.get(0).getDateOfBorrowing());
        assertEquals("2026-06-10", result.get(0).getDateOfReturn());
    }

    @Test
    public void findUserById_returnsUserById() {
        User user = new User();
        user.setUserId(7);
        user.setUserName("testUser");
        when(userMapper.selectByPrimaryKey(7)).thenReturn(user);

        User result = userService.findUserById(7);

        assertNotNull(result);
        assertEquals(Integer.valueOf(7), result.getUserId());
        assertEquals("testUser", result.getUserName());
    }

    @Test
    public void insertUser_returnsInsertedCount() {
        User user = new User();
        user.setUserName("newUser");
        when(userMapper.insert(user)).thenReturn(1);

        assertEquals(1, userService.insertUser(user));
    }

    @Test
    public void deleteUserById_returnsDeletedCount() {
        when(userMapper.deleteByPrimaryKey(9)).thenReturn(1);

        assertEquals(1, userService.deleteUserById(9));
    }

    private Date createDate(int year, int month, int dayOfMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, dayOfMonth, 0, 0, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    @Test
    public void findUserByPage_calculatesBoundaryPageCount() {
        when(userMapper.selectByPageNum(10, 10)).thenReturn(Arrays.asList(new User()));
        when(userMapper.selectUserCount()).thenReturn(11);

        Page<User> page = userService.findUserByPage(2);

        assertNotNull(page);
        assertEquals(2, page.getPageNum());
        assertEquals(10, page.getPageSize());
        assertEquals(2, page.getPageCount());
        assertEquals(1, page.getList().size());
    }
}