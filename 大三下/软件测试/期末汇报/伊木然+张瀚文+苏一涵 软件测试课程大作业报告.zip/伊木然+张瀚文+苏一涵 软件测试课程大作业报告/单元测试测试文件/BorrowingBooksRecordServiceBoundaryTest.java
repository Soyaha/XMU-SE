package com.zbw.service.impl;

import com.zbw.domain.Book;
import com.zbw.domain.BorrowingBooks;
import com.zbw.domain.User;
import com.zbw.domain.Vo.BorrowingBooksVo;
import com.zbw.mapper.BookMapper;
import com.zbw.mapper.BorrowingBooksMapper;
import com.zbw.mapper.UserMapper;
import com.zbw.utils.page.Page;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BorrowingBooksRecordServiceBoundaryTest {

    @Mock
    private BorrowingBooksMapper borrowingBooksMapper;

    @Mock
    private BookMapper bookMapper;

    @Mock
    private UserMapper userMapper;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpSession session;

    @InjectMocks
    private BorrowingBooksRecordServiceImpl borrowingBooksRecordService;

    @Before
    public void setUp() {
        when(request.getSession()).thenReturn(session);
    }

    @Test
    public void selectAllByPage_totalCountIsZero_pageCountIsOne() {
        when(borrowingBooksMapper.selectAllByPage(0, 10)).thenReturn(null);

        Page<BorrowingBooksVo> page = borrowingBooksRecordService.selectAllByPage(1);

        assertNull(page);
    }

    @Test
    public void selectAllByPage_totalCountIsEleven_pageCountIsTwo() {
        BorrowingBooks borrowingBooks = new BorrowingBooks();
        borrowingBooks.setUserId(1);
        borrowingBooks.setBookId(2);
        borrowingBooks.setDate(createDate(2026, Calendar.JANUARY, 15));

        User user = new User();
        user.setUserId(1);
        user.setUserName("边界用户");

        Book book = new Book();
        book.setBookId(2);
        book.setBookName("边界图书");

        when(borrowingBooksMapper.selectAllByPage(0, 10)).thenReturn(Collections.singletonList(borrowingBooks));
        when(userMapper.selectByPrimaryKey(1)).thenReturn(user);
        when(bookMapper.selectByPrimaryKey(2)).thenReturn(book);
        when(borrowingBooksMapper.selectAll()).thenReturn(11);

        Page<BorrowingBooksVo> page = borrowingBooksRecordService.selectAllByPage(1);

        assertNotNull(page);
        assertEquals(2, page.getPageCount());
    }

    @Test
    public void selectAllBorrowRecord_sessionUserIsNull_returnsNull() {
        when(session.getAttribute("user")).thenReturn(null);

        assertNull(borrowingBooksRecordService.selectAllBorrowRecord(request));
    }

    @Test
    public void selectAllBorrowRecord_dateBoundary_formatsCorrectReturnDate() {
        User user = new User();
        user.setUserId(5);

        BorrowingBooks borrowingBooks = new BorrowingBooks();
        borrowingBooks.setBookId(3);
        borrowingBooks.setDate(createDate(2026, Calendar.MARCH, 31));

        Book book = new Book();
        book.setBookId(3);
        book.setBookName("月末边界图书");

        when(session.getAttribute("user")).thenReturn(user);
        when(borrowingBooksMapper.selectAllBorrowRecord(5)).thenReturn(Collections.singletonList(borrowingBooks));
        when(bookMapper.selectByPrimaryKey(3)).thenReturn(book);

        assertEquals(1, borrowingBooksRecordService.selectAllBorrowRecord(request).size());
    }

    private Date createDate(int year, int month, int dayOfMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, dayOfMonth, 0, 0, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }
}