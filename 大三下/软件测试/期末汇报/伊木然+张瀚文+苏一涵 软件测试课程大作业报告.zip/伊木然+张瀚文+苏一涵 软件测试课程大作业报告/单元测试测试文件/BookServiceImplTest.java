package com.zbw.service.impl;

import com.zbw.domain.Book;
import com.zbw.domain.BorrowingBooks;
import com.zbw.domain.Vo.BookVo;
import com.zbw.mapper.BookMapper;
import com.zbw.mapper.BorrowingBooksMapper;
import com.zbw.utils.page.Page;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class BookServiceImplTest {

    @Mock
    private BookMapper bookMapper;

    @Mock
    private BorrowingBooksMapper borrowingBooksMapper;

    @InjectMocks
    private BookServiceImpl bookService;

    @Test
    public void tcB1_selectBooksByBookPartInfo_returnsEmptyListWhenNoBooksFound() {
        when(bookMapper.selectBooksByPartInfo("%不存在%"))
                .thenReturn(null);

        List<BookVo> result = bookService.selectBooksByBookPartInfo("不存在");

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(bookMapper).selectBooksByPartInfo("%不存在%");
        verifyZeroInteractions(borrowingBooksMapper);
    }

    @Test
        public void tcB2_selectBooksByBookPartInfo_marksAvailableBook() {
        Book availableBook = createBook(1, "三体");

        when(bookMapper.selectBooksByPartInfo("%书名%"))
            .thenReturn(Collections.singletonList(availableBook));
        when(borrowingBooksMapper.selectByExample(any()))
            .thenReturn(Collections.emptyList());

        List<BookVo> result = bookService.selectBooksByBookPartInfo("书名");

        assertEquals(1, result.size());
        assertEquals("可借", result.get(0).getIsExist());
        assertEquals("三体", result.get(0).getBookName());
        verify(bookMapper).selectBooksByPartInfo("%书名%");
        verify(borrowingBooksMapper, never()).selectByExample(null);
        }

        @Test
        public void tcB3_selectBooksByBookPartInfo_marksBorrowedBook() {
        Book borrowedBook = createBook(2, "平凡的世界");

        when(bookMapper.selectBooksByPartInfo("%书名%"))
            .thenReturn(Collections.singletonList(borrowedBook));
        when(borrowingBooksMapper.selectByExample(any()))
            .thenReturn(Collections.singletonList(new BorrowingBooks()));

        List<BookVo> result = bookService.selectBooksByBookPartInfo("书名");

        assertEquals(1, result.size());
        assertEquals("不可借", result.get(0).getIsExist());
        assertEquals("平凡的世界", result.get(0).getBookName());
        verify(bookMapper).selectBooksByPartInfo("%书名%");
        verify(borrowingBooksMapper, never()).selectByExample(null);
    }

    @Test
        public void tcB4_findBooksByCategoryId_returnsSinglePageWhenNoBooksExist() {
        when(bookMapper.selectByCategoryId(eq(3), eq(0), eq(10)))
                .thenReturn(null);

        Page<BookVo> page = bookService.findBooksByCategoryId(3, 1);

        assertNotNull(page);
        assertEquals(1, page.getPageNum());
        assertEquals(1, page.getPageCount());
        assertNull(page.getList());
    }

    @Test
    public void tcB5_findBooksByCategoryId_calculatesPageCountByBoundaryValue() {
        Book firstBook = createBook(10, "Java核心技术");
        Book secondBook = createBook(11, "算法导论");

        when(bookMapper.selectByCategoryId(eq(1), eq(0), eq(10)))
                .thenReturn(Arrays.asList(firstBook, secondBook));
        when(bookMapper.selectBookCountByCategoryId(1)).thenReturn(11);
        when(borrowingBooksMapper.selectByExample(any()))
                .thenReturn(Collections.emptyList());

        Page<BookVo> page = bookService.findBooksByCategoryId(1, 1);

        assertNotNull(page.getList());
        assertEquals(2, page.getList().size());
        assertEquals(1, page.getPageNum());
        assertEquals(10, page.getPageSize());
        assertEquals(2, page.getPageCount());
        assertEquals("可借", page.getList().get(0).getIsExist());
        assertEquals("可借", page.getList().get(1).getIsExist());
    }

    @Test
    public void tcB6_findBooksByCategoryId_marksMixedBorrowStatus() {
        Book availableBook = createBook(20, "可借图书");
        Book borrowedBook = createBook(21, "借出图书");

        when(bookMapper.selectByCategoryId(eq(4), eq(0), eq(10)))
                .thenReturn(Arrays.asList(availableBook, borrowedBook));
        when(bookMapper.selectBookCountByCategoryId(4)).thenReturn(2);
        when(borrowingBooksMapper.selectByExample(any()))
                .thenReturn(Collections.emptyList())
                .thenReturn(Collections.singletonList(new BorrowingBooks()));

        Page<BookVo> page = bookService.findBooksByCategoryId(4, 1);

        assertNotNull(page.getList());
        assertEquals(2, page.getList().size());
        assertEquals("可借", page.getList().get(0).getIsExist());
        assertEquals("不可借", page.getList().get(1).getIsExist());
    }

    private Book createBook(int bookId, String bookName) {
        Book book = new Book();
        book.setBookId(bookId);
        book.setBookName(bookName);
        book.setBookAuthor("作者" + bookId);
        book.setBookPublish("出版社" + bookId);
        return book;
    }
}