import re

with open(r'c:\Users\HP\Desktop\library_manager_system-master\library_manager_system-master\src\main\java\com\zbw\service\impl\BookServiceImpl.java', 'r', encoding='utf-8', errors='ignore') as f:
    text = f.read()

text = re.sub(r'\"��.\?\);', r'\"�ɽ�\");', text)
text = re.sub(r'\"����.\?\);', r'\"���ɽ�\");', text)
text = re.sub(r'\"��\?\);', r'\"�ɽ�\");', text)
text = re.sub(r'\"����\?\);', r'\"���ɽ�\");', text)

with open(r'c:\Users\HP\Desktop\library_manager_system-master\library_manager_system-master\src\main\java\com\zbw\service\impl\BookServiceImpl.java', 'w', encoding='utf-8') as f:
    f.write(text)
