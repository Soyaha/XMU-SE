# Upgrade Plan: library_manager_system-master (20260427120318)

- **Generated**: 2026-04-27
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 24: C:\Program Files\Java\jdk-24\bin (Target version)

**Build Tools**
- Maven 3.x: D:\IntelliJ IDEA 2025.1.3\plugins\maven\lib\maven3\bin

## Guidelines

- ����Ŀ�еĴ����Ϊ�ʺ�jdk24�ĵ�Ч���룬ʵ�ֵ�Ŀ��Ҫ��ͬ

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260427120318
- Run tests before and after the upgrade: true

## Upgrade Goals

- Upgrade Java to 24
- Upgrade Spring Boot to 3.x (required for JDK 24 compatibility)

### Technology Stack

| Technology/Dependency | Current | Min Compatible | Why Incompatible |
| --------------------- | ------- | -------------- | ---------------- |
| Java | 1.8 | 24 | User requested |
| Spring Boot | 2.3.2.RELEASE | 3.4.0 | User requested (indirectly, for Java 24 support) |
| mybatis-spring-boot-starter | 1.3.2 | 3.0.3 | Requires update for Spring Boot 3.x compatibility |
| mysql-connector-java | unknown | unknown | May require update for newer Java/Spring Boot |

### Derived Upgrades

- Upgrade Spring Boot to 3.4.x (Java 24 support)
- Migrate from javax.* to jakarta.* (Spring Boot 3.x uses jakarta.*)
- Upgrade mybatis-spring-boot-starter to 3.x (Spring Boot 3.x compatibility)

## Upgrade Steps

- **Step 1: Setup Environment**
  - **Rationale**: Ensure required JDKs and build tools are available.
  - **Changes to Make**:
    - [ ] Verify JDK 24 is available.
  - **Verification**:
    - Command: #appmod-list-jdks to confirm installations
    - Expected: JDK 24 is available.

- **Step 2: Setup Baseline**
  - **Rationale**: Establish pre-upgrade compile and test results to measure upgrade success against.
  - **Changes to Make**:
    - [ ] Run baseline compilation.
  - **Verification**:
    - Command: mvn clean compile test-compile -q
    - JDK: System Default (Java 8/11/etc)
    - Expected: Document SUCCESS/FAILURE.

- **Step 3: Upgrade to Java 24 and Spring Boot 3.x**
  - **Rationale**: Core framework upgrade and Java version bump.
  - **Changes to Make**:
    - [ ] Update spring-boot-starter-parent to 3.4.0
    - [ ] Update java.version property to 24
    - [ ] Update mybatis-spring-boot-starter to 3.0.3
    - [ ] Replace javax. packages with jakarta.
    - [ ] Fix compilation errors.
  - **Verification**:
    - Command: mvn clean test-compile -q
    - JDK: C:\Program Files\Java\jdk-24\bin
    - Expected: Compilation SUCCESS.

- **Step 4: Final Validation**
  - **Rationale**: Verify all upgrade goals met, project compiles successfully, all tests pass.
  - **Changes to Make**:
    - [ ] Clean rebuild with JDK 24
    - [ ] Run full test suite and fix any test failures
  - **Verification**:
    - Command: mvn clean test -q
    - JDK: C:\Program Files\Java\jdk-24\bin
    - Expected: Compilation SUCCESS + 100% tests pass.

## Key Challenges

- **Jakarta EE Namespace Migration**
   - **Challenge**: Codebase likely uses javax.* packages that must migrate to jakarta.* in Spring Boot 3+.
   - **Strategy**: Manually replace javax imports with jakarta imports in source files.
