# 图书管理系统单元测试汇报材料

## 1. 测试对象与选择理由

本次汇报选取服务层作为单元测试对象，原因是服务层直接承载业务规则，适合做程序流图、基本路径、边界值和覆盖率演示。

重点对象：

- [BookServiceImpl](src/main/java/com/zbw/service/impl/BookServiceImpl.java)
- [BorrowingBooksRecordServiceImpl](src/main/java/com/zbw/service/impl/BorrowingBooksRecordServiceImpl.java)
- [UserServiceImpl](src/main/java/com/zbw/service/impl/UserServiceImpl.java)

对应测试类：

- [BookServiceImplTest](src/test/java/com/zbw/service/impl/BookServiceImplTest.java)
- [BorrowingBooksRecordServiceImplTest](src/test/java/com/zbw/service/impl/BorrowingBooksRecordServiceImplTest.java)
- [UserServiceImplTest](src/test/java/com/zbw/service/impl/UserServiceImplTest.java)

## 2. 程序流程图

### 2.1 图书查询主流程

```mermaid
flowchart TD
    A[输入 partInfo] --> B[调用 bookMapper.selectBooksByPartInfo]
    B --> C{books 是否为空}
    C -- 是 --> D[返回空 list]
    C -- 否 --> E[遍历每本书]
    E --> F[根据 bookId 查询借阅记录]
    F --> G{借阅记录是否为空}
    G -- 是 --> H[状态设为 可借]
    G -- 否 --> I[状态设为 不可借]
    H --> J[封装 BookVo]
    I --> J
    J --> K[返回结果列表]
```

### 2.2 借阅记录分页主流程

```mermaid
flowchart TD
    A[输入 pageNum] --> B[查询当前页借阅记录]
    B --> C{list 是否为空}
    C -- 是 --> D[返回 null]
    C -- 否 --> E[遍历记录]
    E --> F[查询用户与图书信息]
    F --> G[格式化借书日期]
    G --> H[计算归还日期 +2 个月]
    H --> I[封装 BorrowingBooksVo]
    I --> J[统计总记录数]
    J --> K[计算总页数]
    K --> L[返回 Page]
```

## 3. 基本路径导出

### 3.1 BookServiceImpl.selectBooksByBookPartInfo

控制流节点：

1. 输入 partInfo
2. 调用书籍查询
3. 判断 books 是否为空
4. 遍历每本书
5. 查询借阅记录
6. 判断是否可借
7. 生成 BookVo
8. 返回结果

基本路径：

- P1：books 为空，直接返回空列表
- P2：books 非空，且借阅记录为空，状态为 可借
- P3：books 非空，且借阅记录非空，状态为 不可借

### 3.2 UserServiceImpl.userBorrowingBook

控制流节点：

1. 获取当前登录用户
2. 查询该书是否已被借出
3. 如果已借出则返回 false
4. 如果未借出则创建借阅记录
5. 插入数据库
6. 根据插入结果返回 true 或 false

基本路径：

- P1：该书已借出，直接返回 false
- P2：该书未借出，插入成功，返回 true
- P3：该书未借出，但插入失败或抛异常，返回 false

## 4. 测试用例表格

| 用例编号 | 测试对象 | 测试目标 | 输入数据 | 前置条件 | 预期结果 |
|---|---|---|---|---|---|
| TC-01 | BookServiceImpl.selectBooksByBookPartInfo | 空查询结果处理 | partInfo = 不存在 | bookMapper 返回 null | 返回空列表，不报错 |
| TC-02 | BookServiceImpl.selectBooksByBookPartInfo | 可借状态分支 | partInfo = 书名 | 第一条借阅记录为空 | 第一条书状态为 可借 |
| TC-03 | BookServiceImpl.selectBooksByBookPartInfo | 不可借状态分支 | partInfo = 书名 | 第二条借阅记录非空 | 第二条书状态为 不可借 |
| TC-04 | BookServiceImpl.findBooksByCategoryId | 空分页边界 | categoryId = 3, pageNum = 1 | 查询结果为空 | pageNum=1，pageCount=1，list 为空 |
| TC-05 | BookServiceImpl.findBooksByCategoryId | 页数边界 | categoryId = 1, pageNum = 1 | 总记录数 = 11 | pageCount = 2 |
| TC-06 | BorrowingBooksRecordServiceImpl.selectAllByPage | 空记录分支 | pageNum = 1 | selectAllByPage 返回 null | 方法返回 null |
| TC-07 | BorrowingBooksRecordServiceImpl.selectAllByPage | 日期转换 | pageNum = 1 | 借书日期 = 2026-01-15 | 还书日期 = 2026-03-15 |
| TC-08 | BorrowingBooksRecordServiceImpl.selectAllBorrowRecord | session 空边界 | request 中无 user | session.getAttribute("user") 返回 null | 返回 null |
| TC-09 | BorrowingBooksRecordServiceImpl.selectAllBorrowRecord | 正常借阅记录转换 | request 中有 user | 借书记录存在 | 正确封装书籍与日期 |
| TC-10 | UserServiceImpl.userLogin | 密码匹配 | 用户名 yxc，密码 123456 | 查到对应用户 | 返回该用户对象 |
| TC-11 | UserServiceImpl.userLogin | 密码不匹配 | 用户名 yxc，密码 000000 | 查到用户但密码不同 | 返回 null |
| TC-12 | UserServiceImpl.updateUser | 更新成功 | session 中有 user | updateByPrimaryKey 返回 1 | session 被刷新，返回 true |
| TC-13 | UserServiceImpl.userBorrowingBook | 已借出边界 | bookId = 3 | 借阅记录已存在 | 返回 false |
| TC-14 | UserServiceImpl.userBorrowingBook | 成功借书 | bookId = 3 | 借阅记录为空且插入成功 | 返回 true |

## 5. 设计测试类及运行

测试方式采用 JUnit4 + Mockito，避免依赖真实数据库，适合做真正意义上的单元测试。

### 5.1 测试类设计

- [BookServiceImplTest](src/test/java/com/zbw/service/impl/BookServiceImplTest.java)
- [BorrowingBooksRecordServiceImplTest](src/test/java/com/zbw/service/impl/BorrowingBooksRecordServiceImplTest.java)
- [UserServiceImplTest](src/test/java/com/zbw/service/impl/UserServiceImplTest.java)

### 5.2 IDEA 运行步骤

1. 在 IDEA 中打开测试类。
2. 右键测试类，选择 Run。
3. 观察 Console 输出和绿色通过标记。
4. 运行 Coverage 版本，查看类覆盖率和行覆盖率。

## 6. 覆盖率测试说明

### 6.1 使用 IDEA 的 Run with Coverage

建议对以下三个类进行覆盖率演示：

- [BookServiceImpl](src/main/java/com/zbw/service/impl/BookServiceImpl.java)
- [BorrowingBooksRecordServiceImpl](src/main/java/com/zbw/service/impl/BorrowingBooksRecordServiceImpl.java)
- [UserServiceImpl](src/main/java/com/zbw/service/impl/UserServiceImpl.java)

### 6.2 汇报口径

可在 PPT 中这样说明：

- 类覆盖率：测试类是否命中了目标类中的方法。
- 行覆盖率：目标方法中是否执行到了关键分支和主要语句。
- 分支覆盖：空值分支、正常分支、边界分支是否都被覆盖。

### 6.3 可直接填写的统计表

| 类名 | 类覆盖率 | 行覆盖率 | 说明 |
|---|---:|---:|---|
| BookServiceImpl | 待填 | 待填 | 查询、分页、可借/不可借分支 |
| BorrowingBooksRecordServiceImpl | 待填 | 待填 | 日期转换、空值分支 |
| UserServiceImpl | 待填 | 待填 | 登录、修改、借书、还书 |

## 7. 边界测试说明

本项目的边界测试重点如下：

- 空查询结果：books = null
- 空借阅记录：borrowingBooksList = null
- 空 session：request.getSession().getAttribute("user") = null
- 分页边界：总记录数 0、1、10、11
- 借书边界：该书已借出时直接返回 false

这些边界已经在单元测试中体现，便于在 PPT 中展示“正常值、异常值、边界值”三类等价划分。

## 8. JProfiler 演示脚本

### 8.1 演示目标

演示对象建议选 [UserServiceImpl](src/main/java/com/zbw/service/impl/UserServiceImpl.java) 的借书与还书流程，因为它同时包含：

- 对象创建
- 集合遍历
- 日期生成与格式化
- 数据库写入与删除调用
- 异常分支

### 8.2 操作步骤

1. 启动项目并登录普通用户账号。
2. 打开 JProfiler，Attach 到 Spring Boot 进程。
3. 进入 CPU Telemetry，观察 CPU 占用变化。
4. 进入 Memory View，观察对象分配和堆内存变化。
5. 进入 GC Activity，观察垃圾回收触发情况。
6. 进入 Classes 视图，观察类加载数量。
7. 进入 Threads 视图，观察线程状态变化。
8. 在页面执行借书动作，重点观察 [UserServiceImpl.userBorrowingBook](src/main/java/com/zbw/service/impl/UserServiceImpl.java) 的执行峰值。
9. 再执行还书动作，对比对象分配和 CPU 波动。

### 8.3 汇报时的讲解词

- “借书流程会先查借阅表，再创建 BorrowingBooks 对象并插入数据库，所以 CPU 和对象分配会有短暂上升。”
- “还书流程主要是构造查询条件并执行删除，整体对象开销比借书流程更小。”
- “在 JProfiler 中可以同时看到内存、GC、类加载和线程状态，证明这个单元测试方案不仅覆盖功能，而且方便做性能观察。”

## 9. PPT 页面建议

建议拆成 5 页：

1. 测试对象与方法选择
2. 程序流程图与基本路径
3. 测试用例表格
4. 覆盖率说明与边界测试
5. JProfiler 演示脚本

## 10. 单元测试部分正式报告稿

### 10.1 测试目标

本次单元测试针对图书管理系统的服务层展开，重点验证核心业务逻辑是否正确、边界条件是否处理完整、主要分支是否被覆盖，以及关键方法在运行时的资源开销是否可控。由于系统的主要功能集中在图书查询、借阅记录管理和用户信息管理，因此选择 [BookServiceImpl](src/main/java/com/zbw/service/impl/BookServiceImpl.java)、[BorrowingBooksRecordServiceImpl](src/main/java/com/zbw/service/impl/BorrowingBooksRecordServiceImpl.java) 和 [UserServiceImpl](src/main/java/com/zbw/service/impl/UserServiceImpl.java) 作为单元测试对象。

### 10.2 测试方法与工具

单元测试采用 JUnit4 + Mockito 组合完成。JUnit4 用于组织测试用例并判断输出结果是否符合预期，Mockito 用于模拟 Mapper、HttpServletRequest、HttpSession 等外部依赖，从而把测试重点放在业务逻辑本身，避免真实数据库和 Web 环境干扰。覆盖率统计使用 JaCoCo，运行效能观察使用 JProfiler。

### 10.3 测试用例设计思路

测试用例按照正常值、异常值和边界值三类设计：

- 正常值：验证典型业务路径是否正确，例如正常登录、正常借书、正常分页查询。
- 异常值：验证空结果、空会话、查无数据等情况是否能被正确处理。
- 边界值：验证分页数为 1、10、11 等临界场景，以及借阅记录为空和已存在等边界场景。

本项目已经补充了 14 个以上的单元测试点，覆盖了图书查询、用户登录、借还书、分页查询、记录转换和用户信息增删改查等核心逻辑。

### 10.4 测试类设计及运行结果

测试类采用“一个服务类对应一个测试类”的方式组织，结构清晰，便于定位问题和统计覆盖率：

- [BookServiceImplTest](src/test/java/com/zbw/service/impl/BookServiceImplTest.java)
- [BorrowingBooksRecordServiceImplTest](src/test/java/com/zbw/service/impl/BorrowingBooksRecordServiceImplTest.java)
- [UserServiceImplTest](src/test/java/com/zbw/service/impl/UserServiceImplTest.java)

运行结果显示，相关测试类均可正常执行，核心业务分支已被覆盖。

[在此插入截图：JUnit 测试类运行通过界面]

### 10.5 覆盖率测试结果

使用 Coverage 方式运行测试后，可以在 IDEA 或 JaCoCo HTML 报告中查看类覆盖率、行覆盖率和分支覆盖情况。当前覆盖率提升主要来自对 `UserServiceImpl` 的补测，新增测试补齐了 `findAllBorrowingBooks`、`findUserById`、`insertUser`、`deleteUserById` 等方法。

[在此插入截图：JaCoCo 覆盖率报告首页]

[在此插入截图：UserServiceImpl 覆盖率详情]

可在汇报中这样说明：

- 类覆盖率反映目标类中的方法是否被测试触达。
- 行覆盖率反映方法内部的主要语句是否被执行。
- 分支覆盖率反映空值判断、失败返回、异常分支是否都被覆盖到。

### 10.6 边界测试结果

本项目的边界测试重点放在以下几类场景：

- 查询结果为空时是否返回空列表或 null。
- session 中没有用户对象时是否返回 null。
- 分页边界下页数是否计算正确，尤其是 0、1、10、11 这些临界值。
- 借书记录已存在时是否直接返回 false，避免重复借阅。

[在此插入截图：边界测试用例表或单元测试执行结果]

### 10.7 行代码运行效能测试

行代码运行效能测试不是单纯看代码能否通过，而是观察目标方法在执行时的资源消耗情况，包括 CPU 使用、对象分配、内存变化和 GC 行为。针对本项目，最适合演示的对象是 [UserServiceImpl.userBorrowingBook](src/main/java/com/zbw/service/impl/UserServiceImpl.java) 和 [UserServiceImpl.findAllBorrowingBooks](src/main/java/com/zbw/service/impl/UserServiceImpl.java)，因为这两个方法同时包含对象创建、集合遍历、日期处理和 Mapper 调用，运行时特征比较明显。

测试时可使用 JProfiler 观察以下内容：

- CPU Telemetry：查看借书、还书执行时的瞬时 CPU 波动。
- Memory View：查看对象分配量和堆内存变化。
- GC Activity：查看是否产生明显垃圾回收压力。
- Threads：查看测试或接口执行期间线程状态是否异常。

[在此插入截图：JProfiler CPU / Memory / GC 视图]

### 10.8 内存泄漏测试

内存泄漏测试主要观察对象是否在业务结束后无法正常释放。本项目中，单元测试层通过 Mockito 模拟依赖，避免引入真实数据库连接和长生命周期对象，因此更适合验证业务方法本身是否存在异常对象堆积。实际演示时可重点关注借阅记录查询和借书流程，反复执行多次后观察堆内存是否稳定、GC 是否能正常回收。

[在此插入截图：JProfiler 堆内存变化或对象分配统计]

### 10.9 单元测试总结

本次单元测试围绕图书管理系统的核心服务层展开，完成了测试用例设计、JUnit 测试类编写、覆盖率统计、边界测试、运行效能观察和内存泄漏观察。整体上，测试覆盖了系统的主要业务路径，能够支撑课程报告中“正确性验证 + 覆盖率验证 + 效能分析”的要求。

如果需要在答辩中简要总结，可以概括为：

“我们通过 JUnit4 和 Mockito 对服务层进行了单元测试，使用 JaCoCo 验证覆盖率，并结合 JProfiler 对借书、还书等核心流程做了运行效能和内存观察。测试结果表明，系统的主要业务逻辑能够正确执行，边界条件处理基本完整，核心方法的运行资源开销处于可接受范围。”
