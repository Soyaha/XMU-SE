data = [1, 2, 3, 12, 20, 100, 6, 9, 12, 8,8, 3]

# 求平均值
def average_value():
    return sum(data)/len(data)

# 求最大值
def max_value():
    return max(data)

# 冒泡排序
def bubble_sort():
    n = len(data)
    for i in range(n):
        for j in range(0, n - i - 1):
            if data[j] > data[j + 1]:
                data[j], data[j + 1] = data[j + 1], data[j]
    return data

# 在指定位置插入元素
def insert_element(position, element):
    data.insert(position, element)
    return data

# 删除指定位置的元素
def delete_element(position):
    del data[position]
    return data


print("平均值:", average_value())
print("最大值:", max_value())
print("排序后的data:", bubble_sort())
print("插入元素后的data:", insert_element(2, 5))
print("删除元素后的data:", delete_element(3))