
class BMPConverter24to8:
    def __init__(self, input_file, output_file):
        self.input_file = input_file
        self.output_file = output_file
        self.file_header = None
        self.info_header = None
        self.pixel_data = []

    def read_24bpp_bmp(self):
        with open(self.input_file, 'rb') as f:
            # 读取文件头（14字节）
            self.file_header = f.read(14)
            # 读取信息头（40字节）
            self.info_header = f.read(40)
            # 计算像素数据起始位置
            pixel_data_offset = int.from_bytes(self.file_header[10:14], 'little')
            f.seek(pixel_data_offset)
            width = int.from_bytes(self.info_header[4:8], 'little')
            height = int.from_bytes(self.info_header[8:12], 'little')
            # 读取像素数据
            for _ in range(height):
                row = []
                for _ in range(width):
                    b = int.from_bytes(f.read(1), 'little')
                    g = int.from_bytes(f.read(1), 'little')
                    r = int.from_bytes(f.read(1), 'little')
                    gray = int(0.299 * r + 0.587 * g + 0.114 * b)
                    row.append(gray)
                self.pixel_data.append(row)

    def create_8bpp_file_header(self):
        file_size = 14 + 40 + 256 * 4 + len(self.pixel_data) * len(self.pixel_data[0])
        new_file_header = bytearray(14)
        new_file_header[:2] = b'BM'  # 文件类型
        new_file_header[2:6] = file_size.to_bytes(4, 'little')  # 文件大小
        new_file_header[6:10] = b'\x00\x00\x00\x00'  # 保留位
        new_file_header[10:14] = (14 + 40 + 256 * 4).to_bytes(4, 'little')  # 像素数据偏移量
        return new_file_header

    def create_8bpp_info_header(self):
        width = len(self.pixel_data[0])
        height = len(self.pixel_data)
        size = 40
        cnt = 8
        colors = 256
        new_info_header = bytearray(40)
        new_info_header[:4] = size.to_bytes(4, 'little')  # 信息头大小
        new_info_header[4:8] = width.to_bytes(4, 'little')  # 图像宽度
        new_info_header[8:12] = height.to_bytes(4, 'little')  # 图像高度
        new_info_header[12:14] = b'\x01\x00'  # 平面数
        new_info_header[14:16] = cnt.to_bytes(2, 'little')  # 每像素位数
        new_info_header[16:20] = b'\x00\x00\x00\x00'  # 压缩方式
        new_info_header[20:24] = (len(self.pixel_data) * len(self.pixel_data[0])).to_bytes(4, 'little')  # 图像大小
        new_info_header[24:28] = b'\x00\x00\x00\x00'  # 水平分辨率
        new_info_header[28:32] = b'\x00\x00\x00\x00'  # 垂直分辨率
        new_info_header[32:36] = colors.to_bytes(4, 'little')  # 颜色表中的颜色数
        new_info_header[36:40] = colors.to_bytes(4, 'little')  # 重要颜色数
        return new_info_header

    def create_color_table(self):
        color_table = bytearray()
        for i in range(256):
            color_table += i.to_bytes(1, 'little') * 4
        return color_table

    def write_8bpp_bmp(self):
        with open(self.output_file, 'wb') as f:
            f.write(self.create_8bpp_file_header())
            f.write(self.create_8bpp_info_header())
            f.write(self.create_color_table())
            for row in self.pixel_data:
                f.write(bytes(row))


# 使用示例
converter = BMPConverter24to8('24位真彩色BMP/trump.bmp', 'result_1/8_trump.bmp')
converter.read_24bpp_bmp()
converter.write_8bpp_bmp()