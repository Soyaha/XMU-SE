import cv2
import dlib 

# 初始化摄像头
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("无法打开摄像头")
    exit()

# 加载OpenCV人脸检测器
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
# 加载dlib的68个人脸特征点检测器（需提前下载模型文件shape_predictor_68_face_landmarks.dat）
predictor = dlib.shape_predictor("D:\python\shape_predictor_68_face_landmarks.dat\shape_predictor_68_face_landmarks.dat")

while True:
    ret, frame = cap.read()
    if not ret:
        print("无法接收帧（流结束？）")
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # 检测人脸
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in faces:
        # 将OpenCV的人脸矩形转换为dlib的矩形格式
        rect = dlib.rectangle(x, y, x + w, y + h)
        # 检测68个人脸特征点
        shape = predictor(gray, rect)
        # 绘制特征点
        for i in range(68):
            cv2.circle(frame, (shape.part(i).x, shape.part(i).y), 2, (0, 255, 0), -1)

    cv2.imshow('image', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()