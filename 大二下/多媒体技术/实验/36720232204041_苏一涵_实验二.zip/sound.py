import sounddevice as sd
from soundfile import read as sf_read
from pydub import AudioSegment
from pydub.utils import make_chunks

# 读取并播放原始音频
data, fs = sf_read('music.wav')
sd.play(data, fs)
sd.wait()

# 处理音频：去掉偶数秒内容
audio = AudioSegment.from_wav('music.wav')
chunk_length_ms = 1000  # 1秒
chunks = make_chunks(audio, chunk_length_ms)

new_audio = AudioSegment.silent(duration=0)
for idx, chunk in enumerate(chunks):
    if (idx + 1) % 2 != 0:  # 保留奇数秒音频
        new_audio += chunk

# 保存新音频
new_audio.export('new_music.wav', format='wav')