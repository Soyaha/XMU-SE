import matplotlib.pyplot as plt

# 统计字母出现次数
letter_count = {}
with open('alphatwice.txt', 'r', encoding='utf-8') as file:
    content = file.read()
    for char in content:
        if char.isalpha():
            letter_count[char] = letter_count.get(char, 0) + 1

# 筛选出现次数最高的10个字母
sorted_letters = sorted(letter_count.items(), key=lambda x: x[1], reverse=True)[:10]
letters, counts = zip(*sorted_letters)

# 绘制直方图并显示具体次数
plt.bar(letters, counts)
plt.xlabel('Letters')
plt.ylabel('Counts')
plt.title('Top 10 English Letters Frequency')

# 添加次数显示
for i, count in enumerate(counts):
    plt.text(i, count, str(count), ha='center', va='bottom')

plt.savefig('letter_frequency_histogram.png')
plt.close()