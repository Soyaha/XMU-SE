#include "circle.h"

double Circle::perimeter() const { return 2.0 * PI * r; }

double Circle::area() const { return PI * r * r; }