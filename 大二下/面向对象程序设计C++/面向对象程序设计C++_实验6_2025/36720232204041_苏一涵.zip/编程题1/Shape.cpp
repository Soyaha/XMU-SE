#include "Shape.h"

double Rectangle::getArea()  {
    return h * w;
}

double Circle::getArea() {
    return 3.14 * r * r;
}
