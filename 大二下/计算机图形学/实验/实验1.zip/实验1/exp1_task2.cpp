#include <GL/glut.h>
#include <math.h>
const GLfloat Pi = 3.1415926536f;//Բ����
const GLfloat R = 0.5f;//�뾶
const int n = 140;//Բ�εĶ�����
static GLfloat spin = 0.0;//��ת����
void init(void)
{
	glClearColor(1.0, 1.0, 1.0, 0.0);//��������Ϊ��ɫ
	glShadeModel(GL_FLAT); //ʹ�õ�һ��ɫ
}
void drawSector(GLfloat red, GLfloat green, GLfloat blue, int startAngleIndex, int endAngleIndex) {
	glBegin(GL_POLYGON);
	glColor3f(red, green, blue); // ������ɫ
	glVertex2f(0, 0);           //Բ��
	for (int i = startAngleIndex; i <= endAngleIndex; i++)
		glVertex2f(R * sin(2 * Pi / n * i), R * cos(2 * Pi / n * i)); // ���㶥��λ��
	glEnd();
}
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT );	// Clear Screen And Depth Buffer
	//glLoadIdentity();									// Reset The Current Modelview Matrix
	//��������ϳ���
	drawSector(1.0, 0.0, 0.0, spin, spin+20);
	drawSector(1.0, 1.0, 0.0, spin+20, spin+40);  
	drawSector(0.0, 1.0, 0.0, spin+40, spin+60); 
	drawSector(0.0, 0.0, 0.8, spin+60, spin+80);  
	drawSector(1.0, 0.0, 1.0, spin+80, spin+100); 
	drawSector(1.0, 0.5, 0.0, spin+100, spin+120);  
	drawSector(0.0, 0.7, 1.0, spin+120,spin+140 );  

	glFlush();
}
void spinDisplay(void) {//��ת����
	spin += 0.01;
	if (spin > 140.0)spin -= 140.0;
	glutPostRedisplay();
}
void mouse(int button, int state, int x, int y)//�����ת���Ҽ�ֹͣ
{
	switch (button) {
	case GLUT_LEFT_BUTTON:
		if (state == GLUT_DOWN)
			glutIdleFunc(spinDisplay);
		break;
	case GLUT_RIGHT_BUTTON:
		if (state == GLUT_DOWN)
			glutIdleFunc(NULL);
		break;
	default:
		break;
	}
}
//void reshape(int w, int h)
//{
//	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
//	glMatrixMode(GL_PROJECTION);
//	glLoadIdentity();
//	glFrustum(-1.0, 1.0, -1.0, 1.0, 1.5, 20.0);
//	glMatrixMode(GL_MODELVIEW);
//}
//
//void keyboard(unsigned char key, int x, int y)
//{
//	switch (key) {
//	case 27:
//		exit(0);
//		break;
//	}
//}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100); //���ڴ�����Ļ���Ͻǵ�λ��
	glutCreateWindow(argv[0]);
	init();
	glutDisplayFunc(display);
	//glutReshapeFunc(reshape);
	//glutKeyboardFunc(keyboard);
	glutMouseFunc(mouse);
	glutMainLoop();
	return 0;
}
