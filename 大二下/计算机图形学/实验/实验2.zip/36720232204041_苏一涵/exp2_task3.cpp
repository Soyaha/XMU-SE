#define _USE_MATH_DEFINES
#include <math.h>
#include <GL/glut.h>

// ������ת�Ƕ�
float rotateAngle = 0.0f;
// �������
float cameraX = 0.0f, cameraY = 0.0f, cameraZ = 5.0f;
float cameraYaw = 0.0f;
float moveSpeed = 0.1f;
int isLocked = 0;
#define DEG_TO_RAD 0.017453
// �����������
GLfloat cameraFront[3] = { 0.0f, 0.0f, -1.0f };

void init() {
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glEnable(GL_DEPTH_TEST);
}

// �����߿�����
void drawWireSphere() {
    const int slices = 30;  // ���ȷֶΣ�����Z��ķֶ�����
    const int stacks = 30;  // γ�ȷֶΣ���Y��ķֶ�����
    glColor3f(1.0, 0.0, 0.0);
    glBegin(GL_LINES);

    // ���ƾ��ߣ�����������
    for (int i = 0; i < slices; i++) {
        float theta1 = 2 * M_PI * i / slices;
        float theta2 = 2 * M_PI * (i + 1) / slices;
        for (int j = 0; j <= stacks; j++) {
            float phi = M_PI * j / stacks;
            float x1 = cos(theta1) * sin(phi);
            float y1 = cos(phi);
            float z1 = sin(theta1) * sin(phi);

            float x2 = cos(theta2) * sin(phi);
            float y2 = cos(phi);
            float z2 = sin(theta2) * sin(phi);

            // ����ͬһγ�ȡ���ͬ���ȵĵ㣨�����߼��Ż���
            glVertex3f(x1, y1, z1);
            glVertex3f(x2, y2, z2);
        }
    }

    // ����γ�ߣ�����������
    for (int j = 0; j < stacks; j++) {
        float phi1 = M_PI * j / stacks;
        float phi2 = M_PI * (j + 1) / stacks;
        for (int i = 0; i <= slices; i++) {
            float theta = 2 * M_PI * i / slices;
            float x = cos(theta) * sin(phi1);
            float z = sin(theta) * sin(phi1);

            float nextX = cos(theta) * sin(phi2);
            float nextZ = sin(theta) * sin(phi2);

            // ����ͬһ���ȡ���ͬγ�ȵĵ�
            glVertex3f(x, cos(phi1), z);
            glVertex3f(nextX, cos(phi2), nextZ);
        }
    }
    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // ��������ӽ�
    gluLookAt(cameraX, cameraY, cameraZ,
        cameraX + cameraFront[0], cameraY + cameraFront[1], cameraZ + cameraFront[2],
        0.0, 1.0, 0.0);

    glPushMatrix();
    glRotatef(rotateAngle, 1.0, 1.0, 1.0); // ��Y����ת
    drawWireSphere();
    glPopMatrix();

    glutSwapBuffers();
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (GLfloat)w / (GLfloat)h, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
}

void idle() {
    rotateAngle += 0.5;
    if (rotateAngle > 360) rotateAngle -= 360;
    glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y) {
    switch (key) {
    case 27: exit(0); break;
    case 'w': {
        if (!isLocked) {
            cameraX += cameraFront[0] * moveSpeed;
            cameraZ += cameraFront[2] * moveSpeed;
        }
        break;
    }
    case 's': {
        if (!isLocked) {
            cameraX -= cameraFront[0] * moveSpeed;
            cameraZ -= cameraFront[2] * moveSpeed;
        }
        break;
    }
    case 'a': {
        if (!isLocked) {
            GLfloat right[3] = { 0.0f, 0.0f, 0.0f };
            GLfloat up[3] = { 0.0f, 1.0f, 0.0f };
            right[0] = cameraFront[1] * up[2] - cameraFront[2] * up[1];
            right[1] = cameraFront[2] * up[0] - cameraFront[0] * up[2];
            right[2] = cameraFront[0] * up[1] - cameraFront[1] * up[0];
            cameraX += right[0] * moveSpeed;
            cameraZ += right[2] * moveSpeed;
        }
        break;
    }
    case 'd': {
        if (!isLocked) {
            GLfloat right[3] = { 0.0f, 0.0f, 0.0f };
            GLfloat up[3] = { 0.0f, 1.0f, 0.0f };
            right[0] = cameraFront[1] * up[2] - cameraFront[2] * up[1];
            right[1] = cameraFront[2] * up[0] - cameraFront[0] * up[2];
            right[2] = cameraFront[0] * up[1] - cameraFront[1] * up[0];
            cameraX -= right[0] * moveSpeed;
            cameraZ -= right[2] * moveSpeed;
        }
        break;
    }
    case 'q': {
        if (!isLocked) {
            GLfloat right[3] = { 0.0f, 0.0f, 0.0f };
            GLfloat up[3] = { 0.0f, 1.0f, 0.0f };
            right[0] = cameraFront[1] * up[2] - cameraFront[2] * up[1];
            right[1] = cameraFront[2] * up[0] - cameraFront[0] * up[2];
            right[2] = cameraFront[0] * up[1] - cameraFront[1] * up[0];
            cameraY += right[0] * moveSpeed;
            cameraZ += right[2] * moveSpeed;
        }
        break;
    }
    case 'e': {
        if (!isLocked) {
            GLfloat right[3] = { 0.0f, 0.0f, 0.0f };
            GLfloat up[3] = { 0.0f, 1.0f, 0.0f };
            right[0] = cameraFront[1] * up[2] - cameraFront[2] * up[1];
            right[1] = cameraFront[2] * up[0] - cameraFront[0] * up[2];
            right[2] = cameraFront[0] * up[1] - cameraFront[1] * up[0];
            cameraY -= right[0] * moveSpeed;
            cameraZ -= right[2] * moveSpeed;
        }
        break;
    }
    case 'l':
    case 'L': {
        isLocked = !isLocked;
        if (isLocked) glutSetCursor(GLUT_CURSOR_NONE);
        else glutSetCursor(GLUT_CURSOR_LEFT_ARROW);
        break;
    }
    }
    glutPostRedisplay();
}

void mouse(int x, int y) {
    static int lastX = -1;
    static int lastY = -1;

    if (lastX == -1 || lastY == -1) {
        lastX = x;
        lastY = y;
        return;
    }

    float sensitivity = 0.05; // ���������
    float deltaX = (x - lastX) * sensitivity;
    float deltaY = (lastY - y) * sensitivity; // y�ᷴ��

    lastX = x;
    lastY = y;

    float yaw = deltaX;
    float pitch = deltaY;

    // ��������ĳ���
    float yawRad = DEG_TO_RAD * yaw;
    float pitchRad = DEG_TO_RAD * pitch;

    GLfloat newX = cameraFront[0] * cos(yawRad) + cameraFront[2] * sin(yawRad);
    GLfloat newY = cameraFront[1];
    GLfloat newZ = -cameraFront[0] * sin(yawRad) + cameraFront[2] * cos(yawRad);
    cameraFront[0] = newX;
    cameraFront[1] = newY;
    cameraFront[2] = newZ;

    // ʹ��ŷ�������Ƹ����Ƕ�
    if ((cameraFront[1] > 0.99 && pitch > 0) || (cameraFront[1] < -0.99 && pitch < 0))
        return;

    GLfloat pitchAxis[] = { 1.0, 0.0, 0.0 }; // ��X����ת
    GLfloat newCameraFront[3];
    GLfloat c = cos(pitchRad);
    GLfloat s = sin(pitchRad);
    newCameraFront[0] = cameraFront[0] * c + (1 - c) * pitchAxis[0] * cameraFront[0] + cameraFront[1] * s;
    newCameraFront[1] = cameraFront[1] * c - (1 - c) * pitchAxis[1] - cameraFront[0] * s;
    newCameraFront[2] = cameraFront[2] * c + (1 - c) * pitchAxis[2] * cameraFront[2];

    // ��������ĳ���
    for (int i = 0; i < 3; ++i)
        cameraFront[i] = newCameraFront[i];

    glutPostRedisplay();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Wire Sphere");

    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutIdleFunc(idle);
    glutKeyboardFunc(keyboard);
    glutPassiveMotionFunc(mouse); // ʹ����깦��

    glutMainLoop();
    return 0;
}