#include <GL/freeglut.h> // ʹ��FreeGLUT֧�ֻ�����
#include <math.h>
#define DEG_TO_RAD 0.017453
const GLfloat RR = 2.0; // camera rad
GLfloat beta = 0;

// Material properties
GLfloat brassAmbient[] = { 0.33f, 0.22f, 0.03f, 1.0f };
GLfloat brassDiffuse[] = { 0.78f, 0.57f, 0.11f, 1.0f };
GLfloat brassSpecular[] = { 0.99f, 0.91f, 0.81f, 1.0f };
GLfloat brassShininess = 27.8f;

GLfloat redPlasticAmbient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat redPlasticDiffuse[] = { 0.5f, 0.0f, 0.0f, 1.0f };
GLfloat redPlasticSpecular[] = { 0.7f, 0.6f, 0.6f, 1.0f };
GLfloat redPlasticShininess = 32.0f;

GLfloat whiteShinyAmbient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat whiteShinyDiffuse[] = { 0.7f, 0.7f, 0.7f, 1.0f };
GLfloat whiteShinySpecular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat whiteShinyShininess = 100.0f;

// ������ǰ���ʵ�shininess����
GLfloat currentShininess = brassShininess;

// Light properties
GLfloat light0Position[] = { 0.0f, 0.0f, 2.0f, 1.0f };
GLfloat light0Ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat light0Diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f };
GLfloat light0Specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };

GLfloat light1Position[] = { 0.0f, 0.0f, 2.0f, 1.0f };
GLfloat light1Ambient[] = { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat light1Diffuse[] = { 1.0f, 0.0f, 0.0f, 1.0f }; // Red light
GLfloat light1Specular[] = { 1.0f, 0.0f, 0.0f, 1.0f };

// �����ز���
GLfloat cameraPos[] = { 0.0, 0.0, 5.0 }; // ���λ��
GLfloat cameraFront[] = { 0.0, 0.0, -1.0 }; // ���ǰ����
GLfloat cameraUp[] = { 0.0, 1.0, 0.0 }; // ����Ϸ���
bool lockCamera = false; // ��������ƶ�����ת

// �����˵��ͻ������ص�����
void shininessSlider(int value) {
    currentShininess = value;
    glMaterialf(GL_FRONT, GL_SHININESS, currentShininess);
    glutPostRedisplay();
}

void lightXSlider(int value) {
    light0Position[0] = (GLfloat)(value - 50) / 10.0f; // ��Χ-5��5
    glLightfv(GL_LIGHT0, GL_POSITION, light0Position);
    glutPostRedisplay();
}

void materialMenu(int option) {
    switch (option) {
    case 0: // ��ͭ����
        glMaterialfv(GL_FRONT, GL_AMBIENT, brassAmbient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, brassDiffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, brassSpecular);
        currentShininess = brassShininess;
        glMaterialf(GL_FRONT, GL_SHININESS, currentShininess);
        break;
    case 1: // ��ɫ����
        glMaterialfv(GL_FRONT, GL_AMBIENT, redPlasticAmbient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, redPlasticDiffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, redPlasticSpecular);
        currentShininess = redPlasticShininess;
        glMaterialf(GL_FRONT, GL_SHININESS, currentShininess);
        break;
    case 2: // ��ɫ����
        glMaterialfv(GL_FRONT, GL_AMBIENT, whiteShinyAmbient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, whiteShinyDiffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, whiteShinySpecular);
        currentShininess = whiteShinyShininess;
        glMaterialf(GL_FRONT, GL_SHININESS, currentShininess);
        break;
    }
    glutPostRedisplay();
}

void init(void)
{
    glClearColor(0.0, 0.0, 0.0, 0.0);

    // Enable depth testing
    glEnable(GL_DEPTH_TEST);

    // Enable lighting
    glEnable(GL_LIGHTING);

    // Enable lights
    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0, GL_POSITION, light0Position);
    glLightfv(GL_LIGHT0, GL_AMBIENT, light0Ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light0Diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light0Specular);

    glEnable(GL_LIGHT1);
    glLightfv(GL_LIGHT1, GL_POSITION, light1Position);
    glLightfv(GL_LIGHT1, GL_AMBIENT, light1Ambient);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, light1Diffuse);
    glLightfv(GL_LIGHT1, GL_SPECULAR, light1Specular);

    // ����Ĭ�ϲ���
    glMaterialfv(GL_FRONT, GL_AMBIENT, brassAmbient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, brassDiffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, brassSpecular);
    glMaterialf(GL_FRONT, GL_SHININESS, brassShininess);

    // �������ʲ˵��ͻ�����
    glutCreateMenu(materialMenu);
    glutAddMenuEntry("��ͭ����", 0);
    glutAddMenuEntry("��ɫ����", 1);
    glutAddMenuEntry("��ɫ����", 2);
    //glutAddSlider("Shininess", 0, 200, (int)brassShininess, shininessSlider); // 0-200��Χ
    //glutAddSlider("Light X Position", 0, 100, 50, lightXSlider); // 0-100ӳ�䵽-5��5
    glutAttachMenu(GLUT_RIGHT_BUTTON); // �Ҽ������˵�
}
void display(void)
{
    // Clear the color and depth buffers
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Reset transformations
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    if (!lockCamera)
    {
        // Set camera position
        gluLookAt(cameraPos[0], cameraPos[1], cameraPos[2],
            cameraPos[0] + cameraFront[0], cameraPos[1] + cameraFront[1], cameraPos[2] + cameraFront[2],
            cameraUp[0], cameraUp[1], cameraUp[2]);
    }

    // Ӧ����ת�任
    glRotatef(beta, 1.0, 1.0, 1.0);  // ��Y����ת����Ҳ�����޸���ͽǶ�

    // Draw the cube
    glBegin(GL_QUADS);
    // face A
    glNormal3f(0.0, 0.0, 1.0);
    glVertex3f(-1, -1, 1);
    glVertex3f(1, -1, 1);
    glVertex3f(1, 1, 1);
    glVertex3f(-1, 1, 1);
    // face B
    glNormal3f(0.0, 0.0, -1.0);
    glVertex3f(-1, -1, -1);
    glVertex3f(1, -1, -1);
    glVertex3f(1, 1, -1);
    glVertex3f(-1, 1, -1);
    // face C
    glNormal3f(0.0, 1.0, 0.0);
    glVertex3f(-1, 1, -1);
    glVertex3f(1, 1, -1);
    glVertex3f(1, 1, 1);
    glVertex3f(-1, 1, 1);
    // face D
    glNormal3f(0.0, -1.0, 0.0);
    glVertex3f(-1, -1, -1);
    glVertex3f(-1, -1, 1);
    glVertex3f(1, -1, 1);
    glVertex3f(1, -1, -1);
    // face E
    glNormal3f(-1.0, 0.0, 0.0);
    glVertex3f(-1, -1, -1);
    glVertex3f(-1, -1, 1);
    glVertex3f(-1, 1, 1);
    glVertex3f(-1, 1, -1);
    // face F
    glNormal3f(1.0, 0.0, 0.0);
    glVertex3f(1, -1, -1);
    glVertex3f(1, -1, 1);
    glVertex3f(1, 1, 1);
    glVertex3f(1, 1, -1);
    glEnd();

    // Swap the buffers
    glutSwapBuffers();
}

void reshape(int w, int h)
{
    // Set the viewport to cover the entire window
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);

    // Set up the projection matrix
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (GLfloat)w / (GLfloat)h, 0.1, 100.0);

    // Switch back to modelview matrix
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void idlefunc()
{
    // Change animation parameter
    beta += 0.5;  // ������ת�ٶȣ�����Ե������ֵ
    if (beta > 360) beta -= 360;
    glutPostRedisplay();
}
// �����������ֲ��䣬�޸�keyboard�������������л�ʱ����currentShininess
void keyboard(unsigned char key, int x, int y)
{
    float cameraSpeed = 0.1;
    switch (key) {
    case 'w':
        cameraPos[0] += cameraSpeed * cameraFront[0];
        cameraPos[2] += cameraSpeed * cameraFront[2];
        break;
    case 's':
        cameraPos[0] -= cameraSpeed * cameraFront[0];
        cameraPos[2] -= cameraSpeed * cameraFront[2];
        break;
    case 'a':
        cameraPos[0] -= cameraSpeed * (cameraFront[2]);
        cameraPos[2] += cameraSpeed * (cameraFront[0]);
        break;
    case 'd':
        cameraPos[0] += cameraSpeed * (cameraFront[2]);
        cameraPos[2] -= cameraSpeed * (cameraFront[0]);
        break;
    case 'q':
        cameraPos[1] += cameraSpeed;
        break;
    case 'e':
        cameraPos[1] -= cameraSpeed;
        break;
    case 'L':
        lockCamera = !lockCamera;
        break;
    case 'b': // ��ͭ����
        glMaterialfv(GL_FRONT, GL_AMBIENT, brassAmbient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, brassDiffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, brassSpecular);
        currentShininess = brassShininess;
        glMaterialf(GL_FRONT, GL_SHININESS, currentShininess);
        break;
    case 'n': // ��ɫ����
        glMaterialfv(GL_FRONT, GL_AMBIENT, redPlasticAmbient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, redPlasticDiffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, redPlasticSpecular);
        currentShininess = redPlasticShininess;
        glMaterialf(GL_FRONT, GL_SHININESS, currentShininess);
        break;
    case 'm': // ��ɫ����
        glMaterialfv(GL_FRONT, GL_AMBIENT, whiteShinyAmbient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, whiteShinyDiffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, whiteShinySpecular);
        currentShininess = whiteShinyShininess;
        glMaterialf(GL_FRONT, GL_SHININESS, currentShininess);
        break;
    case 'o': // White light
        glLightfv(GL_LIGHT1, GL_DIFFUSE, light0Diffuse);
        glLightfv(GL_LIGHT1, GL_SPECULAR, light0Specular);
        break;
    case 'p': // Red light
        glLightfv(GL_LIGHT1, GL_DIFFUSE, light1Diffuse);
        glLightfv(GL_LIGHT1, GL_SPECULAR, light1Specular);
        break;
    case 27: // Escape key
        exit(0);
        break;
    }
    glutPostRedisplay();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Interactive Lighting & Material Demo");
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutIdleFunc(idlefunc);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}