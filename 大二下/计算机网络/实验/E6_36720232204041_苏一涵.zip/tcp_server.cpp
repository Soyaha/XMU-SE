#define _CRT_SECURE_NO_WARNINGS
#include <ws2tcpip.h>  
#include <stdio.h>  

#include <winsock2.h>  
#pragma comment(lib, "ws2_32.lib")  

#define DEFAULT_PORT "54321"  
#define BUFFER_SIZE 1024  

int main() {
    // ��ʼ����
    WSADATA wsaData;
    int result = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (result != 0) {
        printf("WSAStartup failed with error: %d\n", result);
        return 1;
    }

    // �����׽���
    SOCKET serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (serverSocket == INVALID_SOCKET) {
        printf("Could not create socket: %d\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }

    // ��IP�Ͷ˿�
    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(atoi(DEFAULT_PORT));

    if (bind(serverSocket, (SOCKADDR*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        printf("Bind failed with error: %d\n", WSAGetLastError());
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    // ��ʼ����
    if (listen(serverSocket, 5) == SOCKET_ERROR) {
        printf("Listen failed with error: %d\n", WSAGetLastError());
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    printf("Server listening on port %s...\n\n", DEFAULT_PORT);

    // ѭ�������ļ�
    while (1)
    {
        SOCKADDR clientAddr;
        int clientAddrSize = sizeof(clientAddr);
        // ����������Ӷ��з�����һ�������ɹ�������
        SOCKET clientSocket = accept(serverSocket, &clientAddr, &clientAddrSize);
        if (clientSocket == INVALID_SOCKET) {
            printf("Accept failed with error: %d\n", WSAGetLastError());
            closesocket(serverSocket);
            WSACleanup();
            return 1;
        }

        printf("һ���ͻ������ӳɹ���\n\n");

        char buffer[BUFFER_SIZE + 1] = { 0 };

        // ���� �ļ���С �� �ļ���
        char fileNameAndExt[MAX_PATH * 4];
        int fileSize = 0;
        int receivedBytes = recv(clientSocket, buffer, BUFFER_SIZE, 0);
        if (receivedBytes == SOCKET_ERROR) {
            int error = WSAGetLastError();
            if (error == WSAECONNRESET) {
                printf("Client connection reset by peer.\n");
                break;
            }
            else if (error == WSAETIMEDOUT) {
                printf("Receive timeout.\n");
                break;
            }
            else {
                printf("Send failed with error: %d\n", error);
                break;
            }
        }
        else if (receivedBytes == 0) {
            printf("Connection closed by client.\n");
            break;
        }
        else {
            // ȡ���ļ���С��ǰ4���ֽڣ����ļ���
            fileSize = (((unsigned char)buffer[0]) << 24) |
                (((unsigned char)buffer[1]) << 16) |
                (((unsigned char)buffer[2]) << 8) |
                ((unsigned char)buffer[3]);
            strcpy(fileNameAndExt, buffer + 4);
            printf("���յ��ļ���%s\n", fileNameAndExt);
            printf("�ļ���С:%d\n", fileSize);
        }

        // ���ļ���׼��д��
        FILE* pFile = fopen(fileNameAndExt, "wb");
        if (pFile != NULL)
        {
            bool success = true;// �ļ��Ƿ���ȫ����
            int receivedSize = 0;// �ѽ��յ��ֽ���
            // ѭ�������ļ���ֱ��ָ����С
            while (1)
            {
                receivedBytes = recv(clientSocket, buffer, BUFFER_SIZE, 0);
                if (receivedBytes == SOCKET_ERROR) {
                    success = false;
                    int error = WSAGetLastError();
                    if (error == WSAECONNRESET) {
                        // ���ӶϿ������ �ͻ���IP���˿ڣ�ɾ���ļ�
                        char clientIP[INET_ADDRSTRLEN];
                        int clientPort;
                        struct sockaddr_in addr;
                        int addrLen = sizeof(addr);
                        if (getpeername(clientSocket, (struct sockaddr*)&addr, &addrLen) == 0)
                        {
                            inet_ntop(AF_INET, &addr.sin_addr, clientIP, INET_ADDRSTRLEN);
                            clientPort = ntohs(addr.sin_port);
                        }
                        else
                            printf("Error getting peer name: %d\n", WSAGetLastError());

                        printf("�ͻ��� %s : %d ����%s �ļ�������ʧȥ����.\n", clientIP, clientPort, fileNameAndExt);
                        break;
                    }
                    else if (error == WSAETIMEDOUT) {
                        printf("Receive timeout.\n");
                        break;
                    }
                    else {
                        printf("Send failed with error: %d\n", error);
                        break;
                    }
                }
                else {
                    // ���������е�����д�뱾���ļ�
                    if (fwrite(buffer, 1, receivedBytes, pFile) != receivedBytes)
                    {
                        printf("д��ʧ��.\n");
                        break;
                    }

                    // ���յ�ָ����С������Ϊ�ļ����ճɹ�
                    receivedSize += receivedBytes;
                    if (receivedSize == fileSize)
                    {
                        printf("%s ���ճɹ�!\n\n\n", fileNameAndExt);
                        break;
                    }
                }
            }
            // �رձ����ļ�
            fclose(pFile);

            // �ļ�δ�ܽ�����ȫ��ɾ��֮
            if (!success)
            {
                remove(fileNameAndExt);
                printf("%s ��ɾ��.\n\n\n", fileNameAndExt);
            }
        }
        else
        {
            printf("�ļ���ʧ��.\n\n\n");
        }

        closesocket(clientSocket);
    }

    closesocket(serverSocket);
    WSACleanup();

    system("pause");
    return 0;
}