var aigcReportLock = true;
var aigcReportSimilarity = "91.9%";
var aigcReportUrl = "https://report.paperyy.com/20250518/4-6910cc7f95664317abd3674083662adc-aigc/contrast.html?AccessKeyId=HBDT3R50QARZFDNEE0FT&Expires=1748176601&Signature=zvallkhRH70m1s3TOLgnH%2BwOgWg%3D";
var zipReportUrl = "https://report.paperyy.com/20250518/1eb0c6f6-f28c-41de-9e2c-866329c1f117/report.zip?AccessKeyId=HBDT3R50QARZFDNEE0FT&Expires=1748176601&Signature=lYT/EBE/rEIWHLQGdZREPwSuT7Y%3D";

