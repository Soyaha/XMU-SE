﻿#include "stdio.h"
int f1(unsigned n)
{
	int sum = 1, power = 1;
	for (unsigned i = 0; i <= n - 1; i++)
	{
		power *= 2;
		sum += power;
	}
	return sum;
}
float f2(unsigned n)
{
	float sum = 1, power = 1;
	for (unsigned i = 0; i <= n - 1; i++)
	{
		power *= 2;
		sum += power;
	}
	return sum;
}
void hex_out(char a)// 输出 8 位教据的十六进制值
{
	const char HEX[] = "0123456789ABCDEF";
	printf("%c%c", HEX[(a & 0xF0) >> 4], HEX[a & 0x0F]);
}
void out_4byte(char* addr)// 用十六进制输出地址中的 32 位数据机器码
{//小端模式先输出高字节
	hex_out(*(addr + 3)); hex_out(*(addr + 2)); hex_out(*(addr + 1)); hex_out(*(addr + 0));
}
void main(){
	unsigned n=127;
	int a = f1(n);
	int b = f2(n);
	printf("f1(%d)= ",n);
	out_4byte(&a);
	printf("\nf2(%d)= ",n);
	out_4byte(&b);
}