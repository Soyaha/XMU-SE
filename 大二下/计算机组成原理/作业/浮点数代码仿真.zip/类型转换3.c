﻿#include "stdio.h"
union {//该联合体中所有变量共享 4 字节存储空间，但不同变量字节数不同
	int i; unsigned int ui; float f; // i、ui、f 共享4 字节存储空间，机器码相同，数据类型不同
	short s; unsigned short us; // s、us 共享双字节存储空间，机器码相同，教据类型不同
	char c; unsigned char uc; //c、uc 共享单字节存储空间、机器码相同，教据类型不同
}t;
void hex_out(char a)// 输出 8 位教据的十六进制值
{
	const char HEX[] = "0123456789ABCDEF";
	printf("%c%c", HEX[(a & 0xF0) >> 4], HEX[a & 0x0F]);
}
void out_1byte(char* addr)// 用十六进制输出地址中的 8 位教据机器码
{
	hex_out(*(addr + 0));
}
void out_2byte(char* addr)// 用十六进制翰出地址中的 16 位教据机器码
{// 小端模式先翰出高字节
	hex_out(*(addr + 1)); hex_out(*(addr + 0));
}
void out_4byte(char* addr)// 用十六进制输出地址中的 32 位数据机器码
{//小端模式先输出高字节
	hex_out(*(addr + 3)); hex_out(*(addr + 2)); hex_out(*(addr + 1)); hex_out(*(addr + 0));
}
void main(){
	int i = 0xFFFF1001;
	short s;
	unsigned short us;
	s = i;//大字长转小字长，机器码被截短
	us = i;//大字长转小字长，机器码被截短
	out_4byte(&i);printf("=i= %d\n",i);//输出原数据的机器码和真值FFFE1001-i=-61439
	out_2byte(&s);printf("= s = %d\n",s);//输出转换后的机器码和真值1001-s=4097
	out_2byte(&us);printf("=us=%u\n",us);//输出转换后的机器码和真值1001=us=4097
}