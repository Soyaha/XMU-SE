#define _CRT_SECURE_NO_WARNINGS
#include<assert.h>
#include<stdio.h>
#include<iostream>
#include<string.h>
#include<stdbool.h>
using namespace std;
typedef struct QueueNode {//���д洢�ṹ
    int data;
    struct QueueNode* next;
}QueueNode;

typedef struct {//����
    QueueNode* head;
    QueueNode* tail;
}Queue;

void QueueInit(Queue* pq)//��ʼ������
{
    assert(pq);
    pq->head = NULL;
    pq->tail = NULL;
}

void QueueDestory(Queue* pq)//���ٶ���
{
    assert(pq);
    QueueNode* cur = pq->head;
    while (cur)
    {
        QueueNode* next = cur->next;
        free(cur);
        cur = next;
    }
    pq->head = pq->tail = NULL;
}

void QueuePush(Queue* pq, int x)//���
{
    assert(pq);
    QueueNode* newnode = (QueueNode*)malloc(sizeof(QueueNode));
    newnode->data = x;
    newnode->next = NULL;
    if (pq->head == NULL)
    {
        pq->head = pq->tail = newnode;
    }
    else
    {
        pq->tail->next = newnode;
        pq->tail = newnode;
    }
}

void QueuePop(Queue* pq,int& u)//��λ����
{
    assert(pq);
    assert(pq->head);
    u=pq->head->data;
    QueueNode* next = pq->head->next;
    free(pq->head);
    pq->head = next;
    if (pq->head == NULL)
    {
        pq->tail = NULL;
    }
}

bool QueueEmpty(Queue* pq)
{
    if (pq->head == NULL)
        return true;
    else
        return false;
}
